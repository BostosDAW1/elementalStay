<?php
session_start();
// Se asume que $listado y $config vienen definidos al incluir la vista mediante el motor de plantillas
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <title>Elemental Stay - Hoteles Información completa</title>
  <link rel="stylesheet" href="../CSS/header.css"/>
  <link rel="stylesheet" href="../CSS/hoteles_completos.css"/>
  <link rel="stylesheet" href="../CSS/footer.css"/>
  <link rel="shortcut icon" href="../img/logo.png"/>
</head>
<body>
    <!-- ------------------------ NAV PRINCIPAL + OPCIONES --------------------- -->
    <nav>
        <div class="logo">
            <img src="../img/logo.png" alt="Logo">
            <h1 class="logo-title">ELEMENTAL STAY</h1>
        </div>
        <ul>
            <li><a href="../index.php" id="boton-superior"><b>INICIO</b></a></li>
            <li><a href="../contactos/contactos.php" id="boton-superior"><b>CONTACTO</b></a></li>
            <?php if (isset($_SESSION['usuario'])): ?>
                <li class="profile">
                    <a href="javascript:void(0);" onclick="toggleProfileMenu(event)" id="profileButton"><b>PERFIL</b></a>
                    <div class="profile-menu" id="profileMenu">
                        <a href="../perfil/perfil.php">Ver Perfil</a>
                        <a href="../inicio_session/logout.php" class="logout">Cerrar Sesión</a>
                    </div>
                </li>
            <?php else: ?>
                <li><a href="../inicio_session/inicio_session.php" id="boton-superior"><b>INICIAR SESIÓN</b></a></li>
            <?php endif; ?>
        </ul>
    </nav>
    
    
<main>
    <!-- Mostrar información básica del hotel -->
    <section class="hotel-info">
        <?php if (!empty($hotelInfo['imagen'])): ?>
        <div class="hotel-info__image">
            <img src="<?= $config->get('imagePath') . $hotelInfo['imagen'] ?>" alt="Imagen de <?= htmlspecialchars($hotelInfo['nombre']) ?>">
        </div>
        <?php endif; ?>
        <h2><?= htmlspecialchars($hotelInfo['nombre']) ?></h2>
        <div class="hotel-info__community">
            <?= htmlspecialchars($hotelInfo['comunidad_autonoma']) ?>
        </div>
        <p><?= htmlspecialchars($hotelInfo['descripcion']) ?></p>
        <p>Reserva para: <strong><?= $entrada ?></strong> - <strong><?= $salida ?></strong></p>
        <p>Adultos: <strong><?= $adultos ?></strong>, Niños: <strong><?= $ninos ?></strong></p>
    </section>

    <!-- Mostrar habitaciones disponibles -->
    <section class="habitaciones-disponibles">
    <h3>Habitaciones Disponibles</h3>
    <?php if (!empty($habitaciones)): ?>
        <?php foreach ($habitaciones as $hab): ?>
            <article class="habitacion-card">
                <h4><?= htmlspecialchars($hab['nombre']) ?></h4> <!-- Nombre de la habitación (columna 'nombre') -->
                <p>Categoría: <?= htmlspecialchars($hab['nombre_categoria']) ?></p> <!-- Nombre de la categoría -->
                <p>Capacidad: <?= $hab['capacidad'] ?></p>
                <p>Precio: <?= number_format($hab['precio'], 2) ?> €</p>
                <div class="habitacion-card__details">
                    <span><?= $hab['m2'] ?> m²</span>
                    <span class="<?= $hab['wifi'] ? 'wifi' : 'no-wifi' ?>">
                        <?= $hab['wifi'] ? 'Con WiFi' : 'Sin WiFi' ?>
                    </span>
                </div>
                <p><strong>Descripción:</strong> <?= htmlspecialchars($hab['descripcion']) ?></p> <!-- Mostrar descripción de la habitación -->
                <a href="#">Reservar</a>
            </article>
        <?php endforeach; ?>
    <?php else: ?>
        <p>No hay habitaciones disponibles para estas fechas.</p>
    <?php endif; ?>
    </section>
</main>





    <!-- ------------------------ FOOTER --------------------- -->
    <footer>
        <div class="footer-container">
            <div class="footer-section">
                <h4>Sobre Nosotros</h4>
                <p>Elemental Stay es tu plataforma para encontrar los mejores alojamientos al mejor precio, con opciones personalizadas para cada tipo de viajero.</p>
            </div>
            <div class="footer-section">
                <h4>Enlaces Útiles</h4>
                <ul>
                    <li><a href="#">Inicio</a></li>
                    <li><a href="#">Acerca de</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li><a href="#">Términos y Condiciones</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Síguenos</h4>
                <div class="social-icons">
                    <a href="#"><img src="icon-facebook.svg" alt="Facebook"></a>
                    <a href="#"><img src="icon-twitter.svg" alt="Twitter"></a>
                    <a href="#"><img src="icon-instagram.svg" alt="Instagram"></a>
                    <a href="#"><img src="icon-youtube.svg" alt="YouTube"></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Elemental Stay. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!-- ------------------------ SCRIPTS --------------------- -->
    <script src="../JS/Header.js"></script>
    <script src="../JS/hoteles.js"></script>
</body>
</html>
