async function filtrarHoteles() {
  const params = new URLSearchParams({
    nombreHotel: document.getElementById('nombreHotel').value,
    tipoDeHotel: document.getElementById('tipoDeHotel').value,
    comunidad: document.getElementById('comunidad').value,
    disponibilidad: document.getElementById('disponibilidad').value,
    precioMin: document.getElementById('precioMin').value,
    precioMax: document.getElementById('precioMax').value,
    fechaEntrada: document.getElementById('fechaEntrada').value,
    fechaSalida: document.getElementById('fechaSalida').value
  });

  const response = await fetch(`/hoteles?${params}`);
  const hoteles = await response.json();

  document.getElementById('hoteles').innerHTML = hoteles.map(hotel =>
    `<div class="hotel-card"><h2>${hotel.nombre}</h2><p>${hotel.tipo} - ${hotel.comunidad}</p></div>`
  ).join('');
}

function limpiarFiltros() {
  document.querySelectorAll('.filters input, .filters select').forEach(el => el.value = '');
}

//! ---------------------------- FUNCION MOSTRAR LOS HOTELES ----------------------------
function mostrarHoteles(hoteles) {
  const hotelesContainer = document.getElementById('hoteles');
  hotelesContainer.innerHTML = '';

  if (!Array.isArray(hoteles) || hoteles.length === 0) {
    hotelesContainer.innerHTML = '<p>No se encontraron hoteles que coincidan con los filtros.</p>';
    return;
  }

  hoteles.forEach(hotel => {
    const hotelDiv = document.createElement('div');
    hotelDiv.className = 'hotel';

    const nombre = hotel.nombre || 'Nombre no disponible';
    const tipo = hotel.tipo || 'No especificado';
    const comunidad = hotel.comunidad || 'No especificado';
    const precio = hotel.precio !== undefined ? `${hotel.precio}€` : 'No disponible';
    const disponibilidad = hotel.disponibilidad === 1 ? 'Disponible ✅' : 'No disponible ❌';
    
    // Asegurar que la ruta sea correcta
    const imagen = hotel.imagen ? `/${hotel.imagen}` : '/img/default.jpg'; // Imagen por defecto

    hotelDiv.innerHTML = `
      <div class="hotel-card">
        <img src="${imagen}" alt="Imagen de ${nombre}" class="hotel-img">
        <div class="hotel-info">
          <h2>${nombre}</h2>
          <p><strong>Tipo de Hotel:</strong> ${tipo}</p>
          <p><strong>Comunidad Autónoma:</strong> ${comunidad}</p>
          <p><strong>Precio:</strong> ${precio}</p>
          <p><strong>Disponibilidad:</strong> ${disponibilidad}</p>
        </div>
      </div>
    `;
    hotelesContainer.appendChild(hotelDiv);
  });
}




//! FUNCIONES DE BÚSQUEDA
//! ---------------------------- FILTRAR POR NOMBRE DEL HOTEL ----------------------------
function filtrarPorNombreHotel() {
  const nombre = document.getElementById('nombreHotel').value.trim().toLowerCase();
  
  // Realizar la solicitud al servidor para obtener los hoteles filtrados por nombre
  const nombreQuery = encodeURIComponent(nombre);
  
  fetch(`/hoteles?nombreHotel=${nombreQuery}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR TIPO DE HOTEL ----------------------------
function filtrarPorTipoDeHotel() {
  const tipoDeHotel = document.getElementById('tipoDeHotel').value.trim().toLowerCase();
  
  if (!tipoDeHotel) {
    mostrarError('Por favor, selecciona un tipo de hotel.');
    return;
  }

  fetch(`/hoteles?tipoDeHotel=${encodeURIComponent(tipoDeHotel)}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar los hoteles por tipo:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR COMUNIDAD AUTONOMA ----------------------------
function filtrarPorComunidadAutonomas() {
  const comunidadAutonomas = document.getElementById('comunidad').value.trim().toLowerCase();

  if (!comunidadAutonomas) {
    mostrarError('Por favor, selecciona una comunidad autónoma.');
    return;
  }

  fetch(`/hoteles?comunidad=${encodeURIComponent(comunidadAutonomas)}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar los hoteles por comunidad autónoma:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR DISPONIBILIDAD ----------------------------
function filtrarPorDisponibilidad() {
  const disponibilidad = document.getElementById('disponibilidad').value;

  if (disponibilidad === "") {
    mostrarError('Por favor, selecciona una opción de disponibilidad.');
    return;
  }

  fetch(`/hoteles?disponibilidad=${disponibilidad}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar por disponibilidad:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR PRECIO ----------------------------
function filtrarPorPrecio() {
  const precioMin = document.getElementById('precioMin').value.trim();
  const precioMax = document.getElementById('precioMax').value.trim();

  let url = '/hoteles?';
  if (precioMin) url += `precioMin=${encodeURIComponent(precioMin)}&`;
  if (precioMax) url += `precioMax=${encodeURIComponent(precioMax)}`;

  fetch(url)
    .then(response => response.json())
    .then(hoteles => {
      console.log("Hoteles filtrados por precio:", hoteles);
      mostrarHoteles(hoteles);
    })
    .catch(error => {
      console.error('Error al filtrar por precio:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR TIPO, COMUNIDAD Y PRECIO ----------------------------
function filtrarPorTipoComunidadYPrecio() {
  const tipoDeHotel = document.getElementById('tipoDeHotel').value.trim().toLowerCase();
  const comunidadAutonomas = document.getElementById('comunidad').value.trim().toLowerCase(); // El ID de comunidad es correcto aquí
  const precioMin = document.getElementById('precioMin').value.trim();
  const precioMax = document.getElementById('precioMax').value.trim();

  // Validar si al menos un campo está seleccionado
  if (!tipoDeHotel && !comunidadAutonomas && !precioMin && !precioMax) {
    mostrarError('Por favor, selecciona al menos un filtro.');
    return;
  }

  let url = '/hoteles?';

  // Añadir los filtros al URL si están seleccionados
  if (tipoDeHotel) url += `tipoDeHotel=${encodeURIComponent(tipoDeHotel)}&`;
  
  // Cambié de comunidadAutonomas a comunidad
  if (comunidadAutonomas) url += `comunidad=${encodeURIComponent(comunidadAutonomas)}&`; // Se cambia a "comunidad"
  
  if (precioMin) url += `precioMin=${encodeURIComponent(precioMin)}&`;
  if (precioMax) url += `precioMax=${encodeURIComponent(precioMax)}&`;

  console.log('URL de la solicitud:', url); // Para depurar y verificar la URL generada

  // Realizar la solicitud de filtrado
  fetch(url)
    .then(response => response.json())
    .then(hoteles => {
      console.log('Hoteles filtrados por Tipo, Comunidad y Precio:', hoteles); // DEBUG
      mostrarHoteles(hoteles);
    })
    .catch(error => {
      console.error('Error al filtrar los hoteles:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR FECHAS ----------------------------
function filtrarPorFecha() {
  const fechaEntrada = document.getElementById('fechaEntrada').value;
  const fechaSalida = document.getElementById('fechaSalida').value;

  // Validar que ambas fechas se seleccionen
  if (!fechaEntrada || !fechaSalida) {
    mostrarError('Por favor, selecciona una fecha de entrada y salida.');
    return;
  }

  // Convertir las fechas a objetos Date
  const entrada = new Date(fechaEntrada);
  const salida = new Date(fechaSalida);

  // Verificar que la fecha de entrada no sea posterior a la de salida
  if (entrada >= salida) {
    mostrarError('La fecha de entrada no puede ser posterior a la fecha de salida.');
    return;
  }

  // Filtrar los hoteles que estén disponibles en esas fechas
  fetch(`/hoteles?fechaEntrada=${fechaEntrada}&fechaSalida=${fechaSalida}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar por fechas:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR EXTRAS (ADULTOS, NIÑOS, HABITACIONES, MASCOTAS) ----------------------------
function filtrarPorExtras() {
  const numeroAdultos = document.getElementById('numeroAdultos').value;
  const numeroNinos = document.getElementById('numeroNinos').value;
  const numeroHabitaciones = document.getElementById('numeroHabitaciones').value;
  const llevoMascota = document.getElementById('llevoMascota').value;

  // Construir la URL con los parámetros de filtrado
  let url = '/hoteles?';

  if (numeroAdultos) url += `numeroAdultos=${encodeURIComponent(numeroAdultos)}&`;
  if (numeroNinos) url += `numeroNinos=${encodeURIComponent(numeroNinos)}&`;
  if (numeroHabitaciones) url += `numeroHabitaciones=${encodeURIComponent(numeroHabitaciones)}&`;
  if (llevoMascota) url += `llevoMascota=${encodeURIComponent(llevoMascota)}&`;

  // Hacer la petición al servidor para obtener los hoteles filtrados
  fetch(url)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar por extras:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}




//! CÓDIGO EXTRA
//! ---------------------------- CARGAR DATOS AL CARGAR LA PAGINA ----------------------------
document.addEventListener('DOMContentLoaded', () => {
  fetch('/hoteles')
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al cargar los hoteles:', error);
      mostrarError('Hubo un problema al cargar los hoteles.');
    });
});

//! ---------------------------- FUNCION MOSTRAR UN MENSAJE DE ERROR ----------------------------
function mostrarError(message) {
  const hotelesContainer = document.getElementById('hoteles');
  hotelesContainer.innerHTML = `<p style="color: red;">${message}</p>`;
}