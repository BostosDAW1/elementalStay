<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elemental-Stay</title>
    <link rel="stylesheet" href="./css/index.css">
    <link rel="stylesheet" href="./css/footer.css">
    <link rel="stylesheet" href="./css/header.css">
    <style>
        * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        font-family: Arial, Helvetica, sans-serif;
        }

        body {
        font-family: Arial, sans-serif;
        padding-top: 80px; /* Altura del nav para compensar su posición fija */

        }

        body::before {
        content: ""; /* Elemento vacío para el fondo */
        position: fixed; /* Cubre toda la pantalla */
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('../img/hotelPrincipal.jpg'); /* Imagen de fondo */
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        opacity: 0.2; /* Ajusta solo la opacidad de la imagen */
        z-index: -1; /* Coloca detrás del contenido */
        }


        /*****************************
        /*******************************
        /*********************************
        /* ----- SECCION DIV PRINCIPAL FOTO + FORMULARIO ----- */
        /*********************************
        /*******************************
        /*****************************/

        /* Contenedor principal con diseño flexible */
        .container {
        display: flex;
        justify-content: space-between;
        margin: 50px auto;
        max-width: 1300px;
        width: 100%;
        box-sizing: border-box;
        }

        /* Sección de la imagen */
        .text-section {
        flex: 1;
        padding: 20px;
        border-radius: 8px;
        position: relative;
        overflow: hidden;
        }

        .text-section img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        object-position: center;
        }

        /* Sección del formulario */
        .form-section {
        flex: 1;
        background-color: #ffffff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .form-section form {
        display: flex;
        flex-direction: column;
        gap: 15px;
        }

        /* Grupo de formularios */
        .form-group {
        display: flex;
        gap: 10px;
        }

        .form-group input {
        flex: 1;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        }

        .form-group.small input {
        flex: none;
        width: 48%;
        }

        .submit-button {
        padding: 10px 20px;
        background-color: #4caf50;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        align-self: flex-end;
        }

        .submit-button:hover {
        background-color: #45a049;
        }

        form {
        display: flex;
        flex-direction: column;
        gap: 20px;
        width: 100%;
        max-width: 600px;
        margin: 0 auto;
        }

        /* Estilos para el formulario y los inputs */
        .form-group {
        display: flex;
        flex-direction: column;
        gap: 8px;
        }

        label {
        font-size: 1rem;
        font-weight: bold;
        color: #333;
        margin-bottom: 5px;
        }

        /* Estilos para los inputs y selects */
        input[type="text"],
        input[type="date"],
        input[type="number"],
        input[type="checkbox"],
        textarea,
        select {
        width: 100%;
        padding: 12px;
        font-size: 1rem;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        transition: border-color 0.3s ease, background-color 0.3s ease;
        }

        input[type="checkbox"] {
        width: auto;
        margin-top: 5px;
        }

        select {
        width: 100%;
        padding: 12px;
        font-size: 1rem;
        border: 1px solid #ccc;
        border-radius: 4px;
        background-color: #fff;
        box-sizing: border-box;
        appearance: none;
        cursor: pointer;
        }

        select:focus {
        border-color: #4caf50;
        background-color: #f9f9f9;
        }

        select option {
        padding: 12px;
        background-color: #fff;
        color: #333;
        }

        .submit-button {
        padding: 10px 20px;
        background-color: #4caf50;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        align-self: flex-end;
        }

        .submit-button:hover {
        background-color: #45a049;
        }

        /* Estilos para el mensaje de los perros permitidos */
        .form-group p {
        font-size: 1rem;
        color: #333;
        margin: 10px 0;
        }

        .form-group strong {
        font-size: 1.2rem;
        font-weight: bold;
        color: #4caf50;
        }

        .form-group p:first-of-type {
        font-size: 1.1rem;
        font-weight: bold;
        color: #007bff;
        }

        button {
        background-color: #007bff;
        color: white;
        padding: 12px 20px;
        font-size: 1rem;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        align-self: flex-start;
        transition: background-color 0.3s ease;
        }

        button:hover {
        background-color: #0056b3;
        }

        p {
        font-size: 0.9rem;
        color: #666;
        margin-top: 5px;
        margin-bottom: 10px;
        }

        a {
        color: #007bff;
        text-decoration: none;
        }

        a:hover {
        text-decoration: underline;
        }

        /* Media Queries para pantallas más pequeñas */

        /* Para pantallas de tablet (máximo 768px) */
        @media (max-width: 768px) {
        .container {
        flex-direction: column;
        align-items: center;
        gap: 20px;
        }

        .text-section {
        display: none; /* Ocultamos la imagen */
        }

        .form-section {
        background-image: url('./img/hotelPrincipal2.jpg'); /* Aquí le pones la ruta de la imagen */
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        padding: 50px 20px; /* Espaciado extra para que la imagen de fondo no se vea cortada */
        }

        .form-section form {
        background-color: rgba(255, 255, 255, 0.8); /* Fondo semitransparente para el formulario */
        padding: 30px 20px; /* Ajustamos el padding */
        border-radius: 8px;
        }

        form {
        padding: 15px;
        }

        input[type="text"],
        input[type="date"],
        input[type="number"],
        input[type="checkbox"],
        select {
        padding: 10px;
        }

        .submit-button {
        width: 100%;
        }
        }







        /*****************************
        /*******************************
        /*********************************
        /* ----- CADENA DE TITULOS Y PROMOCIONES + GALERIA ----- */
        /*********************************
        /*******************************
        /*****************************/

        .tituloPromociones {
        text-align: center;
        font-size: clamp(28px, 5vw, 50px); /* Escala de forma flexible entre 28px y 50px según el ancho de la pantalla */
        color: white;
        margin-top: 10px; /* Margen reducido para pantallas pequeñas */
        }

        /* Contenedor para el texto */
        .chromatic-container {
        text-align: center;
        padding: 20px;
        background-color: rgba(0, 0, 0, 0.6); /* Fondo semitransparente para resaltar el texto */
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        margin: 20px auto; /* Centrado horizontal y margen vertical responsivo */
        width: min(90%, 1500px); /* Ocupa hasta el 90% del ancho de la pantalla, con un máximo de 1500px */
        height: auto; /* Ajusta automáticamente la altura según el contenido */
        background: linear-gradient(
        to right,
        rgb(239, 57, 6),
        green,
        rgb(10, 135, 218)
        ); /* Gradiente del espectro de colores */
        background-size: 300% 300%; /* Amplía el tamaño para un mejor efecto */
        animation: gradient-animation 25s linear infinite; /* Animación del gradiente */
        color: white;
        }

        .chromatic-container2 {
        text-align: center;
        padding: 20px;
        background-color: rgba(0, 0, 0, 0.6); /* Fondo semitransparente para resaltar el texto */
        border-radius: 10px;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.5);
        margin: 20px auto; /* Centrado horizontal y margen vertical responsivo */
        width: min(90%, 1500px); /* Ocupa hasta el 90% del ancho de la pantalla, con un máximo de 1500px */
        height: auto; /* Ajusta automáticamente la altura según el contenido */
        background: linear-gradient(
        to right,
        rgb(10, 135, 218),
        green,
        rgb(239, 57, 6)

        ); /* Gradiente del espectro de colores */
        background-size: 300% 300%; /* Amplía el tamaño para un mejor efecto */
        animation: gradient-animation 25s linear infinite; /* Animación del gradiente */
        color: white;
        }

        /* Animación del gradiente */
        @keyframes gradient-animation {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
        }

        /* Media Queries para optimizar en diferentes dispositivos */
        @media (max-width: 768px) {
        .chromatic-container {
        padding: 15px; /* Reducir el padding en pantallas pequeñas */
        border-radius: 8px; /* Bordes más sutiles */
        background-size: 400% 400%; /* Ajustar el tamaño del gradiente */
        }

        .chromatic-container2 {
        padding: 15px; /* Reducir el padding en pantallas pequeñas */
        border-radius: 8px; /* Bordes más sutiles */
        background-size: 400% 400%; /* Ajustar el tamaño del gradiente */
        }

        .tituloPromociones {
        font-size: clamp(20px, 6vw, 36px); /* Tamaño dinámico para títulos en pantallas pequeñas */
        }
        }

        @media (max-width: 480px) {
        .chromatic-container {
        padding: 10px; /* Más compacto para pantallas muy pequeñas */
        border-radius: 5px; /* Suavizar aún más los bordes */
        background-size: 500% 500%; /* Mayor efecto de gradiente */
        }

        .tituloPromociones {
        font-size: clamp(16px, 7vw, 28px); /* Tamaño aún más reducido para títulos */
        margin-top: 5px; /* Menor margen superior */
        }
        }

        /*****************************
        /*******************************
        /*********************************
        /* ----- ESTILOS DEL CARRUSEL ----- */
        /*********************************
        /*******************************
        /*****************************/

        .slideshow-container {
        max-width: 1500px;
        position: relative;
        margin: auto;
        margin-top: 20px;
        overflow: hidden; /* Asegura que las imágenes fuera de la caja no sean visibles */
        }

        .mySlides {
        display: none;
        width: 100%;
        }

        #imgCarrusel {
        width: 100%; /* Asegura que las imágenes se ajusten al ancho del contenedor */
        max-height: 500px; /* Ajusta la altura máxima de la imagen */
        object-fit: cover; /* Mantiene la relación de aspecto de la imagen */
        transition: transform 2s ease-in-out; /* Suaviza el cambio al entrar y salir */
        }

        /* Animación de deslizamiento */
        .slide {
        animation-name: slide;
        animation-duration: 2.5s; /* Duración mayor para una transición más suave */
        animation-timing-function: ease-in-out; /* Función de suavizado */
        }

        @keyframes slide {
        0% {
        transform: translateX(100%); /* Comienza fuera de la pantalla a la derecha */
        }
        50% {
        transform: translateX(0); /* Se desliza al centro */
        }
        100% {
        transform: translateX(-100%); /* Se desliza fuera de la pantalla a la izquierda */
        }
        }

        .text {
        color: #f2f2f2;
        font-size: 15px;
        padding: 8px 12px;
        position: absolute;
        bottom: 8px;
        width: 100%;
        text-align: center;
        background-color: rgba(0, 0, 0, 0.5); /* Fondo oscuro para mejorar visibilidad */
        border-radius: 5px; /* Bordes redondeados para el texto */
        }

        .numbertext {
        color: #f2f2f2;
        font-size: 12px;
        padding: 8px 12px;
        position: absolute;
        top: 0;
        }

        .prev, .next {
        cursor: pointer;
        position: absolute;
        top: 50%;
        width: auto;
        padding: 16px;
        margin-top: -22px;
        color: white;
        font-weight: bold;
        font-size: 18px;
        transition: background-color 0.3s ease-in-out; /* Suavizamos el cambio de fondo */
        border-radius: 0 3px 3px 0;
        background-color: rgba(0, 0, 0, 0.5); /* Fondo oscuro para los botones */
        }

        .next {
        right: 0;
        border-radius: 3px 0 0 3px;
        }

        .prev:hover, .next:hover {
        background-color: rgba(0, 0, 0, 0.8); /* Efecto más notorio al pasar el ratón */
        }

        /* Ajustes para dispositivos móviles */
        @media only screen and (max-width: 300px) {
        .prev, .next, .text { font-size: 11px; }
        img {
        max-height: 300px; /* Ajustamos la altura máxima en pantallas pequeñas */
        }
        }





    </style>
</head>
<body>

    <!------------------------ MENÚ DE LINKS ----------------------->
    <nav>
        <div class="logo">
            <img src="img/logo.png" alt="Logo">
            <h1 class="logo-title">ELEMENTAL STAY</h1>
        </div>
        <ul>
            <li><a href="index.php" id="boton-superior"><b>INICIO</b></a></li>
            <li><a href="./mvc/index.php?controlador=Hoteles&accion=listarHoteles" id="boton-superior"><b>HOTELES</b></a></li>
            <li><a href="contactos/contactos.php" id="boton-superior"><b>CONTACTO</b></a></li>
    

            <!-- Aquí verificamos si la sesión está activa -->
            <?php if (isset($_SESSION['usuario'])): ?>
                <!-- Mostrar 'PERFIL' si la sesión está activa -->
                <li class="profile">
                    <a href="javascript:void(0);" onclick="toggleProfileMenu(event)" id="profileButton"><b>PERFIL</b></a>
                    <!-- Menú desplegable de opciones de perfil -->
                    <div class="profile-menu" id="profileMenu">
                        <a href="./perfil/perfil.php">Ver Perfil</a>
                        <a href="./inicio_session/logout.php" class="logout">Cerrar Sesión</a>
                    </div>
                </li>
            <?php else: ?>
                <!-- Si no hay sesión activa, mostrar el botón de "Iniciar sesión" -->
                <li><a href="../mp10/inicio_session/inicio_session.php" id="boton-superior"><b>INICIAR SESIÓN</b></a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <!-- SCRIPT DEL DESPLEGABLE DEL PERIL -->
    <script>
        // Función para alternar la visibilidad del menú de perfil
        function toggleProfileMenu(event) {
            event.stopPropagation();  // Evita que el clic se propague a otras partes de la página
            var menu = document.getElementById('profileMenu');
            menu.classList.toggle('show');  // Alterna la clase 'show' para mostrar/ocultar el menú
        }

        // Cerrar el menú si se hace clic fuera de él
        window.onclick = function(event) {
            // Verificamos si el clic NO fue sobre el enlace 'PERFIL' ni el menú desplegable
            if (!event.target.matches('#profileButton') && !event.target.matches('.profile-menu') && !event.target.closest('.profile')) {
                var dropdowns = document.getElementsByClassName('profile-menu');
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');  // Oculta el menú
                    }
                }
            }
        }
    </script>





    <!-- -------------------------------------- CONTENEDOR PRINCIPAL DE BÚSQUEDA DE HOTELES --------------------------- -->
    <section>
    <div class="container">
        <!-- --------------- IMAGEN - SECCION CONTENEDOR PRINCIPAL ------------- -->
        <div class="text-section">
        <form action="../index.php?controlador=Hoteles&accion=buscarHoteles"
        method="GET">        

        </div>
        
        <!-- --------------------- FORMULARIO - SECCION CONTENEDOR PRINCIPAL ------------------- -->
        <div class="form-section">
        <form action="mvc/" method="GET">                <div class="form-group">
                    <label for="destino"><b>¿Adónde vas?</b></label>
                    <select name="destino" id="destino" required>
                        <option value="" disabled selected>Selecciona un destino</option>
                        <option value="Valencia">Valencia</option>
                        <option value="Madrid">Madrid</option>
                        <option value="Cantabria">Cantabria</option>
                    </select>
                </div>

                <!-- Campos de fecha debajo del destino -->
                <div class="form-group">
                    <label for="entrada"><b>Fecha de entrada</b></label>
                    <input type="date" id="entrada" name="entrada" required>
                </div>
            
                <div class="form-group">
                    <label for="salida"><b>Fecha de salida</b></label>
                    <input type="date" id="salida" name="salida" required>
                </div>
            
                <!-- Sección de selección de personas y habitaciones -->
                <div class="form-group">
                    <label><b>Adultos</b></label>
                    <input type="number" id="adultos" name="adultos" value="1" min="1">
                </div>
            
                <div class="form-group">
                    <label><b>Niños</b></label>
                    <input type="number" id="ninos" name="ninos" value="0" min="0">
                </div>
            
                <div class="form-group">
                    <label><b>Habitaciones</b></label>
                    <input type="number" id="habitaciones" name="habitaciones" value="1" min="1">
                </div>

                <!-- Mensaje sobre los perros permitidos en todas las habitaciones -->
                <div class="form-group">
                    <p><strong>¡Tu perro es bienvenido en todas nuestras habitaciones!</strong></p>
                    <p>En nuestros hoteles, creemos que tu mascota es parte de la familia. Por eso, permitimos perros en todas las habitaciones, para que disfrutes de tu estancia junto a tu compañero, sin costes extra.</p>
                </div>

                <button type="submit">Buscar</button>
            </form>
        </div>
    </div>
</section>






    <!------------------- CARRUSEL DE IMÁGENES DE PROMOCIONES -------------------->
    <section>
        <!------------------- Primer carrusel -------------------->
        <div class="chromatic-container">
            <h5 class="tituloPromociones">PROMOCIONES</h5>
        </div>
    
        <div class="slideshow-container" id="carrusel1">
            <div class="mySlides fade">
                <div class="numbertext">1 / 4</div>
                <img src="images/s1.jpg" style="width:100%" alt="imgCarrusel">
                <div class="text">Caption Text</div>
            </div>
    
            <div class="mySlides fade">
                <div class="numbertext">2 / 4</div>
                <img src="images/s2.jpg" style="width:100%" alt="imgCarrusel">
                <div class="text">Caption Two</div>
            </div>
    
            <div class="mySlides fade">
                <div class="numbertext">3 / 4</div>
                <img src="images/s3.jpg" style="width:100%" alt="imgCarrusel">
                <div class="text">Caption Three</div>
            </div>
    
            <div class="mySlides fade">
                <div class="numbertext">4 / 4</div>
                <img src="images/s4.jpg" style="width:100%" alt="imgCarrusel">
                <div class="text">Caption Four</div>
            </div>
    
            <a class="prev" onclick="plusSlides(-1, 'carrusel1')">❮</a>
            <a class="next" onclick="plusSlides(1, 'carrusel1')">❯</a>
        </div>
        <br>
        <br>
        <br>



        <!------------------- CARRUSEL DE ACTIVIDADES -------------------->
        <div class="chromatic-container2">
            <h5 class="tituloPromociones">ACTIVIDADES</h5>
        </div>
    
        <div class="slideshow-container" id="carrusel2">
            <div class="mySlides fade">
                <div class="numbertext">1 / 4</div>
                <img src="images/a5.jpeg" style="width:100%" alt="imgCarrusel">
                <div class="text">Caption Text</div>
            </div>
    
            <div class="mySlides fade">
                <div class="numbertext">2 / 4</div>
                <img src="images/a6.jpeg" style="width:100%" alt="imgCarrusel">
                <div class="text">Caption Two</div>
            </div>
    
            <div class="mySlides fade">
                <div class="numbertext">3 / 4</div>
                <img src="images/a7.jpeg" style="width:100%" alt="imgCarrusel">
                <div class="text">Caption Three</div>
            </div>
    
            <div class="mySlides fade">
                <div class="numbertext">4 / 4</div>
                <img src="images/a8.jpeg" style="width:100%" alt="imgCarrusel">
                <div class="text">Caption Four</div>
            </div>
    
            <a class="prev" onclick="plusSlides(-1, 'carrusel2')">❮</a>
            <a class="next" onclick="plusSlides(1, 'carrusel2')">❯</a>
        </div>
    </section>




    <!------------------------ FOOTER DE LA PESTAÑA --------------------- -->
    <footer>
        <div class="footer-container">

            <div class="footer-section">
                <h4>Sobre Nosotros</h4>
                <p>Elemental Stay es tu plataforma para encontrar los mejores alojamientos al mejor precio, con opciones personalizadas para cada tipo de viajero.</p>
            </div>

            <div class="footer-section">
                <h4>Enlaces Útiles</h4>
                <ul>
                    <li><a href="#">Inicio</a></li>
                    <li><a href="#">Acerca de</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li><a href="#">Términos y Condiciones</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h4>Síguenos</h4>
                <div class="social-icons">
                    <a href="#"><img src="icon-facebook.svg" alt="Facebook"></a>
                    <a href="#"><img src="icon-twitter.svg" alt="Twitter"></a>
                    <a href="#"><img src="icon-instagram.svg" alt="Instagram"></a>
                    <a href="#"><img src="icon-youtube.svg" alt="YouTube"></a>
                </div>
            </div>

        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2024 Elemental Stay. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script src="JS/Carrusel.js"></script>
    <script src="JS/Header.js"></script>

    
</body>
</html>