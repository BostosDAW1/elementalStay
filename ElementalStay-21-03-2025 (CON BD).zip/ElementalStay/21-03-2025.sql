-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: elementalStay
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.23.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias` (
  `id_categoria` int NOT NULL AUTO_INCREMENT,
  `nombre_categoria` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'deluxe'),(2,'estandar'),(3,'basica');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comunidades_autonomas`
--

DROP TABLE IF EXISTS `comunidades_autonomas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comunidades_autonomas` (
  `id_comunidad` int NOT NULL AUTO_INCREMENT,
  `comunidad_autonoma` varchar(75) NOT NULL,
  PRIMARY KEY (`id_comunidad`,`comunidad_autonoma`),
  UNIQUE KEY `comunidad_autonoma_UNIQUE` (`comunidad_autonoma`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comunidades_autonomas`
--

LOCK TABLES `comunidades_autonomas` WRITE;
/*!40000 ALTER TABLE `comunidades_autonomas` DISABLE KEYS */;
INSERT INTO `comunidades_autonomas` VALUES (2,'Cantabria'),(3,'Madrid'),(1,'Valencia');
/*!40000 ALTER TABLE `comunidades_autonomas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_pagos`
--

DROP TABLE IF EXISTS `detalle_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_pagos` (
  `id_detalle_pago` int NOT NULL AUTO_INCREMENT,
  `id_pago` int DEFAULT NULL,
  `descripcion` text,
  `id_hotel` int DEFAULT NULL,
  `id_servicio` int DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_detalle_pago`),
  KEY `fk_detalle_pagos_1_idx_new` (`total`),
  KEY `fk_detalle_pagos_1_idx` (`total`),
  KEY `fk_detalle_pagos_2_idx` (`id_pago`),
  KEY `fk_detalle_pagos_3_idx` (`id_hotel`),
  KEY `fk_detalle_pagos_4_idx` (`id_servicio`),
  CONSTRAINT `fk_detalle_pagos_1` FOREIGN KEY (`total`) REFERENCES `pagos` (`total_pago`),
  CONSTRAINT `fk_detalle_pagos_2` FOREIGN KEY (`id_pago`) REFERENCES `pagos` (`id_pago`),
  CONSTRAINT `fk_detalle_pagos_3` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`),
  CONSTRAINT `fk_detalle_pagos_4` FOREIGN KEY (`id_servicio`) REFERENCES `servicios` (`id_servicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_pagos`
--

LOCK TABLES `detalle_pagos` WRITE;
/*!40000 ALTER TABLE `detalle_pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `habitaciones`
--

DROP TABLE IF EXISTS `habitaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `habitaciones` (
  `id_habitacion` int NOT NULL,
  `id_hotel` int DEFAULT NULL,
  `id_categoria` int DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `capacidad` int DEFAULT NULL,
  `m2` varchar(45) DEFAULT NULL,
  `wifi` tinyint DEFAULT NULL,
  `comunidadAutonoma` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_habitacion`),
  KEY `fk_habitacions_1_idx` (`id_hotel`),
  KEY `fk_habitaciones_2_idx` (`comunidadAutonoma`),
  KEY `fk_habitaciones_1_idx` (`id_categoria`),
  CONSTRAINT `fk_habitaciones_1` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`),
  CONSTRAINT `fk_habitaciones_2` FOREIGN KEY (`comunidadAutonoma`) REFERENCES `hoteles` (`comunidad_autonoma`),
  CONSTRAINT `fk_habitacions_1` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `habitaciones`
--

LOCK TABLES `habitaciones` WRITE;
/*!40000 ALTER TABLE `habitaciones` DISABLE KEYS */;
INSERT INTO `habitaciones` VALUES (1,1,2,'Habitación Vista Mar',2,'25',1,'Valencia'),(2,1,2,'Suite Familiar',5,'40',1,'Valencia'),(3,1,1,'Habitación Doble Deluxe',2,'30',1,'Valencia'),(4,1,3,'Habitación Triple',3,'35',1,'Valencia'),(5,1,3,'Habitación Individual',1,'20',1,'Valencia'),(6,2,2,'Habitación Estándar',2,'28',1,'Valencia'),(7,2,3,'Suite con Terraza',2,'45',1,'Valencia'),(8,2,3,'Habitación Familiar',3,'32',1,'Valencia'),(9,2,2,'Habitación Doble Superior',2,'30',1,'Valencia'),(10,2,1,'Habitación Individual Económica',2,'18',0,'Valencia'),(16,3,3,'Habitación Vista al Mar',2,'26',1,'Valencia'),(17,3,3,'Suite Ejecutiva',4,'48',1,'Valencia'),(18,3,1,'Habitación Doble Premium',2,'30',1,'Valencia'),(19,3,2,'Habitación Triple Confort',3,'36',1,'Valencia'),(20,3,2,'Habitación Individual Superior',1,'22',0,'Valencia'),(21,4,1,'Habitación Familiar Deluxe',4,'40',1,'Valencia'),(22,4,3,'Suite con Jacuzzi',2,'35',1,'Valencia'),(23,4,2,'Habitación Doble Estándar',2,'28',0,'Valencia'),(24,4,2,'Habitación Triple Familiar',3,'32',1,'Valencia'),(25,4,3,'Habitación Individual Económica',1,'18',0,'Valencia'),(26,5,3,'Habitación Doble Vista Jardín',2,'30',1,'Valencia'),(27,5,2,'Suite Familiar con Terraza',4,'45',1,'Valencia'),(28,5,3,'Habitación Individual Confort',1,'20',0,'Valencia'),(29,5,2,'Habitación Triple Estándar',3,'35',1,'Valencia'),(30,5,1,'Habitación Doble Superior',2,'28',1,'Valencia'),(31,6,2,'Habitación Deluxe con Balcón',2,'32',1,'Cantabria'),(32,6,2,'Suite Ejecutiva con Vista',2,'50',1,'Cantabria'),(33,6,3,'Habitación Doble Clásica',2,'29',0,'Cantabria'),(34,6,1,'Habitación Familiar Espaciosa',3,'40',1,'Cantabria'),(35,6,3,'Habitación Individual Económica',2,'18',0,'Cantabria'),(36,7,3,'Habitación Doble con Vista al Lago',2,'30',1,'Cantabria'),(37,7,2,'Suite Familiar con Balcón',4,'48',1,'Cantabria'),(38,7,3,'Habitación Individual Clásica',1,'22',0,'Cantabria'),(39,7,2,'Habitación Triple Confortable',3,'35',1,'Cantabria'),(40,7,1,'Habitación Doble Superior con Jacuzzi',2,'32',1,'Cantabria'),(41,8,2,'Habitación Estándar con Terraza',2,'28',1,'Cantabria'),(42,8,1,'Suite de Lujo',4,'50',1,'Cantabria'),(43,8,2,'Habitación Doble Premium',2,'30',0,'Cantabria'),(44,8,3,'Habitación Familiar Espaciosa',3,'40',1,'Cantabria'),(45,8,3,'Habitación Individual Económica',1,'18',0,'Cantabria'),(49,9,3,'Habitación Familiar Deluxe',4,'42',1,'Cantabria'),(50,9,2,'Habitación Doble Estándar',2,'28',0,'Cantabria'),(51,9,3,'Suite con Vista al Lago',3,'45',1,'Cantabria'),(52,9,2,'Habitación Individual Superior',1,'22',0,'Cantabria'),(53,9,1,'Habitación Doble Premium',2,'30',1,'Cantabria'),(59,10,3,'Habitación Doble con Vista al Jardín',2,'30',1,'Cantabria'),(60,10,3,'Suite Ejecutiva con Terraza',4,'55',1,'Cantabria'),(61,10,2,'Habitación Doble Estándar',2,'28',0,'Cantabria'),(62,10,1,'Habitación Familiar Deluxe',3,'40',1,'Cantabria'),(63,10,2,'Habitación Individual Confortable',1,'22',0,'Cantabria'),(69,11,3,'Habitación Doble con Vista al Mar',2,'30',1,'Madrid'),(70,11,1,'Suite Familiar con Balcón',2,'55',1,'Madrid'),(71,11,2,'Habitación Doble Estándar',2,'28',0,'Madrid'),(72,11,2,'Habitación Triple Confortable',3,'40',1,'Madrid'),(73,11,3,'Habitación Individual Clásica',1,'22',0,'Madrid'),(74,12,2,'Habitación Doble Superior',2,'35',1,'Madrid'),(75,12,1,'Suite de Lujo',4,'60',1,'Madrid'),(76,12,2,'Habitación Doble Estándar',2,'28',0,'Madrid'),(77,12,3,'Habitación Familiar Espaciosa',4,'45',1,'Madrid'),(78,12,3,'Habitación Individual Económica',1,'20',0,'Madrid'),(79,13,3,'Habitación Doble con Vista al Jardín',2,'30',1,'Madrid'),(80,13,1,'Suite Familiar con Terraza',4,'55',1,'Madrid'),(81,13,3,'Habitación Doble Clásica',2,'28',0,'Madrid'),(82,13,2,'Habitación Triple Confortable',3,'40',1,'Madrid'),(83,13,2,'Habitación Individual Estándar',1,'22',0,'Madrid'),(84,14,1,'Habitación Doble Deluxe',2,'38',1,'Madrid'),(85,14,3,'Suite Ejecutiva',4,'65',1,'Madrid'),(86,14,2,'Habitación Doble Estándar',2,'30',0,'Madrid'),(87,14,3,'Habitación Familiar con Vista',4,'50',1,'Madrid'),(88,14,2,'Habitación Individual Confortable',1,'25',0,'Madrid'),(89,15,2,'Habitación Doble con Balcón',2,'32',1,'Madrid'),(90,15,1,'Suite de Lujo con Jacuzzi',2,'70',1,'Madrid'),(91,15,2,'Habitación Doble Clásica',2,'28',0,'Madrid'),(92,15,2,'Habitación Familiar Espaciosa',4,'48',1,'Madrid'),(93,15,3,'Habitación Individual Económica',1,'22',0,'Madrid');
/*!40000 ALTER TABLE `habitaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoteles`
--

DROP TABLE IF EXISTS `hoteles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hoteles` (
  `id_hotel` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `tipo_hotel` varchar(25) DEFAULT NULL,
  `comunidad_autonoma` varchar(75) DEFAULT NULL,
  `descripcion` text,
  `precio_noche` int DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_hotel`),
  UNIQUE KEY `idx_nombre_hotel` (`nombre`),
  KEY `fk_hoteles_1_idx` (`tipo_hotel`),
  KEY `fk_hoteles_2_idx` (`comunidad_autonoma`),
  CONSTRAINT `fk_hoteles_1` FOREIGN KEY (`tipo_hotel`) REFERENCES `tipo_hotel` (`tipo_hotel`),
  CONSTRAINT `fk_hoteles_2` FOREIGN KEY (`comunidad_autonoma`) REFERENCES `comunidades_autonomas` (`comunidad_autonoma`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoteles`
--

LOCK TABLES `hoteles` WRITE;
/*!40000 ALTER TABLE `hoteles` DISABLE KEYS */;
INSERT INTO `hoteles` VALUES (1,'Hotel Playa Valencia','playa','Valencia','Un elegante hotel frente al mar con vistas impresionantes y acceso directo a la playa.',115,'img/playa/img1.jpg'),(2,'Hotel Sol y Mar','playa','Valencia','Hotel moderno con piscina y restaurante gourmet, ideal para disfrutar del sol y la arena.',120,'img/playa/img2.jpg'),(3,'Hotel Mediterráneo','playa','Valencia','Ubicado en primera línea de playa, ofrece habitaciones con terraza y espectaculares puestas de sol.',125,'img/playa/img3.jpg'),(4,'Hotel Costa Azul','playa','Valencia','Hotel familiar con múltiples actividades acuáticas y servicio todo incluido.',118,'img/playa/img4.jpg'),(5,'Hotel Playa Dorada','playa','Valencia','Un refugio de lujo con spa y acceso a las mejores playas de Valencia.',122,'img/playa/img5.jpg'),(6,'Hotel Montaña Cantabria','montaña','Cantabria','Un acogedor hotel de montaña rodeado de naturaleza y rutas de senderismo.',98,'img/montaña/img1.jpg'),(7,'Hotel Picos de Europa','montaña','Cantabria','Ubicado en los Picos de Europa, este hotel ofrece vistas panorámicas y ambiente rústico.',102,'img/montaña/img2.jpg'),(8,'Hotel Valle de Liébana','montaña','Cantabria','Hotel rural con encanto, ideal para desconectar y disfrutar del aire puro de Cantabria.',100,'img/montaña/img3.jpg'),(9,'Hotel Cabañas del Bosque','montaña','Cantabria','Cabañas de madera en plena montaña, perfectas para una escapada en la naturaleza.',95,'img/montaña/img4.jpg'),(10,'Hotel Mirador de la Montaña','montaña','Cantabria','Hotel con un mirador espectacular y chimeneas en cada habitación para una experiencia acogedora.',105,'img/montaña/img5.jpg'),(11,'Hotel Ciudad Madrid','ciudad','Madrid','Moderno hotel en el centro de Madrid, con fácil acceso a las principales atracciones turísticas.',135,'img/ciudad/img1.jpg'),(12,'Hotel Gran Vía','ciudad','Madrid','Ubicado en la Gran Vía, este hotel ofrece lujo y comodidad en el corazón de la ciudad.',140,'img/ciudad/img2.jpg'),(13,'Hotel Plaza Mayor','ciudad','Madrid','A pocos metros de la Plaza Mayor, ideal para explorar la historia y cultura madrileña.',145,'img/ciudad/img3.jpg'),(14,'Hotel Retiro','ciudad','Madrid','Frente al Parque del Retiro, combina naturaleza y cercanía a la zona cultural de Madrid.',138,'img/ciudad/img4.jpg'),(15,'Hotel Centro Histórico','ciudad','Madrid','Situado en el casco histórico, con una arquitectura clásica y un ambiente sofisticado.',142,'img/ciudad/img5.jpg');
/*!40000 ALTER TABLE `hoteles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opiniones`
--

DROP TABLE IF EXISTS `opiniones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opiniones` (
  `id_opinion` int NOT NULL AUTO_INCREMENT,
  `id_hotel` int DEFAULT NULL,
  `id_usuario` int DEFAULT NULL,
  `calificacion` int DEFAULT NULL,
  `comentario` text,
  `fecha_opinion` date DEFAULT NULL,
  PRIMARY KEY (`id_opinion`),
  KEY `fk_opiniones_1_idx` (`id_hotel`),
  KEY `fk_opiniones_2_idx` (`id_usuario`),
  CONSTRAINT `fk_opiniones_1` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`),
  CONSTRAINT `fk_opiniones_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opiniones`
--

LOCK TABLES `opiniones` WRITE;
/*!40000 ALTER TABLE `opiniones` DISABLE KEYS */;
/*!40000 ALTER TABLE `opiniones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos` (
  `id_pago` int NOT NULL AUTO_INCREMENT,
  `metodo_pago` varchar(45) DEFAULT NULL,
  `total_pago` decimal(10,2) DEFAULT NULL,
  `fecha_pago` datetime DEFAULT NULL,
  PRIMARY KEY (`id_pago`),
  UNIQUE KEY `idx_total_pago` (`total_pago`),
  KEY `fk_pagos_1_idx_new` (`metodo_pago`),
  KEY `fk_pagos_1_idx` (`metodo_pago`),
  CONSTRAINT `fk_pagos_1` FOREIGN KEY (`metodo_pago`) REFERENCES `tipos_pagos` (`metodo_pago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paises_usuario`
--

DROP TABLE IF EXISTS `paises_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paises_usuario` (
  `id_pais` int NOT NULL AUTO_INCREMENT,
  `pais` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id_pais`),
  UNIQUE KEY `pais_UNIQUE` (`pais`)
) ENGINE=InnoDB AUTO_INCREMENT=371 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paises_usuario`
--

LOCK TABLES `paises_usuario` WRITE;
/*!40000 ALTER TABLE `paises_usuario` DISABLE KEYS */;
INSERT INTO `paises_usuario` VALUES (187,'Afganistán'),(188,'Albania'),(189,'Alemania'),(190,'Andorra'),(191,'Angola'),(192,'Antigua y Barbuda'),(193,'Arabia Saudita'),(194,'Armenia'),(195,'Australia'),(196,'Austria'),(197,'Azerbaiyán'),(198,'Bahamas'),(199,'Bahrein'),(200,'Bangladés'),(201,'Barbados'),(202,'Baréin'),(203,'Bélgica'),(204,'Belice'),(205,'Benín'),(206,'Bielorrusia'),(207,'Birmania'),(208,'Bolivia'),(209,'Bosnia y Herzegovina'),(210,'Botsuana'),(211,'Brasil'),(212,'Brunéi'),(213,'Bulgaria'),(214,'Burkina Faso'),(215,'Burundi'),(216,'Cabo Verde'),(217,'Camboya'),(218,'Camerún'),(219,'Canadá'),(220,'Catar'),(221,'Chile'),(222,'China'),(223,'Chipre'),(224,'Colombia'),(225,'Comoras'),(226,'Congo'),(227,'Corea del Norte'),(228,'Corea del Sur'),(229,'Costa Rica'),(230,'Croacia'),(231,'Cuba'),(232,'Curazao'),(233,'Dinamarca'),(234,'Dominica'),(235,'Ecuador'),(236,'Egipto'),(237,'El Salvador'),(238,'Emiratos Árabes Unidos'),(239,'Eslovaquia'),(240,'Eslovenia'),(241,'España'),(242,'Estados Unidos'),(243,'Estonia'),(244,'Etiopía'),(245,'Filipinas'),(246,'Finlandia'),(247,'Fiyi'),(248,'Francia'),(249,'Gabón'),(250,'Gambia'),(251,'Gana'),(252,'Granada'),(253,'Grecia'),(254,'Guatemala'),(255,'Guinea'),(256,'Guinea Ecuatorial'),(257,'Guinea-Bisáu'),(258,'Guyana'),(259,'Haití'),(260,'Honduras'),(261,'Hungría'),(262,'India'),(263,'Indonesia'),(264,'Irak'),(265,'Irán'),(266,'Irlanda'),(267,'Islandia'),(268,'Islas Marshall'),(269,'Islas Salomón'),(270,'Israel'),(271,'Italia'),(272,'Jamaica'),(273,'Japón'),(274,'Jordania'),(275,'Kazajistán'),(276,'Kenia'),(277,'Kirguistán'),(278,'Kiribati'),(279,'Kuwait'),(280,'Laos'),(281,'Lesoto'),(282,'Letonia'),(283,'Líbano'),(284,'Liberia'),(285,'Libia'),(286,'Liechtenstein'),(287,'Lituania'),(288,'Luxemburgo'),(289,'Madagascar'),(290,'Malasia'),(291,'Malaui'),(292,'Maldivas'),(293,'Malí'),(294,'Malta'),(295,'Marruecos'),(296,'Mauricio'),(297,'Mauritania'),(298,'México'),(299,'Micronesia'),(300,'Moldavia'),(301,'Mónaco'),(302,'Mongolia'),(303,'Montenegro'),(304,'Mozambique'),(305,'Namibia'),(306,'Nauru'),(307,'Nepal'),(308,'Nicaragua'),(309,'Níger'),(310,'Nigeria'),(311,'Noruega'),(312,'Nueva Zelanda'),(313,'Omán'),(314,'Pakistán'),(315,'Palaos'),(316,'Panamá'),(317,'Papúa Nueva Guinea'),(318,'Paraguay'),(319,'Perú'),(320,'Polonia'),(321,'Portugal'),(322,'Reino Unido'),(323,'República Checa'),(324,'República Dominicana'),(325,'Ruanda'),(326,'Rumanía'),(327,'Samoa'),(328,'San Cristóbal y Nieves'),(329,'San Marino'),(330,'San Vicente y las Granadinas'),(331,'Santa Lucía'),(332,'Santo Tomé y Príncipe'),(333,'Senegal'),(334,'Serbia'),(335,'Seychelles'),(336,'Sierra Leona'),(337,'Singapur'),(338,'Siria'),(339,'Somalia'),(340,'Sri Lanka'),(341,'Sudáfrica'),(342,'Sudán'),(343,'Sudán del Sur'),(344,'Suecia'),(345,'Suiza'),(346,'Surinam'),(347,'Svajilandia'),(348,'Tailandia'),(349,'Tanzania'),(350,'Tayikistán'),(351,'Timor Oriental'),(352,'Togo'),(353,'Tonga'),(354,'Trinidad y Tobago'),(355,'Túnez'),(356,'Turkmenistán'),(357,'Turquía'),(358,'Tuvalu'),(360,'Ucrania'),(359,'Uganda'),(361,'Uruguay'),(362,'Uzbekistán'),(363,'Vanuatu'),(364,'Vaticano'),(365,'Venezuela'),(366,'Vietnam'),(367,'Yemen'),(368,'Yibuti'),(369,'Zambia'),(370,'Zimbabue');
/*!40000 ALTER TABLE `paises_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promociones`
--

DROP TABLE IF EXISTS `promociones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promociones` (
  `id_promocion` int NOT NULL AUTO_INCREMENT,
  `id_servicio` int DEFAULT NULL,
  `id_hotel` varchar(45) DEFAULT NULL,
  `descripcion` text,
  `fecha_inicio` datetime DEFAULT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `descuento` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id_promocion`),
  KEY `fk_promociones_1_idx` (`id_servicio`),
  KEY `fk_promociones_2_idx` (`id_hotel`),
  CONSTRAINT `fk_promociones_1` FOREIGN KEY (`id_servicio`) REFERENCES `servicios` (`id_servicio`),
  CONSTRAINT `fk_promociones_2` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promociones`
--

LOCK TABLES `promociones` WRITE;
/*!40000 ALTER TABLE `promociones` DISABLE KEYS */;
/*!40000 ALTER TABLE `promociones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservas`
--

DROP TABLE IF EXISTS `reservas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservas` (
  `id_reserva` int NOT NULL AUTO_INCREMENT,
  `id_hotel` int DEFAULT NULL,
  `id_habitacion` int DEFAULT NULL,
  `id_usuario` int DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `dia_entrada` datetime DEFAULT NULL,
  `dia_salida` datetime DEFAULT NULL,
  `plaza_coche_parking` tinyint DEFAULT NULL,
  PRIMARY KEY (`id_reserva`),
  KEY `fk_reservas_2_idx` (`id_hotel`),
  KEY `fk_reservas_1_idx` (`id_usuario`),
  KEY `fk_reservas_3_idx` (`id_habitacion`),
  CONSTRAINT `fk_reservas_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`),
  CONSTRAINT `fk_reservas_2` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`),
  CONSTRAINT `fk_reservas_3` FOREIGN KEY (`id_habitacion`) REFERENCES `habitaciones` (`id_habitacion`)
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservas`
--

LOCK TABLES `reservas` WRITE;
/*!40000 ALTER TABLE `reservas` DISABLE KEYS */;
INSERT INTO `reservas` VALUES (101,1,1,37,230.50,'2025-04-01 14:00:00','2025-04-07 11:00:00',1),(102,2,6,38,240.00,'2025-05-15 15:00:00','2025-05-20 10:00:00',0),(103,3,16,37,300.00,'2025-06-01 16:00:00','2025-06-10 12:00:00',1),(104,4,21,38,180.75,'2025-07-05 12:00:00','2025-07-10 11:00:00',0),(105,5,26,37,275.00,'2025-08-10 13:00:00','2025-08-15 10:00:00',1),(106,6,31,38,120.50,'2025-09-01 14:30:00','2025-09-07 11:00:00',0),(107,7,36,37,150.75,'2025-10-01 15:00:00','2025-10-05 12:00:00',1),(108,8,41,38,200.00,'2025-11-01 16:00:00','2025-11-10 11:00:00',0),(109,9,49,37,180.00,'2025-12-10 14:00:00','2025-12-15 10:00:00',1),(110,10,59,38,220.00,'2025-01-01 13:00:00','2025-01-07 12:00:00',0),(111,11,69,37,340.00,'2025-02-05 16:00:00','2025-02-10 10:00:00',1),(112,12,74,38,190.25,'2025-03-01 14:00:00','2025-03-10 12:00:00',0),(113,13,79,37,145.00,'2025-04-10 15:30:00','2025-04-15 11:00:00',1),(114,14,84,38,210.50,'2025-05-20 14:00:00','2025-05-25 11:00:00',0),(115,15,89,37,120.00,'2025-06-15 13:30:00','2025-06-20 10:00:00',1),(117,1,2,37,150.00,'2026-06-10 00:00:00','2026-06-15 00:00:00',1);
/*!40000 ALTER TABLE `reservas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservashab`
--

DROP TABLE IF EXISTS `reservashab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservashab` (
  `idreservashab` int NOT NULL AUTO_INCREMENT,
  `idhotel` int NOT NULL,
  `idhabitacion` int NOT NULL,
  `nombrehab` varchar(30) DEFAULT NULL,
  `capacidad` int DEFAULT NULL,
  `mascota` tinyint DEFAULT NULL,
  PRIMARY KEY (`idreservashab`,`idhotel`,`idhabitacion`),
  KEY `fk_reservashab_1_idx` (`idhotel`),
  KEY `fk_reservashab_2_idx` (`idhabitacion`),
  CONSTRAINT `fk_reservashab_1` FOREIGN KEY (`idhotel`) REFERENCES `reservas` (`id_hotel`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservashab`
--

LOCK TABLES `reservashab` WRITE;
/*!40000 ALTER TABLE `reservashab` DISABLE KEYS */;
INSERT INTO `reservashab` VALUES (1,1,1,'Habitación Deluxe',2,1),(2,1,2,'Habitación Standard',2,0),(3,1,3,'Habitación Familiar',4,1),(4,1,4,'Habitación Suite',3,0),(5,1,5,'Habitación Individual',1,0),(6,2,1,'Habitación Premium',2,1),(7,2,2,'Habitación Vista Mar',2,0),(8,2,3,'Habitación Familiar',4,1),(9,2,4,'Habitación Confort',3,0),(10,2,5,'Habitación Doble',2,1),(11,3,1,'Habitación Executive',2,0),(12,3,2,'Habitación Marítima',2,1),(13,3,3,'Habitación Vista Montaña',4,0),(14,3,4,'Habitación Confort',3,1),(15,3,5,'Habitación Standard',1,0),(16,4,1,'Habitación Junior Suite',2,1),(17,4,2,'Habitación Simple',1,0),(18,4,3,'Habitación Familiar',4,1),(19,4,4,'Habitación Premium',2,0),(20,4,5,'Habitación Triple',3,1),(21,5,1,'Habitación Superior',2,0),(22,5,2,'Habitación Doble',2,1),(23,5,3,'Habitación Junior',3,0),(24,5,4,'Habitación King Size',2,1),(25,5,5,'Habitación Estándar',1,0);
/*!40000 ALTER TABLE `reservashab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservasservicios`
--

DROP TABLE IF EXISTS `reservasservicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservasservicios` (
  `idreservasservicios` int NOT NULL AUTO_INCREMENT,
  `idHotel` int NOT NULL,
  `idReserva` int NOT NULL,
  `idServicio` int DEFAULT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `cantidad` int DEFAULT NULL,
  PRIMARY KEY (`idreservasservicios`,`idHotel`,`idReserva`),
  KEY `fk_reservasservicios_1_idx` (`idReserva`),
  KEY `fk_reservasservicios_2_idx` (`idHotel`),
  KEY `fk_reservasservicios_3_idx` (`idServicio`),
  CONSTRAINT `fk_reservasservicios_1` FOREIGN KEY (`idReserva`) REFERENCES `reservas` (`id_reserva`),
  CONSTRAINT `fk_reservasservicios_2` FOREIGN KEY (`idHotel`) REFERENCES `hoteles` (`id_hotel`),
  CONSTRAINT `fk_reservasservicios_3` FOREIGN KEY (`idServicio`) REFERENCES `servicios` (`id_servicio`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservasservicios`
--

LOCK TABLES `reservasservicios` WRITE;
/*!40000 ALTER TABLE `reservasservicios` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservasservicios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicios`
--

DROP TABLE IF EXISTS `servicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicios` (
  `id_servicio` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `nombre_hotel` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_servicio`),
  KEY `fk_servicios_1_idx_new` (`nombre_hotel`),
  KEY `fk_servicios_1_idx` (`nombre_hotel`),
  CONSTRAINT `fk_servicios_1` FOREIGN KEY (`nombre_hotel`) REFERENCES `hoteles` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicios`
--

LOCK TABLES `servicios` WRITE;
/*!40000 ALTER TABLE `servicios` DISABLE KEYS */;
INSERT INTO `servicios` VALUES (10,'WiFi gratuito','Hotel Playa Valencia'),(11,'Desayuno incluido','Hotel Playa Valencia'),(12,'Servicio de limpieza diario','Hotel Playa Valencia'),(13,'Piscina exterior','Hotel Sol y Mar'),(14,'Spa y bienestar','Hotel Sol y Mar'),(15,'Restaurante con vista al mar','Hotel Sol y Mar'),(16,'Actividades acuáticas','Hotel Sol y Mar'),(17,'WiFi gratuito','Hotel Mediterráneo'),(18,'Desayuno buffet','Hotel Mediterráneo'),(19,'Acceso directo a la playa','Hotel Mediterráneo'),(20,'Restaurante gourmet','Hotel Costa Azul'),(21,'Bar en la piscina','Hotel Costa Azul'),(22,'Servicio de transporte al aeropuerto','Hotel Costa Azul'),(23,'Actividades recreativas','Hotel Costa Azul'),(24,'WiFi gratuito','Hotel Playa Dorada'),(25,'Club infantil','Hotel Playa Dorada'),(26,'Actividades deportivas en la playa','Hotel Playa Dorada'),(27,'Bar en la playa','Hotel Playa Dorada'),(28,'Senderismo guiado','Hotel Montaña Cantabria'),(29,'Desayuno típico de la región','Hotel Montaña Cantabria'),(30,'Alquiler de bicicletas','Hotel Montaña Cantabria'),(31,'Zona de spa y relajación','Hotel Montaña Cantabria'),(32,'Excursiones a la montaña','Hotel Picos de Europa'),(33,'Restaurante con comida local','Hotel Picos de Europa'),(34,'Guías turísticos disponibles','Hotel Picos de Europa'),(35,'Catas de vino','Hotel Valle de Liébana'),(36,'Senderismo y rutas naturales','Hotel Valle de Liébana'),(37,'Zona de juegos para niños','Hotel Valle de Liébana'),(38,'Cabañas privadas en la naturaleza','Hotel Cabañas del Bosque'),(39,'Actividades al aire libre','Hotel Cabañas del Bosque'),(40,'Barbacoa y picnic en el bosque','Hotel Cabañas del Bosque'),(41,'Vistas panorámicas','Hotel Mirador de la Montaña'),(42,'Senderismo guiado','Hotel Mirador de la Montaña'),(43,'Restaurante con cocina regional','Hotel Mirador de la Montaña'),(44,'WiFi gratuito en todo el hotel','Hotel Ciudad Madrid'),(45,'Centro de negocios','Hotel Ciudad Madrid'),(46,'Servicio de habitaciones 24 horas','Hotel Ciudad Madrid'),(47,'Gimnasio equipado','Hotel Ciudad Madrid'),(48,'Ubicación céntrica','Hotel Gran Vía'),(49,'Terraza en la azotea','Hotel Gran Vía'),(50,'Bar y lounge','Hotel Gran Vía'),(51,'Desayuno continental incluido','Hotel Gran Vía'),(52,'Ubicación en el corazón de la ciudad','Hotel Plaza Mayor'),(53,'Desayuno buffet','Hotel Plaza Mayor'),(54,'Recepción 24 horas','Hotel Plaza Mayor'),(55,'Servicio de transporte al aeropuerto','Hotel Plaza Mayor'),(56,'Jardín privado','Hotel Retiro'),(57,'Spa y wellness','Hotel Retiro'),(58,'Alquiler de bicicletas','Hotel Retiro'),(59,'Restaurante gourmet','Hotel Retiro'),(60,'Visitas guiadas a monumentos cercanos','Hotel Centro Histórico'),(61,'WiFi gratuito en áreas comunes','Hotel Centro Histórico'),(62,'Cafetería y bar','Hotel Centro Histórico'),(63,'Servicio de lavandería','Hotel Centro Histórico');
/*!40000 ALTER TABLE `servicios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tarifas`
--

DROP TABLE IF EXISTS `tarifas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tarifas` (
  `id_tarifa` int NOT NULL AUTO_INCREMENT,
  `id_hotel` int NOT NULL,
  `id_categoria` int NOT NULL,
  `id_temporada` int NOT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_tarifa`,`id_hotel`,`id_categoria`,`id_temporada`),
  KEY `fk_tarifas_1_idx` (`id_hotel`),
  KEY `fk_tarifas_2_idx` (`id_categoria`),
  KEY `fk_tarifas_3_idx` (`id_temporada`),
  CONSTRAINT `fk_tarifas_1` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`),
  CONSTRAINT `fk_tarifas_2` FOREIGN KEY (`id_categoria`) REFERENCES `categorias` (`id_categoria`),
  CONSTRAINT `fk_tarifas_3` FOREIGN KEY (`id_temporada`) REFERENCES `temporadas` (`id_temporada`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarifas`
--

LOCK TABLES `tarifas` WRITE;
/*!40000 ALTER TABLE `tarifas` DISABLE KEYS */;
INSERT INTO `tarifas` VALUES (1,1,1,1,99.00),(2,1,1,2,59.00),(3,1,2,1,89.00),(4,1,2,2,69.00),(5,1,3,1,79.00),(6,1,3,2,49.00),(7,2,1,3,99.00),(8,2,1,4,59.00),(9,2,2,3,89.00),(10,2,2,4,69.00),(11,2,3,3,79.00),(12,2,3,4,49.00),(13,3,1,5,99.00),(14,3,1,6,59.00),(15,3,2,5,89.00),(16,3,2,6,69.00),(17,3,3,5,79.00),(18,3,3,6,49.00),(19,4,1,7,99.00),(20,4,1,8,59.00),(21,4,2,7,89.00),(22,4,2,8,69.00),(23,4,3,7,79.00),(24,4,3,8,49.00),(25,5,1,9,99.00),(26,5,1,10,59.00),(27,5,2,9,89.00),(28,5,2,10,69.00),(29,5,3,9,79.00),(30,5,3,10,49.00),(31,6,1,11,89.00),(32,6,1,12,59.00),(33,6,2,11,79.00),(34,6,2,12,49.00),(35,6,3,11,69.00),(36,6,3,12,39.00),(43,7,1,13,89.00),(44,7,1,14,59.00),(45,7,2,13,79.00),(46,7,2,14,49.00),(47,7,3,13,69.00),(48,7,3,14,39.00),(49,8,1,15,89.00),(50,8,1,16,59.00),(51,8,2,15,79.00),(52,8,2,16,49.00),(53,8,3,15,69.00),(54,8,3,16,39.00),(55,9,1,17,89.00),(56,9,1,18,59.00),(57,9,2,17,79.00),(58,9,2,18,49.00),(59,9,3,17,69.00),(60,9,3,18,39.00),(61,10,1,19,89.00),(62,10,1,20,59.00),(63,10,2,19,79.00),(64,10,2,20,49.00),(65,10,3,19,69.00),(66,10,3,20,39.00),(67,11,1,21,109.00),(68,11,1,22,69.00),(69,11,2,21,99.00),(70,11,2,22,59.00),(71,11,3,21,89.00),(72,11,3,22,49.00),(73,12,1,23,109.00),(74,12,1,24,69.00),(75,12,2,23,99.00),(76,12,2,24,59.00),(77,12,3,23,89.00),(78,12,3,24,49.00),(79,13,1,25,109.00),(80,13,1,26,69.00),(81,13,2,25,99.00),(82,13,2,26,59.00),(83,13,3,25,89.00),(84,13,3,26,49.00),(85,14,1,27,109.00),(86,14,1,28,69.00),(87,14,2,27,99.00),(88,14,2,28,59.00),(89,14,3,27,89.00),(90,14,3,28,49.00),(91,15,1,29,109.00),(92,15,1,30,69.00),(93,15,2,29,99.00),(94,15,2,30,59.00),(95,15,3,29,89.00),(96,15,3,30,49.00);
/*!40000 ALTER TABLE `tarifas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temporadas`
--

DROP TABLE IF EXISTS `temporadas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `temporadas` (
  `id_temporada` int NOT NULL AUTO_INCREMENT,
  `id_hotel` int DEFAULT NULL,
  `nombre` enum('baja','alta') DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_fin` date DEFAULT NULL,
  PRIMARY KEY (`id_temporada`),
  KEY `fk_temporadas_1_idx` (`id_hotel`),
  CONSTRAINT `fk_temporadas_1` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temporadas`
--

LOCK TABLES `temporadas` WRITE;
/*!40000 ALTER TABLE `temporadas` DISABLE KEYS */;
INSERT INTO `temporadas` VALUES (1,1,'alta','2025-06-01','2025-09-14'),(2,1,'baja','2025-09-15','2026-05-31'),(3,2,'alta','2025-06-01','2025-09-14'),(4,2,'baja','2025-09-15','2026-05-31'),(5,3,'alta','2025-06-01','2025-09-14'),(6,3,'baja','2025-09-15','2026-05-31'),(7,4,'alta','2025-06-01','2025-09-14'),(8,4,'baja','2025-09-15','2026-05-31'),(9,5,'alta','2025-06-01','2025-09-14'),(10,5,'baja','2025-09-15','2026-05-31'),(11,6,'alta','2025-11-01','2026-03-31'),(12,6,'baja','2025-04-01','2025-10-31'),(13,7,'alta','2025-11-01','2026-03-31'),(14,7,'baja','2025-04-01','2025-10-31'),(15,8,'alta','2025-11-01','2026-03-31'),(16,8,'baja','2025-04-01','2025-10-31'),(17,9,'alta','2025-11-01','2026-03-31'),(18,9,'baja','2025-04-01','2025-10-31'),(19,10,'alta','2025-11-01','2026-03-31'),(20,10,'baja','2025-04-01','2025-10-31'),(21,11,'alta','2025-06-01','2025-08-31'),(22,11,'baja','2025-09-01','2026-05-31'),(23,12,'alta','2025-06-01','2025-08-31'),(24,12,'baja','2025-09-01','2026-05-31'),(25,13,'alta','2025-06-01','2025-08-31'),(26,13,'baja','2025-09-01','2026-05-31'),(27,14,'alta','2025-06-01','2025-08-31'),(28,14,'baja','2025-09-01','2026-05-31'),(29,15,'alta','2025-06-01','2025-08-31'),(30,15,'baja','2025-09-01','2026-05-31');
/*!40000 ALTER TABLE `temporadas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_hotel`
--

DROP TABLE IF EXISTS `tipo_hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_hotel` (
  `id_tipo_hotel` int NOT NULL AUTO_INCREMENT,
  `tipo_hotel` varchar(25) NOT NULL,
  PRIMARY KEY (`id_tipo_hotel`,`tipo_hotel`),
  UNIQUE KEY `idx_tipo_hotel` (`tipo_hotel`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_hotel`
--

LOCK TABLES `tipo_hotel` WRITE;
/*!40000 ALTER TABLE `tipo_hotel` DISABLE KEYS */;
INSERT INTO `tipo_hotel` VALUES (2,'ciudad'),(1,'montaña'),(3,'playa');
/*!40000 ALTER TABLE `tipo_hotel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_pagos`
--

DROP TABLE IF EXISTS `tipos_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipos_pagos` (
  `id_tipo_pago` int NOT NULL AUTO_INCREMENT,
  `metodo_pago` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_pago`),
  UNIQUE KEY `idx_metodo_pago` (`metodo_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_pagos`
--

LOCK TABLES `tipos_pagos` WRITE;
/*!40000 ALTER TABLE `tipos_pagos` DISABLE KEYS */;
INSERT INTO `tipos_pagos` VALUES (3,'facial'),(2,'paypal'),(1,'tarjeta');
/*!40000 ALTER TABLE `tipos_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `dni` varchar(20) DEFAULT NULL,
  `nombre` varchar(35) DEFAULT NULL,
  `apellidos` varchar(50) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `nombre_pais` varchar(45) DEFAULT NULL,
  `contraseña` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `correo_UNIQUE` (`correo`),
  KEY `fk_usuarios_1_idx` (`nombre_pais`),
  CONSTRAINT `fk_usuarios_1` FOREIGN KEY (`nombre_pais`) REFERENCES `paises_usuario` (`pais`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (37,'76373838H','Hugo','Moreno','hugo@gmail.com',NULL,NULL,'$2y$10$FgYowSYdBiNFAyV32ZwMKO0ZPanA0k6jmYzqlrSIt3HgD6GvsGoz2'),(38,'64747474B','Bruno','Ostos','bruno1@gmail.com',NULL,NULL,'$2y$10$n3wcf1jyAhT7hZbkAQYqC.PlYodMal7Qq3W9wdC79irW35bAOKrAK');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-21 16:56:37
