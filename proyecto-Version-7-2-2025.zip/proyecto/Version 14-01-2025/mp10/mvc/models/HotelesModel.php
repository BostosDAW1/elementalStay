<?php
class HotelesModel
{
    protected $db;

    public function __construct()
    {
        // Incluimos el archivo de conexión
        require '../../config/conexion.php'; // Asegúrate de que la ruta sea correcta
        $this->db = $conn; // Asignamos la conexión a la propiedad
    }
 
    public function listadoHotelesTotal()
    {
        // Realizamos la consulta de todos los hoteles
        $consulta = $this->db->prepare('SELECT * FROM hoteles');
        $consulta->execute();
        // Devolvemos la colección para que la vista la presente
        return $consulta;
    }
}

?>