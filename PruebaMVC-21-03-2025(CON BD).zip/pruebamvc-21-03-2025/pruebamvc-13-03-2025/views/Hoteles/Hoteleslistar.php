<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>MVC - Modelo, Vista, Controlador - Elemental Stay</title>
</head>
<style>
    body {
        font-family: sans-serif;
        background-color: #f9f9f9;
        color: #333;
        text-align: center;
        margin: 0;
        padding: 0;
    }
    h1, h4 {
        margin: 0;
        padding: 10px;
    }
    h1 {
        background-color: #4f4caf;
        color: #fff;
    }
    table {
        width: 90%;
        margin: 20px auto;
        border-collapse: collapse;
    }
    th, td {
        padding: 10px;
        border: 1px solid #ddd;
        text-align: center;
    }
    th {
        background-color: #4f4caf;
        color: #fff;
    }
    tr:hover {
        background-color: #ddd;
    }
    #acciones {
        background-color: #6461b1;
    }
    a {
        color: black;
        text-decoration: none;
        padding: 10px;
    }
    a:hover {
        color: white;
        background-color: #4e4d76;
        border-radius: 15px;
    }
    .div-estat {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 300px;
        height: 50px;
        background-color:#4f4caf;
        margin: 15px auto;
        border-radius: 5px;
    }
    .div-estat:hover {
        background-color: #6461b1;
    }
    .estat-total {
        color: white;
        margin: 0 0 0 25px;
    }
    .estat-link {
        text-decoration: none;
        padding: 10px;
    }
    .estat-link:hover {
        color: white;
        background-color: #6461b1;
    }
</style>
<body>
    <h1>Elemental Stay</h1>
    <h4>Llistat de Hoteles disponibles</h4>
    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Precios</th>
            <th>Accions</th>
        </tr>
        <?php
        // Suponemos que $listado es un array de hoteles
        if (is_array($listado) && count($listado) > 0) {
            foreach ($listado as $hotel) {
        ?>
        <tr>
            <td><?php echo $hotel['id_hotel']; ?></td>
            <td><?php echo $hotel['nombre']; ?></td>
            <td><?php echo "desde " . number_format($hotel['min_precio'], 2) . "€"; ?></td>
            <td id="acciones">
                <a href="index.php?controlador=HotelesCompletos&accion=listarHotelesCompletos&id=<?php echo $hotel['id_hotel']; ?>">Ver más</a>
            </td>
        </tr>
        <?php
            }
        } else {
            echo "<tr><td colspan='3'>No se encontraron hoteles.</td></tr>";
        }
        ?>
    </table>
    <a href="index.php?controlador=Hoteles&accion=afegirHoteles">Afegir</a>
    <a href="views/menuMVC.php">Tornar</a>
</body>
</html>
