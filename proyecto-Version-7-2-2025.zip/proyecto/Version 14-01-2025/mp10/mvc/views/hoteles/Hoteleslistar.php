<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>MVC - Modelo, Vista, Controlador</title>
</head>
<style>
    /* Aquí va tu CSS */
</style>
<body>
    <h1>Elemental Stay</h1>
    <h4>Llistat de Hoteles disponibles</h4>
    <table>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Tipo</th>
            <th>Comunidad Autónoma</th>
            <th>Acciones</th>
        </tr>
        <?php
        // Verifica si la variable $listado está correctamente asignada
        if (isset($listado)) {
            // Mostramos los datos obtenidos desde el modelo
            while($hoteles = $listado->fetch()) {
        ?>
        <tr>
            <td><?php echo $hoteles['id_hotel']?></td>
            <td><?php echo $hoteles['nombre']?></td>
            <td><?php echo $hoteles['tipo_hotel']?></td>
            <td><?php echo $hoteles['comunidad_autonoma']?></td>
            <td>
                <a href="index.php?controlador=Hoteles&accion=modificarHoteles&id=<?= $hoteles["id_hotel"]?>">Modificar</a>
                <a href="index.php?controlador=Hoteles&accion=eliminarHoteles&id=<?= $hoteles["id_hotel"]?>">Eliminar</a>
            </td>
        </tr>
        <?php
            }
        }
        ?>
    </table>
    <a href="index.php?controlador=Hoteles&accion=afegirHoteles">Afegir</a>
    <a href="../../../index.php">Tornar</a>
</body>
</html>
