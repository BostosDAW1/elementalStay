<?php
class HotelesCompletosController
{
    private $view;
    
    public function __construct()
    {
        // Instanciamos el motor de plantillas
        $this->view = new View();
    }
 
    public function listarHotelesCompletos()
    {
        require_once 'models/HotelesCompletosModel.php';

        $hotelesCompletos = new HotelesCompletosModel();

        // Obtener ID del hotel desde la URL
        $id_hotel = isset($_GET['id']) ? intval($_GET['id']) : 0;

        // Obtener los datos solo del hotel seleccionado
        $listado = $hotelesCompletos->listadoHotelesCompletosPorId($id_hotel);

        $data['listado'] = $listado;

        $this->view->show("Hoteles/HotelesCompletoslistar.php", $data);
    }
}
?>
