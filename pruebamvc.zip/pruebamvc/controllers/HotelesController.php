<?php
class HotelesController
{
    private $view;
    
    public function __construct()
    {
        // Instanciamos el motor de plantillas
        $this->view = new View();
    }
 
    public function listarHoteles()
    {
        // Incluimos el modelo correspondiente
        require_once 'models/HotelesModel.php';
 
        // Creamos una instancia del modelo
        $hoteles = new HotelesModel();
 
        // Obtenemos el listado de hoteles
        $listado = $hoteles->listadoHotelesTotal();
 
        // Preparamos los datos para la vista
        $data['listado'] = $listado;
 
        // Mostramos la vista (sin barra inicial para que la ruta sea correcta)
        $this->view->show("Hoteles/Hoteleslistar.php", $data);
    }
}
?>
