-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: hoteles_db
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.23.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `pais` varchar(50) NOT NULL,
  `ciudad` varchar(50) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'hugor','Hugo','Ramírez López','hugo.ramirez@example.com','677123456','España','Sevilla','cd6cbae9376c247d9ae791675c706da07e3d7a2877c94cf6deb2ec9bdee50177'),(2,'brunof','Bruno','Fernández Torres','bruno.fernandez@example.com','688234567','México','Guadalajara','9f8fcbdf72be532e8a913ebed95adfd9cc16bf13a7cf3f397c64c93c18bf942b');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `habitaciones`
--

DROP TABLE IF EXISTS `habitaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `habitaciones` (
  `id_habitacion` int NOT NULL AUTO_INCREMENT,
  `id_hotel` int NOT NULL,
  `tipo_habitacion` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `capacidad` int DEFAULT NULL,
  PRIMARY KEY (`id_habitacion`),
  KEY `id_hotel` (`id_hotel`),
  KEY `idx_nombre_habitacion` (`nombre`),
  CONSTRAINT `habitaciones_ibfk_1` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=204 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `habitaciones`
--

LOCK TABLES `habitaciones` WRITE;
/*!40000 ALTER TABLE `habitaciones` DISABLE KEYS */;
INSERT INTO `habitaciones` VALUES (1,1,'Económica',108.00,'Sol Simple',2),(2,2,'Económica',81.00,'Refugio Azul',2),(3,3,'Económica',135.00,'Estancia Serena',2),(4,4,'Económica',180.00,'Vista Montaña',4),(5,5,'Económica',225.00,'Habitación Coral',2),(6,6,'Económica',72.00,'Eco Zen',2),(7,7,'Económica',90.00,'Nido Urbano',3),(8,8,'Económica',162.00,'Descanso del Mar',2),(9,9,'Económica',198.00,'Encina Tranquila',2),(10,10,'Económica',117.00,'Brisa Suave',3),(11,11,'Económica',99.00,'Almendra Clara',2),(12,12,'Económica',117.00,'Refugio del Alba',3),(13,13,'Económica',126.00,'Olivo Viejo',2),(14,14,'Económica',189.00,'Nube Baja',2),(15,15,'Económica',85.50,'Pequeño Paraíso',1),(16,16,'Económica',153.00,'Cabaña Urbana',4),(17,17,'Económica',162.00,'Solera Moderna',2),(18,18,'Económica',225.00,'Espacio Cálido',3),(19,19,'Económica',144.00,'Ámbar Rústico',2),(20,20,'Económica',117.00,'Rincón Serrano',2),(21,21,'Económica',216.00,'Amanecer Económico',2),(22,22,'Económica',130.50,'Dormitorio Roble',3),(23,23,'Económica',139.50,'Malva Suave',2),(24,24,'Económica',238.50,'Refugio Lirio',2),(25,25,'Económica',157.50,'Nido del Alba',3),(26,26,'Económica',207.00,'Estancia Bronce',2),(27,27,'Económica',103.50,'Cuarto Jade',1),(28,28,'Económica',171.00,'EcoLuz',3),(29,29,'Económica',184.50,'Refugio Pino',2),(30,30,'Económica',112.50,'Espacio Urbano 30',2),(31,31,'Económica',135.00,'Vista Lago',2),(32,32,'Económica',198.00,'Cuarzo Gris',2),(33,33,'Económica',121.50,'Descanso Lavanda',1),(34,34,'Económica',139.50,'Encanto Natural',2),(36,1,'Estándar',120.00,'Sol Naciente',2),(37,2,'Estándar',90.00,'Habitación Central',2),(38,3,'Estándar',150.00,'Nube Clara',2),(39,4,'Estándar',200.00,'Almendra Noble',4),(40,5,'Estándar',250.00,'Mediterráneo Cálido',2),(41,6,'Estándar',80.00,'Dormitorio Sierra',2),(42,7,'Estándar',100.00,'Amanecer Estándar',3),(43,8,'Estándar',180.00,'Esmeralda Suave',2),(44,9,'Estándar',220.00,'Habitación Real',2),(45,10,'Estándar',130.00,'Nido Azul',3),(46,11,'Estándar',110.00,'Tranquilo Este',2),(47,12,'Estándar',130.00,'Suite Clara',3),(48,13,'Estándar',140.00,'Cedro Blanco',2),(49,14,'Estándar',210.00,'Lila Profunda',2),(50,15,'Estándar',95.00,'Norte Brillante',1),(51,16,'Estándar',170.00,'Jardín Estándar',4),(52,17,'Estándar',180.00,'Río Fresco',2),(53,18,'Estándar',250.00,'Suite Terra',3),(54,19,'Estándar',160.00,'Girasol Alto',2),(55,20,'Estándar',130.00,'Reflejo Sereno',2),(56,21,'Estándar',240.00,'Refugio Castilla',2),(57,22,'Estándar',145.00,'Mistral Norte',3),(58,23,'Estándar',155.00,'Laurel Verde',2),(59,24,'Estándar',265.00,'Arena Dorada',2),(60,25,'Estándar',175.00,'Brisa Marina',3),(61,26,'Estándar',230.00,'Prado Estándar',2),(62,27,'Estándar',115.00,'Sur Soleado',1),(63,28,'Estándar',190.00,'Tierra Suave',3),(64,29,'Estándar',205.00,'Primavera Cálida',2),(65,30,'Estándar',125.00,'Verde Oliva',2),(66,31,'Estándar',150.00,'Central Moderna',2),(67,32,'Estándar',220.00,'Jardín Claro',2),(68,33,'Estándar',135.00,'Piedra Serena',3),(69,34,'Estándar',155.00,'Castilla Estándar',2),(71,1,'Suite',144.00,'Suite Amanecer',2),(72,2,'Suite',108.00,'Suite Encanto Azul',2),(73,3,'Suite',180.00,'Suite Horizonte',2),(74,4,'Suite',240.00,'Suite Montaña Clara',4),(75,5,'Suite',300.00,'Suite Imperial',2),(76,6,'Suite',96.00,'Suite Verde Paz',2),(77,7,'Suite',120.00,'Suite Zafiro',3),(78,8,'Suite',216.00,'Suite Coralina',2),(79,9,'Suite',264.00,'Suite Mirador',2),(80,10,'Suite',156.00,'Suite Alba',3),(81,11,'Suite',132.00,'Suite Ciprés',2),(82,12,'Suite',156.00,'Suite Serenidad',3),(83,13,'Suite',168.00,'Suite Cielo Claro',2),(84,14,'Suite',252.00,'Suite Estrella',2),(85,15,'Suite',114.00,'Suite Delicias',1),(86,16,'Suite',204.00,'Suite Jardín del Sol',4),(87,17,'Suite',216.00,'Suite Aurora',2),(88,18,'Suite',300.00,'Suite Oasis',3),(89,19,'Suite',192.00,'Suite Brisa Real',2),(90,20,'Suite',156.00,'Suite Lavanda',2),(91,21,'Suite',288.00,'Suite Panorámica',2),(92,22,'Suite',174.00,'Suite Canela',3),(93,23,'Suite',186.00,'Suite Tranquila',2),(94,24,'Suite',318.00,'Suite Orquídea',2),(95,25,'Suite',210.00,'Suite Dorada',3),(96,26,'Suite',276.00,'Suite Ébano',2),(97,27,'Suite',138.00,'Suite Amanecer Urbano',1),(98,28,'Suite',228.00,'Suite Altamar',3),(99,29,'Suite',246.00,'Suite Olivares',2),(100,30,'Suite',150.00,'Suite Central',2),(101,31,'Suite',180.00,'Suite Cristalina',2),(102,32,'Suite',264.00,'Suite Horizonte Azul',2),(103,33,'Suite',162.00,'Suite Aromas',3),(104,34,'Suite',186.00,'Suite Magnolia',2);
/*!40000 ALTER TABLE `habitaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoteles`
--

DROP TABLE IF EXISTS `hoteles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hoteles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `descripcion` varchar(455) DEFAULT NULL,
  `comunidad` varchar(50) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `disponibilidad` tinyint(1) NOT NULL,
  `available_from` date NOT NULL,
  `available_to` date NOT NULL,
  `capacidad` int NOT NULL,
  `numero_habitaciones` int NOT NULL,
  `permite_mascotas` tinyint(1) NOT NULL,
  `imagen` varchar(45) DEFAULT NULL,
  `imagen2` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`),
  UNIQUE KEY `nombre_2` (`nombre`),
  UNIQUE KEY `nombre_3` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoteles`
--

LOCK TABLES `hoteles` WRITE;
/*!40000 ALTER TABLE `hoteles` DISABLE KEYS */;
INSERT INTO `hoteles` VALUES (1,'Hotel Marítimo','playa','Un hermoso hotel frente al mar con vistas espectaculares y acceso directo a la playa.','valencia',120.00,1,'2025-01-01','2025-12-31',2,1,1,'img/hotel1.jpg','img/hotel1segunda.jpg'),(2,'Hotel Montaña Azul','montaña','Ubicado en la cima de la montaña, este hotel es perfecto para los amantes del senderismo y la naturaleza.','madrid',90.00,0,'2025-03-01','2025-11-30',2,1,0,'img/hotel2.jpg',NULL),(3,'Hotel Sol','playa','Un elegante hotel en la costa con piscinas infinitas y servicio todo incluido.','valencia',150.00,1,'2025-06-01','2025-08-31',2,2,1,'img/hotel3.jpg',NULL),(4,'Hotel Vista al Mar','playa','Relájate con el sonido de las olas en este encantador hotel con vistas panorámicas al mar.','cantabria',200.00,1,'2025-05-01','2025-09-30',4,2,1,'img/hotel4.jpg',NULL),(5,'Hotel Palacio Real','ciudad','Lujo y comodidad en pleno corazón de Madrid, ideal para una escapada urbana de ensueño.','madrid',250.00,0,'2025-07-01','2025-12-31',2,1,0,'img/hotel5.jpg',NULL),(6,'Hotel Costa Verde','playa','Un refugio rodeado de naturaleza, perfecto para desconectar del estrés de la ciudad.','cantabria',80.00,1,'2025-04-01','2025-10-15',2,1,1,'img/hotel6.jpg',NULL),(7,'Hotel Andino','montaña','Un acogedor hotel de montaña con chimeneas y vistas impresionantes del amanecer.','madrid',100.00,1,'2025-01-01','2025-12-31',3,1,1,'img/hotel7.jpg',NULL),(8,'Hotel del Sol','playa','Disfruta del sol y la arena en este exclusivo hotel frente al mar con servicios de lujo.','valencia',180.00,0,'2025-05-01','2025-09-30',2,2,0,'img/hotel8.jpg',NULL),(9,'Hotel Madrid Centro','ciudad','Ubicación inmejorable en el centro de la ciudad con acceso a los mejores restaurantes y tiendas.','madrid',220.00,1,'2025-01-01','2025-12-31',2,1,1,'img/hotel9.jpg',NULL),(10,'Hotel de la Montaña','montaña','Rodeado de montañas, este hotel ofrece una experiencia única para los aventureros.','cantabria',130.00,0,'2025-04-01','2025-10-31',3,1,1,'img/hotel10.jpg',NULL),(11,'Hotel Brisa Marina','playa','Perfecto para una escapada romántica, con habitaciones con vista al mar y cena gourmet.','valencia',110.00,1,'2025-02-01','2025-12-31',2,1,1,'img/hotel11.jpg',NULL),(12,'Hotel Roca del Mar','playa','Comodidad y relajación junto a la playa, ideal para disfrutar de unas vacaciones inolvidables.','cantabria',130.00,1,'2025-03-01','2025-11-30',3,1,0,'img/hotel12.jpg',NULL),(13,'Hotel Montaña Escondida','montaña','Hotel boutique en la montaña con una experiencia de spa y desconexión total.','madrid',140.00,0,'2025-04-01','2025-10-31',2,1,0,'img/hotel13.jpg',NULL),(14,'Hotel Ciudad Central','ciudad','Diseño moderno y sofisticado en pleno centro de Madrid, con todas las comodidades.','madrid',210.00,1,'2025-01-01','2025-12-31',2,1,1,'img/hotel14.jpg',NULL),(15,'Hotel Costa Dorada','playa','Un pequeño y acogedor hotel junto al mar, ideal para familias y parejas.','cantabria',95.00,0,'2025-05-01','2025-09-30',1,1,1,'img/hotel15.jpg',NULL),(16,'Hotel Vista Panorámica','montaña','Paisajes impresionantes y senderos naturales rodean este hotel de montaña.','cantabria',170.00,1,'2025-06-01','2025-12-31',4,2,0,'img/hotel16.jpg',NULL),(17,'Hotel Sol y Luna','playa','Un paraíso tropical con piscinas, restaurantes gourmet y acceso directo a la playa.','valencia',180.00,1,'2025-07-01','2025-12-31',2,2,1,'img/hotel17.jpg',NULL),(18,'Hotel Paraíso Urbano','ciudad','Situado en el corazón de la ciudad, con un diseño vanguardista y habitaciones de lujo.','madrid',250.00,0,'2025-08-01','2025-12-31',3,1,0,'img/hotel18.jpg',NULL),(19,'Hotel Sierra Azul','montaña','Un hotel rústico en la montaña con cabañas privadas y vistas impresionantes.','madrid',160.00,1,'2025-03-01','2025-10-31',2,1,1,'img/hotel19.jpg',NULL),(20,'Hotel Brisas del Sur','playa','Situado en la costa, este hotel es ideal para relajarse y disfrutar del mar.','valencia',130.00,1,'2025-02-15','2025-11-30',2,1,0,'img/hotel20.jpg',NULL),(21,'Hotel Cielo Abierto','ciudad','Arquitectura moderna y espacios amplios, con vistas espectaculares a la ciudad.','cantabria',240.00,1,'2025-04-01','2025-12-31',2,2,1,'img/hotel21.jpg',NULL),(22,'Hotel Rincón Secreto','montaña','Un hotel escondido en la montaña, perfecto para una escapada de aventura y naturaleza.','cantabria',145.00,0,'2025-01-15','2025-09-15',3,2,0,'img/hotel22.jpg',NULL),(23,'Hotel Sol Naciente','playa','Un encantador hotel de playa con actividades acuáticas y espectáculos nocturnos.','valencia',155.00,1,'2025-03-01','2025-08-31',2,1,1,'img/hotel23.jpg',NULL),(24,'Hotel Horizonte Infinito','ciudad','Lujo y comodidad con vistas panorámicas de la ciudad y un restaurante de alta cocina.','madrid',265.00,0,'2025-05-01','2025-12-31',2,2,0,'img/hotel24.jpg',NULL),(25,'Hotel Mar y Montaña','playa','Una combinación perfecta entre mar y montaña, con paisajes únicos y tranquilidad.','cantabria',175.00,1,'2025-04-15','2025-10-15',3,1,1,'img/hotel25.jpg',NULL),(26,'Hotel Oasis Urbano','ciudad','Un oasis en la ciudad con un ambiente relajante y espacios exclusivos para los huéspedes.','valencia',230.00,1,'2025-02-01','2025-11-30',2,1,0,'img/hotel26.jpg',NULL),(27,'Hotel Rocas y Mar','playa','Un lugar ideal para escapar de la rutina y disfrutar de la brisa marina.','cantabria',115.00,0,'2025-06-01','2025-09-30',1,1,1,'img/hotel27.jpg',NULL),(28,'Hotel Bruma del Valle','montaña','Un refugio en las montañas con spa, piscinas naturales y aire puro.','madrid',190.00,1,'2025-03-15','2025-12-31',3,2,1,'img/hotel28.jpg',NULL),(29,'Hotel Ciudad del Sol','ciudad','Ubicación estratégica con fácil acceso a las principales atracciones de la ciudad.','madrid',205.00,1,'2025-01-01','2025-10-31',2,1,0,'img/hotel29.jpg',NULL),(30,'Hotel Mar Serene','playa','Hotel boutique con una atmósfera acogedora y acceso privado a la playa.','valencia',125.00,1,'2025-04-01','2025-11-30',2,1,1,'img/hotel30.jpg',NULL),(31,'Hotel Pico del Cielo','montaña','El destino perfecto para los amantes de la montaña y el turismo de aventura.','cantabria',150.00,0,'2025-05-01','2025-10-31',2,1,0,'img/hotel31.jpg',NULL),(32,'Hotel Urbe Moderna','ciudad','Estilo y comodidad en un hotel urbano con todas las facilidades modernas.','madrid',220.00,1,'2025-02-01','2025-12-31',2,1,1,'img/hotel32.jpg',NULL),(33,'Hotel Playa Dorada','playa','Un hotel exclusivo en la costa con servicio personalizado y playa privada.','valencia',135.00,1,'2025-06-01','2025-12-31',3,2,1,'img/hotel33.jpg',NULL),(34,'Hotel Montaña Viva','montaña','Aventura y tranquilidad en este hotel de montaña con rutas de senderismo.','madrid',155.00,1,'2025-07-01','2025-11-30',2,1,0,'img/hotel34.jpg',NULL),(35,'Hotel Ciudad de Oro','ciudad','Un hotel elegante con vistas impresionantes y un ambiente tranquilo y sofisticado.','cantabria',245.00,0,'2025-03-01','2025-09-30',3,2,1,'img/hotel35.jpg',NULL);
/*!40000 ALTER TABLE `hoteles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info_pagos`
--

DROP TABLE IF EXISTS `info_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info_pagos` (
  `id_infoPago` int NOT NULL AUTO_INCREMENT,
  `nombreTarjeta` varchar(100) DEFAULT NULL,
  `numeroTarjeta` varchar(20) DEFAULT NULL,
  `cvv` varchar(4) DEFAULT NULL,
  `caducidadTarjeta` varchar(7) DEFAULT NULL,
  PRIMARY KEY (`id_infoPago`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_pagos`
--

LOCK TABLES `info_pagos` WRITE;
/*!40000 ALTER TABLE `info_pagos` DISABLE KEYS */;
INSERT INTO `info_pagos` VALUES (10,'Juan Pérez','1234567812345678','123','12/26'),(11,'hugo hugo hugo','1111222233334444','555','01/28'),(12,'hugo hugo hugo','1111222233334444','555','01/28'),(13,'pereira pereira ola buenas','7777888877776666','888','11/29'),(14,'hugo','2222333344445555','888','07/28'),(15,'ALFREDO DURO','1212121211111221','888','02/30'),(16,'hugo moreno exposito','6378292876437281','555','11/30'),(17,'hugo moreno exposito','1111111111111111','333','12/28'),(18,'HUGO MORENO EXPOSITO','1111222233334444','777','02/29'),(19,'hugo moreno','1234567891234555','111','11/11'),(20,'hugo moreno exposito','1234567890876543','222','08/25'),(21,'hugo moreno exposito','1234567890876543','345','08/25'),(22,'hugo moreno exposito','1111111111111111','111','12/26'),(23,'hugo moreno exposito','1234567890876543','123','08/25'),(24,'hugo moreno exposito','1234543234565434','123','08/29'),(25,'pedrito gonzaless','1111222223334444','111','12/28'),(26,'pedrito gonzaless','1111222223334444','111','12/28'),(27,'pedrito gonzaless','1111222223334444','111','12/28'),(28,'pepe','1111111111111111','111','12/29'),(29,'hugo moreno exposito','1111111111111111','111','12/29'),(30,'hugo moreno exposito','5555555555555555','222','12/28');
/*!40000 ALTER TABLE `info_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservas`
--

DROP TABLE IF EXISTS `reservas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservas` (
  `idreserva` int NOT NULL AUTO_INCREMENT,
  `id_infoPago` int DEFAULT NULL,
  `id_hotel` int DEFAULT NULL,
  `id_habitacion` int DEFAULT NULL,
  `id_usuario` int DEFAULT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellidos` varchar(100) DEFAULT NULL,
  `correo` varchar(45) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `nombre_hotel` varchar(225) DEFAULT NULL,
  `nombre_habitacion` varchar(45) DEFAULT NULL,
  `fecha_inicio` date DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  PRIMARY KEY (`idreserva`),
  KEY `fk_reservas_1_idx` (`id_hotel`),
  KEY `fk_reservas_3_idx` (`id_habitacion`),
  KEY `fk_reservas_3_idx1` (`id_usuario`),
  KEY `fk_reservas_4_idx1` (`nombre_habitacion`,`correo`),
  KEY `idx_nombre_habitacion` (`nombre_habitacion`),
  KEY `idx_nombre_habitacion1` (`nombre_habitacion`),
  KEY `fk_reservas_1_idx1` (`id_infoPago`),
  CONSTRAINT `fk_reservas_1` FOREIGN KEY (`id_infoPago`) REFERENCES `info_pagos` (`id_infoPago`),
  CONSTRAINT `fk_reservas_2` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id`),
  CONSTRAINT `fk_reservas_3` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `fk_reservas_id_habitacion` FOREIGN KEY (`id_habitacion`) REFERENCES `habitaciones` (`id_habitacion`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservas`
--

LOCK TABLES `reservas` WRITE;
/*!40000 ALTER TABLE `reservas` DISABLE KEYS */;
INSERT INTO `reservas` VALUES (4,NULL,1,1,1,'carlosf','Fernández Gutierrez','carlos.fernandez@example.com','612345678','Hotel Marítimo','Sol Simple','2025-06-15','2025-06-20'),(5,NULL,2,2,2,'lauram','Martínez Pérez','laura.martinez@example.com','623456789','Hotel Montaña Azul','Refugio Azul','2025-07-01','2025-07-05'),(6,NULL,3,3,3,'davidg','García López','david.garcia@example.com','634567890','Hotel Sol','Estancia Serena','2025-07-10','2025-07-15'),(7,NULL,4,4,4,'anar','Ruiz Sánchez','ana.ruiz@example.com','645678901','Hotel Vista al Mar','Vista Montaña','2025-08-01','2025-08-05'),(8,NULL,5,5,5,'miguelt','Torres Díaz','miguel.torres@example.com','656789012','Hotel Palacio Real','Habitación Coral','2025-09-01','2025-09-07'),(23,29,2,2,35,'hugo','pereira','pereira@gmail.com','666777888','Hotel Montaña Azul','Refugio Azul','2025-05-30','2025-05-31');
/*!40000 ALTER TABLE `reservas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellidos` varchar(100) DEFAULT NULL,
  `correo` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `pais` varchar(50) DEFAULT NULL,
  `ciudad` varchar(50) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `correo` (`correo`),
  KEY `idx_apellidos` (`apellidos`),
  KEY `idx_telefono` (`telefono`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'carlosf','Carlos','Fernández Gutierrez','carlos.fernandez@example.com','612345678','España','Barcelona','ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f',0),(2,'lauram','Laura','Martínez Pérez','laura.martinez@example.com','623456789','España','Barcelona','4379f8e1c8ffa0a9f75b600b3af9412b0fa91123c8b674d49139268b71aefd9d',0),(3,'davidg','David','García López','david.garcia@example.com','634567890','México','Ciudad de México','42474f99289f6500159070f4fb96a4f381132d36136fa802333b671603852e9f',0),(4,'anar','Ana','Ruiz Sánchez','ana.ruiz@example.com','645678901','Argentina','Buenos Aires','f22b9c0270fbebdf6244fcd6b930fdfa2dfa919105553ae1a590c8fc39899bcb',0),(5,'miguelt','Miguel','Torres Díaz','miguel.torres@example.com','656789012','Chile','Santiago','1af2389ce41a68ca5e3d4a3528f7a0a0e5221222a3ab207e7d867fdc587ae431',0),(6,'hugo','Hugo','Moreno Expósito','hmore2@insdanielblanxart.cat','602954729','Andorra','Andorra','5186646859c5b07676015f15c581e2514b2b778309f9422150a6032f826f388e',0),(21,'Raul','Raul ','Masso','raul@gmail.com','123456789','España','Barcelona','d5019c66fba6d3222d8eca93ed676d5e6885897d3f5d2e1dec7e209be2ae1f09',0),(24,'Isaac','isaac manuel','123567890\'','isaac@gmail.com','12345678','Colombia','quito','02df7b1f373b58f5dcfeab8974a2182eeb8b5eb38f0e9c94b4e86940a08ecedf',0),(25,'alfredito','Alfredo','Moreno','alfredito@gmail.com','666000222','Hungría','Barcelona','cfb53652ae88578c81744ffb1f624615bf6a4c8f52c2d22c2b86c429f23e8246',0),(27,'Ignasio','ignasio','perez','ignasio@gmail.com','666000222','España','Barcelona','a9d53d4c7415bb81315c11cf7d534c895c7639747315db085a321b4111f9ddf5',0),(28,'Bruno2','hugo','aaaaaaaa','bruno2@gmail.com','666777888','w','barcelona','ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f',1),(30,'alex','','Fernández Garcia','alex@gmail.com','','','','f001722cdd7f9371daedf315af63a5ffed19ea84a3788bbe7e7069c3ae11f4d0',0),(31,'alba','garcia','lopez','alba@gmail.com','333333333','españa','barcelona','65865c1a28afba289bd68a3f89ef2a34ee3731f69f1be0c1ece3c79a71a26540',0),(33,'aalfredo','aaaa','aaaaaaaaaaaaaaa','aalfredo@gmail.com','666777888','','','5b5adfe1bdd5f3376df64a143e13613b368e26d3eaa1bcf42f2f93796b1e0a04',0),(34,'pedrito','pedrito','gonzales','pedrito@gmail.com','111111111','ESpaña','Barcelona','5ae94b1f7cca53480ab488920cdd6925a592e642ade4027982dc336097aa3379',0),(35,'pereira','hugo','pereira','pereira@gmail.com','666777888','españa','berceloan','29dd1a8107aab1f437a5cb2b1de2f099a596e6acedc8b4c907991afbcb4ccbc5',0),(36,'user','user','useruser','user@gmail.com','787888999','España','Barcelona','e172c5654dbc12d78ce1850a4f7956ba6e5a3d2ac40f0925fc6d691ebb54f6bf',0);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-16 17:44:58
