<?php
// Asegúrate de incluir los modelos necesarios
require_once('/var/www/html/mvc/models/HotelesModel.php');

// El resto de tu código


class HotelesController {

    public function buscarHoteles() {
        // Recibimos los datos del formulario
        $destino = $_GET['destino'] ?? '';
        $entrada = $_GET['entrada'] ?? '';
        $salida = $_GET['salida'] ?? '';
        $adultos = $_GET['adultos'] ?? 1;
        $ninos = $_GET['ninos'] ?? 0;
        $habitaciones = $_GET['habitaciones'] ?? 1;

        // Llamamos al modelo para obtener los hoteles disponibles
        $hoteles = HotelesModel::obtenerHotelesDisponibles($destino, $entrada, $salida, $adultos, $ninos, $habitaciones);

        // Incluimos la vista que muestra los hoteles
        include_once 'views/mostrar_hoteles.php';
    }
}
