document.addEventListener('DOMContentLoaded', () => {
  // 1) Intentamos obtener el usuario de sesión
  fetch('/usuario', { credentials: 'include' })
    .then(res => {
      if (!res.ok) throw new Error('No autenticado');
      return res.json();
    })
    .then(userData => {
      // 2) Si hay usuario, guardarlo y ajustar la navbar
      window.currentUser = userData;
      const navLinks = document.querySelector('.navbar-left-links');
      // Elimina el "Iniciar sesión"
      const loginLink = navLinks.querySelector('.btn-login');
      if (loginLink) loginLink.remove();
      // Añade "Ver perfil" si no existe aún
      if (!navLinks.querySelector('.btn-perfil')) {
        const perfilLi = document.createElement('li');
        perfilLi.innerHTML = `<a href="/perfil/perfil.html" class="btn-perfil">Ver perfil</a>`;
        navLinks.appendChild(perfilLi);
      }
    })
    .catch(() => {
      // 3) Si no está autenticado, deja el botón de "Iniciar sesión"
      console.log('Usuario no autenticado');
      // (Opcional) podrías forzar que exista:
      // const navLinks = document.querySelector('.navbar-left-links');
      // if (!navLinks.querySelector('.btn-login')) { /* crear btn-login */ }
    })
    .finally(() => {
      // 4) Resto de inicialización
      cargarHoteles();
      const modal = document.getElementById('hotelModal');
      const closeModal = document.querySelector('.close');
      closeModal.addEventListener('click', cerrarModal);
      window.addEventListener('click', e => {
        if (e.target === modal) cerrarModal();
      });
    
      // Establecer fecha mínima en los inputs de fecha
      const hoy = new Date().toISOString().split('T')[0];
      document.getElementById('fechaEntrada').setAttribute('min', hoy);
      document.getElementById('fechaSalida').setAttribute('min', hoy);
    });
    
});

function limpiarErrores() {
  const errores = document.querySelectorAll('.error-msg');
  errores.forEach(el => el.textContent = '');
}

function mostrarError(message) {
  const hotelesContainer = document.getElementById('hoteles');
  hotelesContainer.innerHTML = `<p style="color: red;">${message}</p>`;
}

function cargarHoteles() {
  fetch('/hoteles')
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al cargar los hoteles:', error);
      mostrarError('Hubo un problema al cargar los hoteles.');
    });
}

function filtrarHotelesDisponibles() {
  limpiarErrores();

  const fechaEntrada = document.getElementById('fechaEntrada').value;
  const fechaSalida = document.getElementById('fechaSalida').value;

  // Validar fechas antes de continuar
  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0); // Quitar hora para comparar solo fechas

  if (!fechaEntrada || !fechaSalida) {
    mostrarError('❌ Debes seleccionar ambas fechas: entrada y salida.');
    return;
  }

  const entrada = new Date(fechaEntrada);
  const salida = new Date(fechaSalida);

  if (entrada < hoy || salida < hoy) {
    mostrarError('❌ Las fechas no pueden ser anteriores a hoy.');
    return;
  }

  if (entrada >= salida) {
    mostrarError('❌ La fecha de entrada debe ser anterior a la fecha de salida.');
    return;
  }

  // Si pasa validación, continuar con el filtrado

  const tipoDeHotel = document.getElementById('tipoDeHotel').value;
  const comunidad = document.getElementById('comunidad').value;
  const numeroAdultos = document.getElementById('numeroAdultos').value;
  const numeroNinos = document.getElementById('numeroNinos').value;
  const precioMin = document.getElementById('precioMin').value;
  const precioMax = document.getElementById('precioMax').value;

  const params = new URLSearchParams();
  params.append("fechaEntrada", fechaEntrada);
  params.append("fechaSalida", fechaSalida);

  if (tipoDeHotel) params.append("tipoDeHotel", tipoDeHotel);
  if (comunidad) params.append("comunidad", comunidad);
  if (numeroAdultos) params.append("numeroAdultos", numeroAdultos);
  if (numeroNinos) params.append("numeroNinos", numeroNinos);
  if (precioMin) params.append("precioMin", precioMin);
  if (precioMax) params.append("precioMax", precioMax);

  fetch(`/hoteles?${params.toString()}`)
    .then(response => response.json())
    .then(hoteles => {
      mostrarHoteles(hoteles);
    })
    .catch(error => {
      console.error('Error al filtrar los hoteles:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

function mostrarHoteles(hoteles) {
  const hotelesContainer = document.getElementById('hoteles');
  hotelesContainer.innerHTML = '';

  if (!Array.isArray(hoteles) || hoteles.length === 0) {
    hotelesContainer.innerHTML = '<p>No se encontraron hoteles que coincidan con los filtros.</p>';
    return;
  }

  hoteles.forEach(hotel => {
    const hotelDiv = document.createElement('div');
    hotelDiv.className = 'hotel';

    const nombre = hotel.nombre || 'Nombre no disponible';
    const tipo = hotel.tipo || 'No especificado';
    const descripcion = hotel.descripcion || 'Descripción no disponible';
    const comunidad = hotel.comunidad || 'No especificado';
    const precio = (hotel.precio_habitacion_min !== undefined && hotel.precio_habitacion_min !== null)
      ? `${hotel.precio_habitacion_min}€`
      : 'No disponible';
    const imagen = hotel.imagen ? `/${hotel.imagen}` : '/img/default.jpg';

    hotelDiv.innerHTML = `
      <div class="hotel-card">
        <img src="${imagen}" alt="Imagen de ${nombre}" class="hotel-img">
        <div class="hotel-info">
          <h2>${nombre}</h2>
          <p><strong>Descripción:</strong> ${descripcion}</p>
          <p><strong>Tipo:</strong> ${tipo}</p>
          <p><strong>Comunidad:</strong> ${comunidad}</p>
          <p><strong>Precio mínimo:</strong> ${precio}</p>
        </div>
      </div>
    `;

    hotelDiv.addEventListener('dblclick', () => mostrarDetallesHotel(hotel));

    hotelesContainer.appendChild(hotelDiv);
  });
}

function cerrarModal() {
  const modal = document.getElementById('hotelModal');
  modal.classList.add('hide');
  setTimeout(() => {
    modal.style.display = 'none';
    modal.classList.remove('hide');
  }, 300);
}
document.addEventListener('click', e => {
  if (e.target.matches('.btn-reservar')) {
    const roomItem = e.target.closest('.room-item');
    const roomId = e.target.dataset.roomId;
    const roomName = roomItem.querySelector('.room-name').textContent;
    const roomPrice = roomItem.querySelector('.room-price').textContent;
    iniciarReserva(window.currentHotel, { id: roomId, nombre: roomName, precio: roomPrice });
  }
});

function mostrarDetallesHotel(hotel) {
  // 0) Guardar el hotel "activo" globalmente para la reserva
  window.currentHotel = hotel;

  // 0.1) Leer las fechas de búsqueda desde los inputs
  const feBusqueda = document.getElementById('fechaEntrada').value;
  const fsBusqueda = document.getElementById('fechaSalida').value;

  // 1) Referencias al modal y sus elementos
  const modal = document.getElementById('hotelModal');
  const modalTitle = document.getElementById('modal-title');
  const modalBody = document.getElementById('modal-body');
  const modalImage = document.getElementById('modal-image');
  const roomList = document.getElementById('room-list');

  // 2) Título e imagen
  modalTitle.textContent = hotel.nombre || 'Detalles del Hotel';
  if (hotel.imagen) {
    modalImage.src = `/${hotel.imagen}`;
    modalImage.style.display = 'block';
  } else {
    modalImage.style.display = 'none';
  }

  // 3) Construir listado de detalles con fallback para entrada/salida
  let detallesHtml = '<ul>';

  // Entrada
  if (feBusqueda) {
    const fechaE = new Date(feBusqueda)
      .toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
    detallesHtml += `<li><strong>Entrada (búsqueda):</strong> ${fechaE}</li>`;
  } else if (hotel.available_from) {
    const fechaE = new Date(hotel.available_from)
      .toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
    detallesHtml += `<li><strong>Entrada:</strong> ${fechaE}</li>`;
  }

  // Salida
  if (fsBusqueda) {
    const fechaS = new Date(fsBusqueda)
      .toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
    detallesHtml += `<li><strong>Salida (búsqueda):</strong> ${fechaS}</li>`;
  } else if (hotel.available_to) {
    const fechaS = new Date(hotel.available_to)
      .toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
    detallesHtml += `<li><strong>Salida:</strong> ${fechaS}</li>`;
  }

  // Campos a ocultar del mapeo dinámico
  const ocultar = [
    'disponibilidad', 'permite_mascotas', 'imagen2',
    'habitaciones', 'id', 'precio', 'imagen', 'numero_habitaciones',
    'available_from', 'available_to'
  ];
  // Etiquetas personalizadas
  const labelMap = {
    numero_habitaciones: 'Número de habitaciones',
    capacidad: 'Capacidad'
  };

  // Añadir el resto de propiedades de hotel
  detallesHtml += Object.entries(hotel)
    .filter(([key]) => !ocultar.includes(key))
    .map(([key, val]) => {
      let value = val;
      // Formatear fechas ISO
      if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(value)) {
        value = new Date(value).toLocaleDateString('es-ES', {
          year: 'numeric', month: 'long', day: 'numeric'
        });
      }
      const label = labelMap[key]
        || key.replace(/_/g, ' ')
          .replace(/\b\w/g, c => c.toUpperCase());
      return `<li><strong>${label}:</strong> ${value ?? 'No disponible'}</li>`;
    })
    .join('');
  detallesHtml += '</ul>';

  modalBody.innerHTML = detallesHtml;

  // 4) Renderizar habitaciones disponibles
  let habitaciones = [];
  if (hotel.habitaciones) {
    habitaciones = Array.isArray(hotel.habitaciones)
      ? hotel.habitaciones
      : JSON.parse(hotel.habitaciones);
  }

  const roomsHtml = habitaciones.length > 0
    ? habitaciones.map(r => `
        <div class="room-item">
          <span class="room-name">${r.nombre || 'Habitación'}</span>
          <span class="room-price">${parseFloat(r.precio).toFixed(2)} €</span>
          <button class="btn-reservar" data-room-id="${r.id_habitacion || r.id}">
            Reservar
          </button>
        </div>
      `).join('')
    : `<p>No hay habitaciones disponibles.</p>`;
  roomList.innerHTML = roomsHtml;

  // 5) Mostrar modal
  modal.classList.remove('hide');
  modal.style.display = 'flex';
}


async function iniciarReserva(hotel, room) {
  const modalInfo = document.querySelector('.modal-info-rooms');
  const container = document.getElementById('reservation-container');
  if (!modalInfo || !container) return;

  // 1) Usuario
  const user = window.currentUser;
  if (!user) {
    alert('❌ Debes iniciar sesión para reservar.');
    return;
  }
  const { nombre, apellidos, correo, telefono, id: id_usuario } = user;
  if (!nombre || !apellidos || !correo || !telefono) {
    alert('❌ Completa tu perfil con todos los datos.');
    return;
  }

  // 2) Fechas
  const fe = document.getElementById('fechaEntrada').value;
  const fs = document.getElementById('fechaSalida').value;
  if (!fe || !fs) {
    alert('❌ Selecciona fechas de entrada y salida.');
    return;
  }
  const fmtDate = iso => new Date(iso).toLocaleDateString('es-ES', {
    year: 'numeric', month: 'long', day: 'numeric'
  });

  // 3) Render formulario
  modalInfo.style.display = 'none';
  container.style.display = 'block';
  container.innerHTML = `
  <div class="reservation-card">
    <div class="reservation-left">
      <div class="reservation-details">
        <h2>${hotel.nombre}</h2>
        <p><strong>Descripción:</strong> ${hotel.descripcion || '-'}</p>
        <p><strong>Tipo:</strong> ${hotel.tipo}</p>
        <p><strong>Capacidad:</strong> ${hotel.capacidad} personas</p>
        <p><strong>Entrada:</strong> ${fmtDate(fe)}</p>
        <p><strong>Salida:</strong> ${fmtDate(fs)}</p>
        <hr>
        <p><strong>Habitación:</strong> ${room.nombre}</p>
        <p><strong>Precio:</strong> ${parseFloat(room.precio).toFixed(2)} €</p>
      </div>
    </div>
    <div class="reservation-right">
      <form id="payment-form" class="payment-form" novalidate>
        <h3>Datos de pago</h3>
        <div class="form-group">
          <label>Nombre en tarjeta</label>
          <input type="text" name="nombreTarjeta" required>
          <small class="error-msg"></small>
        </div>
        <div class="form-group">
          <label>N.º de tarjeta</label>
          <input type="text" name="numeroTarjeta" required maxlength="16" pattern="\\d{16}" title="16 dígitos">
          <small class="error-msg"></small>
        </div>
        <div class="form-group">
          <label>Caducidad (MM/AA)</label>
          <input type="text" name="caducidadTarjeta" required maxlength="5" placeholder="MM/AA"
                 pattern="(0[1-9]|1[0-2])\\/\\d{2}" title="Formato MM/AA">
          <small class="error-msg"></small>
        </div>
        <div class="form-group">
          <label>CVV</label>
          <input type="text" name="cvv" required maxlength="3" pattern="\\d{3}" title="3 dígitos">
          <small class="error-msg"></small>
        </div>
        <div class="buttons">
          <button type="button" id="cancel-reservation">Volver</button>
          <button type="submit">Pagar y reservar</button>
        </div>
      </form>
    </div>
  </div>
`;


  // Formato inputs
  container.querySelector('input[name=numeroTarjeta]')
    .addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g, '').slice(0, 16));
  container.querySelector('input[name=cvv]')
    .addEventListener('input', e => e.target.value = e.target.value.replace(/\D/g, '').slice(0, 3));
  container.querySelector('input[name=caducidadTarjeta]')
    .addEventListener('input', e => {
      let v = e.target.value.replace(/\D/g, '').slice(0, 4);
      if (v.length > 2) v = v.slice(0, 2) + '/' + v.slice(2);
      e.target.value = v;
    });

  // Botón volver
  document.getElementById('cancel-reservation').onclick = () => {
    container.innerHTML = '';
    container.style.display = 'none';
    modalInfo.style.display = '';
  };

  // Submit
  const form = document.getElementById('payment-form');
  form.onsubmit = async e => {
    e.preventDefault();

    // Validación
    let valid = true;
    form.querySelectorAll('.form-group').forEach(group => {
      const inp = group.querySelector('input');
      const err = group.querySelector('.error-msg');
      if (!inp.checkValidity()) {
        valid = false;
        err.textContent = inp.validity.valueMissing
          ? 'Obligatorio'
          : (inp.validity.patternMismatch ? inp.title : 'Inválido');
      } else {
        err.textContent = '';
      }
    });
    if (!valid) return;

    // Datos de pago
    const pago = {
      nombreTarjeta: form.nombreTarjeta.value.trim(),
      numeroTarjeta: form.numeroTarjeta.value.trim(),
      cvv: form.cvv.value.trim(),
      caducidadTarjeta: form.caducidadTarjeta.value.trim()
    };

    // Datos de reserva
    const reserva = {
      hotelId: hotel.id,
      roomId: room.id,
      id_usuario,
      nombre_usuario: nombre,
      apellidos_usuario: apellidos,
      correo_usuario: correo,
      telefono_usuario: telefono,
      nombre_hotel: hotel.nombre,
      nombre_habitacion: room.nombre,
      fecha_inicio: fe,
      fecha_salida: fs
    };

    try {
      // 1) Guardar info_pagos
      const rp = await fetch('/info_pagos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pago)
      });
      const dp = await rp.json();
      if (!rp.ok || !dp.success) throw new Error('Error al guardar info_pagos');
      console.log('✅ Pago guardado:', dp.id_infoPago);

      // 2) Guardar reserva
      reserva.id_infoPago = dp.id_infoPago;
      const rr = await fetch('/reservar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reserva)
      });
      const dr = await rr.json();
      if (!rr.ok || !dr.success) throw new Error('Error al guardar reserva');
      console.log('✅ Reserva guardada:', dr.idReserva);

      alert('✅ ¡Reserva completada correctamente!');
      container.innerHTML = '';
      cerrarModal();
      location.reload();

    } catch (err) {
      console.error('❌ Error en reserva:', err);
      alert('❌ ' + (err.message || 'Ocurrió un error inesperado.'));
    }
  };
}

function filtrarPorTipoDeHotel(tipoDeHotel = "") {
  if (!tipoDeHotel) {
    tipoDeHotel = document.getElementById('tipoDeHotel').value.trim().toLowerCase();
  }
  if (!tipoDeHotel) {
    cargarHoteles();
    return;
  }
  fetch(`/hoteles?tipoDeHotel=${encodeURIComponent(tipoDeHotel)}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar por tipo:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

function filtrarPorComunidadAutonomas() {
  const comunidad = document.getElementById('comunidad').value.trim().toLowerCase();
  if (!comunidad) {
    cargarHoteles();
    return;
  }
  fetch(`/hoteles?comunidad=${encodeURIComponent(comunidad)}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar por comunidad:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}
