// ---------------------------- FILTRAR POR PLATOS ----------------------------
function filtrarPlatos() {
  const ingredientes = document.getElementById('ingredientes').value.trim();
  
  // Dividir los ingredientes por coma y eliminar entradas vacías
  const ingredientesArray = ingredientes 
      ? ingredientes.split(',').map(ing => ing.trim()).filter(ing => ing !== '') 
      : [];

  // Realizar la solicitud al servidor para obtener los platos filtrados
  const ingredientesQuery = encodeURIComponent(ingredientesArray.join(','));
  
  fetch(`/platos?ingredientes=${ingredientesQuery}`)
    .then(response => response.json())
    .then(platos => mostrarPlatos(platos))
    .catch(error => {
      console.error('Error:', error);
      mostrarError('Hubo un problema al obtener los platos. Intenta de nuevo.');
    });
}

// ---------------------------- FILTRAR POR NOMBRE PLATO ----------------------------
function filtrarPorNombre() {
  const nombre = document.getElementById('nombre').value.trim().toLowerCase();
  
  // Realizar la solicitud al servidor para obtener los platos filtrados por nombre
  const nombreQuery = encodeURIComponent(nombre);
  
  fetch(`/platos?nombre=${nombreQuery}`)
    .then(response => response.json())
    .then(platos => mostrarPlatos(platos))
    .catch(error => {
      console.error('Error:', error);
      mostrarError('Hubo un problema al obtener los platos. Intenta de nuevo.');
    });
}

// ---------------------------- FUNCION MOSTRAR PLATOS ----------------------------
function mostrarPlatos(platos) {
  const platosContainer = document.getElementById('platos');
  platosContainer.innerHTML = '';

  if (platos.length > 0) {
    platos.forEach(plato => {
      const platoDiv = document.createElement('div');
      platoDiv.className = 'plato';
      platoDiv.innerHTML = `
        <h2>${plato.nombre}</h2>
        <p><strong>Ingredientes:</strong> ${plato.ingredientes.join(', ')}</p>
      `;
      platosContainer.appendChild(platoDiv);
    });
  } else {
    platosContainer.innerHTML = '<p>No se encontraron platos que coincidan con los filtros.</p>';
  }
}

// Función para mostrar un mensaje de error en la interfaz
function mostrarError(message) {
  const platosContainer = document.getElementById('platos');
  platosContainer.innerHTML = `<p style="color: red;">${message}</p>`;
}

// ---------------------------- FILTRAR POR CANTIDAD INGREDIENTES ----------------------------
function filtrarPorCantidadIngredientes() {
  const cantidad = document.getElementById('cantidadIngredientes').value;

  // Convertimos la cantidad seleccionada a un número
  const cantidadSeleccionada = parseInt(cantidad);

  if (isNaN(cantidadSeleccionada) || cantidadSeleccionada <= 0) {
    mostrarError('Por favor, selecciona una cantidad válida de ingredientes.');
    return;
  }

  // Realizamos la solicitud al servidor para obtener platos
  fetch(`/platos`)
    .then(response => {
      if (!response.ok) {
        throw new Error('Error al obtener la lista de platos');
      }
      return response.json();
    })
    .then(platos => {
      // Validar que cada plato tenga un array de ingredientes y filtrar correctamente
      const platosFiltrados = platos.filter(plato => 
        Array.isArray(plato.ingredientes) && plato.ingredientes.length === cantidadSeleccionada
      );

      if (platosFiltrados.length === 0) {
        mostrarError(`No se encontraron platos con exactamente ${cantidadSeleccionada} ingredientes.`);
      } else {
        mostrarPlatos(platosFiltrados);
      }
    })
    .catch(error => {
      console.error('Error:', error);
      mostrarError('Hubo un problema al filtrar los platos. Intenta de nuevo.');
    });
}

// ---------------------------- CARGAR INGREDIENTES EN EL SELECT ----------------------------
function cargarIngredientes() {
  fetch('/platos')
    .then(response => response.json())
    .then(platos => {
      const ingredientesUnicos = new Set(); // Usamos Set para evitar duplicados
      platos.forEach(plato => {
        plato.ingredientes.forEach(ingrediente => ingredientesUnicos.add(ingrediente));
      });

      const select = document.getElementById('selectIngredientes');
      ingredientesUnicos.forEach(ingrediente => {
        const option = document.createElement('option');
        option.value = ingrediente;
        option.textContent = ingrediente;
        select.appendChild(option);
      });
    })
    .catch(error => {
      console.error('Error al cargar los ingredientes:', error);
    });
}

// ---------------------------- FILTRAR POR INGREDIENTE SELECCIONADO ----------------------------
function filtrarPorIngredienteSeleccionado() {
  const ingredienteSeleccionado = document.getElementById('selectIngredientes').value.trim();
  
  if (!ingredienteSeleccionado) {
    mostrarError('Por favor, selecciona un ingrediente.');
    return;
  }

  fetch(`/platos?ingredientes=${encodeURIComponent(ingredienteSeleccionado)}`)
    .then(response => response.json())
    .then(platos => mostrarPlatos(platos))
    .catch(error => {
      console.error('Error al filtrar los platos por ingrediente:', error);
      mostrarError('Hubo un problema al obtener los platos. Intenta de nuevo.');
    });
}

// Llamar a cargarIngredientes cuando la página se carga
document.addEventListener('DOMContentLoaded', cargarIngredientes);
