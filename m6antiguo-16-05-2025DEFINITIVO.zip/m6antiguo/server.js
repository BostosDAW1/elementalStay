const session = require('express-session');
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');
const cookieParser = require('cookie-parser');
const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use(session({
  name: 'sid',
  secret: 'un-secreto-muy-seguro',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    maxAge: 1000 * 60 * 60  // 1 hora
  }
}));

app.get('/favicon.ico', (req, res) => res.status(204).end());

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ---------------- Conexión a la base de datos ----------------
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'P@ssw0rd',
  database: 'hoteles_db'
});

// Ruta para obtener usuario autenticado
app.get('/api/usuario-autenticado', (req, res) => {
  if (req.session && req.session.usuario) {
    res.json({ usuario: req.session.usuario });
  } else {
    res.status(401).json({ mensaje: 'No autenticado' });
  }
});

db.connect(err => {
  if (err) {
    console.error('❌ Error al conectar a la base de datos:', err.message);
    process.exit(1);
  }
  console.log('✅ Conectado a MySQL');
});

const promiseDB = db.promise();
// ---------------- RUTA: Consultar Hoteles ----------------
app.get('/hoteles', (req, res) => {
  const {
    tipoDeHotel, comunidad, disponibilidad,
    precioMin, precioMax, fechaEntrada, fechaSalida,
    numeroAdultos, numeroNinos, numeroHabitaciones, llevoMascota
  } = req.query;

  const totalPersonas = (parseInt(numeroAdultos) || 0) + (parseInt(numeroNinos) || 0);

  let query = `
    SELECT 
      h.*,
      (
        SELECT MIN(ha.precio)
        FROM habitaciones ha
        WHERE ha.id_hotel = h.id
          ${precioMin ? "AND ha.precio >= ?" : ""}
          ${precioMax ? "AND ha.precio <= ?" : ""}
          ${totalPersonas ? "AND ha.capacidad >= ?" : ""}
          ${fechaEntrada && fechaSalida ? `
            AND NOT EXISTS (
              SELECT 1 
              FROM reservas r
              WHERE r.id_habitacion = ha.id_habitacion
                AND r.fecha_inicio < ?
                AND r.fecha_salida > ?
            )
          ` : ""}
      ) AS precio_habitacion_min,
      COALESCE(
        (
          SELECT JSON_ARRAYAGG(
            JSON_OBJECT(
              'id', ha.id_habitacion,
              'nombre', ha.nombre,
              'precio', ha.precio,
              'capacidad', ha.capacidad
            )
          )
          FROM habitaciones ha
          WHERE ha.id_hotel = h.id
            ${precioMin ? "AND ha.precio >= ?" : ""}
            ${precioMax ? "AND ha.precio <= ?" : ""}
            ${totalPersonas ? "AND ha.capacidad >= ?" : ""}
            ${fechaEntrada && fechaSalida ? `
              AND NOT EXISTS (
                SELECT 1 
                FROM reservas r
                WHERE r.id_habitacion = ha.id_habitacion
                  AND r.fecha_inicio < ?
                  AND r.fecha_salida > ?
              )
            ` : ""}
        ),
        JSON_ARRAY()
      ) AS habitaciones
    FROM hoteles h
    WHERE 1=1
  `;

  const filtros = [];
  const params = [];

  // Parámetros para ambas subconsultas (se repiten)
  if (precioMin) filtros.push(precioMin);
  if (precioMax) filtros.push(precioMax);
  if (totalPersonas) filtros.push(totalPersonas);
  if (fechaEntrada && fechaSalida) filtros.push(fechaSalida, fechaEntrada);
  if (precioMin) filtros.push(precioMin);
  if (precioMax) filtros.push(precioMax);
  if (totalPersonas) filtros.push(totalPersonas);
  if (fechaEntrada && fechaSalida) filtros.push(fechaSalida, fechaEntrada);

  // Filtros sobre hoteles
  if (tipoDeHotel) {
    query += " AND h.tipo LIKE ?";
    params.push(`%${tipoDeHotel}%`);
  }
  if (comunidad) {
    query += " AND LOWER(h.comunidad) LIKE ?";
    params.push(`%${comunidad.toLowerCase()}%`);
  }
  if (disponibilidad) {
    query += " AND h.disponibilidad = ?";
    params.push(disponibilidad === 'true' ? 1 : 0);
  }
  if (fechaEntrada && fechaSalida) {
    query += " AND h.available_from <= ? AND h.available_to >= ?";
    params.push(fechaEntrada, fechaSalida);
  }
  if (numeroHabitaciones) {
    query += " AND h.numero_habitaciones >= ?";
    params.push(numeroHabitaciones);
  }
  if (llevoMascota) {
    query += " AND h.permite_mascotas = ?";
    params.push(llevoMascota === 'true' ? 1 : 0);
  }

  // Asegurar al menos una habitación válida
  if (precioMin || precioMax || totalPersonas || (fechaEntrada && fechaSalida)) {
    query += `
      AND EXISTS (
        SELECT 1 
        FROM habitaciones ha
        WHERE ha.id_hotel = h.id
          ${precioMin ? "AND ha.precio >= ?" : ""}
          ${precioMax ? "AND ha.precio <= ?" : ""}
          ${totalPersonas ? "AND ha.capacidad >= ?" : ""}
          ${fechaEntrada && fechaSalida ? `
            AND NOT EXISTS (
              SELECT 1 
              FROM reservas r
              WHERE r.id_habitacion = ha.id_habitacion
                AND r.fecha_inicio < ?
                AND r.fecha_salida > ?
            )
          ` : ""}
      )
    `;
    if (precioMin) params.push(precioMin);
    if (precioMax) params.push(precioMax);
    if (totalPersonas) params.push(totalPersonas);
    if (fechaEntrada && fechaSalida) params.push(fechaSalida, fechaEntrada);
  }

  db.query(query, [...filtros, ...params], (err, results) => {
    if (err) {
      console.error('Error al obtener los hoteles:', err);
      return res.status(500).json({ error: 'Error al obtener hoteles' });
    }

    // Imprime los resultados crudos para depuración
    console.log('←←← RAW RESULTS:', JSON.stringify(results, null, 2));

    // 1) Filtrar hoteles sin habitación
    results = results.filter(h => h.precio_habitacion_min !== null);

    // 2) Convertir el JSON de 'habitaciones' en array real
    results = results.map(h => {
      if (typeof h.habitaciones === 'string') {
        try {
          h.habitaciones = JSON.parse(h.habitaciones);
        } catch {
          h.habitaciones = [];
        }
      }
      return h;
    });

    // 3) Enviar respuesta
    res.json(results);
  });
});


// al principio del fichero, tras tus requires y db.connect…
const util = require('util');
const query = util.promisify(db.query).bind(db);

// POST /info_pagos
app.post('/info_pagos', async (req, res) => {
  console.log('>>> LLEGA /info_pagos:', req.body);
  const { nombreTarjeta, numeroTarjeta, cvv, caducidadTarjeta } = req.body;
  try {
    const [result] = await db.promise().execute(
      `INSERT INTO info_pagos
         (nombreTarjeta, numeroTarjeta, cvv, caducidadTarjeta)
       VALUES (?, ?, ?, ?)`,
      [nombreTarjeta, numeroTarjeta, cvv, caducidadTarjeta]
    );
    console.log('<<< INSERT info_pagos id:', result.insertId);
    return res.json({ success: true, id_infoPago: result.insertId });
  } catch (err) {
    console.error('❌ Error en /info_pagos:', err);
    return res.status(500).json({ success: false, error: 'Error al guardar info_pagos' });
  }
});

// RUTA: Obtener las reservas del usuario logueado
// En app.js (o donde definas tus rutas)
app.get('/mis-reservas', async (req, res) => {
  if (!req.session || !req.session.usuario) {
    return res.status(401).json({ error: 'No autenticado' });
  }

  const id_usuario = req.session.usuario.id;

  try {
    // Antes de res.json(rows);
    const [rows] = await db.promise().query(
      `SELECT
        r.idreserva               AS id,
        r.nombre_hotel,
        r.nombre_habitacion,
        r.fecha_inicio,
        r.fecha_salida,
        r.nombre         AS nombre_usuario,
        r.apellidos,
        r.correo,
        r.telefono,
        h.precio,
        h.imagen
      FROM reservas AS r
      JOIN hoteles  AS h  ON r.id_hotel = h.id
      WHERE r.id_usuario = ?
      ORDER BY r.fecha_inicio DESC`,
      [id_usuario]
    );

    // Comprueba en consola del servidor:
    console.log('→ Filas de mis-reservas:', rows);
    res.json(rows);
  } catch (err) {
    console.error('Error en /mis-reservas:', err);
    res.status(500).json({ error: 'Error al obtener tus reservas' });
  }
});

// DELETE /reserva/:id
app.delete('/reserva/:id', async (req, res) => {
  if (!req.session?.usuario) {
    return res.status(401).json({ error: 'No autenticado' });
  }
  const idreserva = req.params.id;
  try {
    // Asegúrate de que la reserva pertenece al usuario
    const [check] = await db.promise().query(
      'SELECT id_usuario FROM reservas WHERE idreserva = ?',
      [idreserva]
    );
    if (!check.length || check[0].id_usuario !== req.session.usuario.id) {
      return res.status(403).json({ error: 'No tienes permiso' });
    }
    await db.promise().query(
      'DELETE FROM reservas WHERE idreserva = ?',
      [idreserva]
    );
    res.json({ success: true });
  } catch (err) {
    console.error('Error al cancelar reserva:', err);
    res.status(500).json({ error: 'Error al cancelar reserva' });
  }
});


// ————— RUTA DE RESERVA (usa ya info_pagos hecho arriba) —————
app.post('/reservar', async (req, res) => {
  console.log('>>> LLEGA /reservar:', req.body);
  const {
    hotelId, roomId, id_usuario,
    nombre_usuario, apellidos_usuario,
    correo_usuario, telefono_usuario,
    nombre_hotel, nombre_habitacion,
    fecha_inicio, fecha_salida,
    id_infoPago
  } = req.body;

  if (!id_usuario) {
    return res.status(401).json({ success: false, error: 'No autenticado' });
  }
  if (!nombre_usuario || !apellidos_usuario || !correo_usuario || !telefono_usuario) {
    return res.status(400).json({ success: false, error: 'Faltan datos de usuario' });
  }

  try {
    await db.promise().query('START TRANSACTION');

    const [resResult] = await db.promise().execute(
      `INSERT INTO reservas
         (id_hotel, id_habitacion, id_usuario,
          nombre, apellidos, correo, telefono,
          nombre_hotel, nombre_habitacion,
          fecha_inicio, fecha_salida, id_infoPago)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        hotelId, roomId, id_usuario,
        nombre_usuario, apellidos_usuario,
        correo_usuario, telefono_usuario,
        nombre_hotel, nombre_habitacion,
        fecha_inicio, fecha_salida, id_infoPago
      ]
    );

    await db.promise().query('COMMIT');
    console.log('<<< INSERT reservas id:', resResult.insertId);
    return res.json({ success: true, idReserva: resResult.insertId });
  } catch (err) {
    await db.promise().query('ROLLBACK');
    console.error('❌ Error en /reservar:', err);
    return res.status(500).json({ success: false, error: 'Error al guardar reserva' });
  }
});


// Después
app.get('/usuario', (req, res) => {
  if (req.session && req.session.usuario) {
    // Devuelve el objeto usuario que guardaste en la sesión
    return res.json(req.session.usuario);
  }
  res.status(401).send("No autenticado");
});

// RUTA: Página de registro
app.get('/registro', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'registro', 'registro.html'));
});

// RUTA: Página de inicio de sesión
app.get('/inicio_sesion', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'inicio_sesion', 'inicio_sesion.html'));
});

// RUTA: Logout
app.get('/logout', (req, res) => {
  // destruye la sesión
  req.session.destroy(err => {
    if (err) console.error('Error destruyendo sesión:', err);
    // borra la cookie de sesión en el cliente
    res.clearCookie('sid');
    // redirige
    res.redirect('/inicio_sesion/inicio_sesion.html');
  });
});


// POST: Login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).send("Faltan datos de login.");
  }

  const queryUser = `
    SELECT * 
      FROM usuarios 
     WHERE username = ? 
       AND password = SHA2(?, 256)
     LIMIT 1
  `;
  db.query(queryUser, [username, password], (err, results) => {
    if (err) {
      console.error("Error en la base de datos:", err);
      return res.status(500).send(`
        <html>
          <head>
            <style>
              body {
                font-family: sans-serif;
                background: #f8d7da;
                color: #842029;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
              }
              .error-box {
                background: #f5c2c7;
                border: 1px solid #f5c2c7;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                text-align: center;
              }
              .error-box h1 {
                margin-bottom: 10px;
                font-size: 1.5rem;
              }
              .error-box p {
                margin: 0;
              }
            </style>
          </head>
          <body>
            <div class="error-box">
              <h1>No se pudo iniciar sesión...</h1>
                <p>Crendenciales incorrectas, intentar acordarte de tu usuario y contraseña...</p>
            </div>
          </body>
        </html>
      `);
    }

    if (results.length > 0) {
      // 1) Guardar el usuario en la sesión
      req.session.usuario = results[0];
      // 2) Redirigir al index
      return res.redirect('/index.html');
    }

    // Si no es un usuario normal, probamos admin
    const queryAdmin = `
      SELECT * 
        FROM admin 
       WHERE username = ? 
         AND password = SHA2(?, 256)
       LIMIT 1
    `;
    db.query(queryAdmin, [username, password], (err2, adminResults) => {
      if (err2) {
        console.error("Error en la base de datos (admin):", err2);
        return res.status(500).send(`
        <html>
          <head>
            <style>
              body {
                font-family: sans-serif;
                background: #f8d7da;
                color: #842029;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
              }
              .error-box {
                background: #f5c2c7;
                border: 1px solid #f5c2c7;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                text-align: center;
              }
              .error-box h1 {
                margin-bottom: 10px;
                font-size: 1.5rem;
              }
              .error-box p {
                margin: 0;
              }
            </style>
          </head>
          <body>
            <div class="error-box">
              <h1>500 — Error interno</h1>
              <p>Crendenciales incorrectas, intentar acordarte de tu usuario y contraseña...</p>
            </div>
          </body>
        </html>
      `);
      }
      if (adminResults.length > 0) {
        // Podrías también guardar datos de admin en sesión si lo necesitas
        req.session.usuario = { ...adminResults[0], isAdmin: true };
        return res.redirect('/');
      }
      return res.status(401).send("Credenciales inválidas.");
    });
  });
});


// POST: Registro
app.post('/register', (req, res) => {
  const { username, email, password, confirmPassword } = req.body;
  if (!username || !email || !password || !confirmPassword) {
    return res.status(400).send("Faltan datos en el registro.");
  }
  if (password !== confirmPassword) {
    return res.status(400).send("Las contraseñas no coinciden.");
  }
  const queryCheck = "SELECT * FROM usuarios WHERE username = ? OR correo = ? LIMIT 1";
  db.query(queryCheck, [username, email], (err, results) => {
    if (err) {
      console.error("Error al consultar la base de datos:", err);
      return res.status(500).send("Error interno en el servidor.");
    }
    if (results.length > 0) {
      return res.status(400).send("El nombre de usuario o el correo electrónico ya están registrados.");
    }
    const queryInsert = "INSERT INTO usuarios (username, correo, password) VALUES (?, ?, SHA2(?, 256))";
    db.query(queryInsert, [username, email, password], (err, insertResults) => {
      if (err) {
        console.error("Error al insertar el usuario:", err);
        return res.status(500).send("Error al registrar el usuario.");
      }
      res.send("¡Registro exitoso! Puedes iniciar sesión ahora.");
    });
  });
});

// POST: Actualización de datos de usuario
app.post('/updateUser', (req, res) => {
  const { username, nombre, apellidos, correo, telefono, pais, ciudad } = req.body;
  if (!username || !correo) {
    return res.status(400).json({ error: "Faltan datos requeridos" });
  }
  const query = `UPDATE usuarios 
                 SET nombre = ?, apellidos = ?, correo = ?, telefono = ?, pais = ?, ciudad = ? 
                 WHERE username = ?`;
  db.query(query, [nombre, apellidos, correo, telefono, pais, ciudad, username], (err, result) => {
    if (err) {
      console.error("Error al actualizar el usuario:", err);
      return res.status(500).json({ error: "Error al actualizar el usuario" });
    }
    const queryUser = "SELECT * FROM usuarios WHERE username = ? LIMIT 1";
    db.query(queryUser, [username], (err, results) => {
      if (err) {
        console.error("Error al obtener el usuario actualizado:", err);
        return res.status(500).json({ error: "Error al obtener datos actualizados" });
      }
      if (results.length > 0) {
        res.cookie("usuario", JSON.stringify(results[0]), { maxAge: 3600000, httpOnly: false });
        return res.json({ success: true, user: results[0] });
      } else {
        return res.status(404).json({ error: "Usuario no encontrado" });
      }
    });
  });
});

// ---------------- FIN DE LAS RUTAS ----------------
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});

// ---------------- API ADMINISTRATIVA ----------------

// 1) Hoteles
app.get('/api/admin/hoteles', (req, res) => {
  const sql = `SELECT id, nombre, comunidad, precio, disponibilidad FROM hoteles ORDER BY id`;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error al obtener hoteles:', err);
      return res.status(500).json({ error: 'Error al obtener hoteles' });
    }
    res.json(results);
  });
});

// 2) Usuarios
app.get('/api/admin/usuarios', (req, res) => {
  const sql = `SELECT id, username, nombre, apellidos, correo, telefono, pais, ciudad, admin FROM usuarios ORDER BY id`;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error al obtener usuarios:', err);
      return res.status(500).json({ error: 'Error al obtener usuarios' });
    }
    res.json(results);
  });
});

// 3) Reservas
app.get('/api/admin/reservas', (req, res) => {
  const sql = `
    SELECT
      r.idreserva AS id,
      u.username AS usuario,
      h.nombre   AS hotel,
      ha.nombre  AS habitacion,
      r.fecha_inicio AS desde,
      r.fecha_salida AS hasta
    FROM reservas r
    JOIN usuarios u      ON u.id = r.id_usuario
    JOIN habitaciones ha ON ha.id_habitacion = r.id_habitacion
    JOIN hoteles h       ON h.id = ha.id_hotel
    ORDER BY r.fecha_inicio DESC
  `;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error al obtener reservas:', err);
      return res.status(500).json({ error: 'Error al obtener reservas' });
    }
    res.json(results);
  });
});

// ———> Ahora sí servimos estáticos desde public
app.use(express.static(path.join(__dirname, 'public')));

// ELIMINAR 
// ———> Rutas DELETE
app.delete('/api/admin/hoteles/:id', (req, res) => {
  db.query('DELETE FROM hoteles WHERE id = ?', [req.params.id], (err) => {
    if (err) {
      console.error('Error al eliminar hotel:', err);
      return res.status(500).json({ error: 'No se pudo eliminar el hotel' });
    }
    res.json({ success: true });
  });
});

app.delete('/api/admin/usuarios/:id', (req, res) => {
  db.query('DELETE FROM usuarios WHERE id = ?', [req.params.id], (err) => {
    if (err) {
      console.error('Error al eliminar usuario:', err);
      return res.status(500).json({ error: 'No se pudo eliminar el usuario' });
    }
    res.json({ success: true });
  });
});

app.delete('/api/admin/reservas/:id', (req, res) => {
  db.query('DELETE FROM reservas WHERE idreserva = ?', [req.params.id], (err) => {
    if (err) {
      console.error('Error al eliminar reserva:', err);
      return res.status(500).json({ error: 'No se pudo eliminar la reserva' });
    }
    res.json({ success: true });
  });
});

// ———> Ahora sí servimos estáticos desde public
app.use(express.static(path.join(__dirname, 'public')));