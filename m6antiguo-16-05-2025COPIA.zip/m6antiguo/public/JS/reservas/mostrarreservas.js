// FUNCIONES PARA CARGAR LOS HOTELES 
document.addEventListener('DOMContentLoaded', () => {
    // ------------------------ 1) NAVBAR: menú hamburguesa + perfil/inicio sesión -------------------------
    const btnHamburger = document.getElementById('hamburger-btn');
    const navLinks     = document.querySelector('.navbar-left-links');

    btnHamburger.addEventListener('click', () => {
    navLinks.classList.toggle('show-mobile');
    const opened = navLinks.classList.contains('show-mobile');
    btnHamburger.setAttribute('aria-label', opened ? 'Cerrar menú' : 'Abrir menú');
    });

    fetch('/usuario', { credentials: 'include' })
    .then(res => {
        if (!res.ok) throw new Error('No autenticado');
        return res.json();
    })
    .then(() => {
        const loginLink = navLinks.querySelector('.btn-login');
        if (loginLink) loginLink.remove();
        if (!navLinks.querySelector('.btn-perfil')) {
        const li = document.createElement('li');
        li.innerHTML = '<a href="/perfil/perfil.html" class="btn-perfil">Ver perfil</a>';
        navLinks.appendChild(li);
        }
    })
    .catch(() => {
        console.log('Usuario no autenticado');
    });

    // ------------------------- 2) CARGAR Y RENDERIZAR RESERVAS -------------------------
    const container = document.getElementById('mis-reservas');
    container.innerHTML = '<p>Cargando reservas...</p>';

    fetch('/mis-reservas', { credentials: 'include' })
    .then(res => {
        if (!res.ok) throw new Error('Error ' + res.status);
        return res.json();
    })
    .then(reservas => {
        if (reservas.length === 0) {
        container.innerHTML = '<p>No tienes reservas registradas.</p>';
        return;
        }

        container.innerHTML = reservas.map(r => `
        <div class="reserva-card" data-id="${r.id}">
            <img src="${r.imagen ? '../' + r.imagen : 'https://via.placeholder.com/400x200?text=Sin+imagen'}" alt="Hotel">
            <h3>${r.nombre_hotel}</h3>
            <p><strong>Habitación:</strong> ${r.nombre_habitacion}</p>
            <p><strong>Desde:</strong> ${new Date(r.fecha_inicio).toLocaleDateString('es-ES')}</p>
            <p><strong>Hasta:</strong> ${new Date(r.fecha_salida).toLocaleDateString('es-ES')}</p>
            <p><strong>Precio:</strong> ${r.precio} €</p>
            <hr>
            <p><strong>Usuario:</strong> ${r.nombre_usuario} ${r.apellidos}</p>
            <p><strong>Correo:</strong> ${r.correo}</p>
            <p><strong>Teléfono:</strong> ${r.telefono}</p>
            <button class="btn-cancelar">Cancelar reserva</button>
        </div>
        `).join('');

        // ------------------------- 3) CANCELAR RESERVA con modal -------------------------
        const modal    = document.getElementById('confirm-modal');
        const btnYes   = document.getElementById('confirm-yes');
        const btnNo    = document.getElementById('confirm-no');

        document.querySelectorAll('.btn-cancelar').forEach(button => {
        button.addEventListener('click', e => {
            const card = e.target.closest('.reserva-card');
            const id   = card.dataset.id;

            // 3.1 Mostrar modal
            modal.classList.remove('hidden');

            // 3.2 “Sí, cancelar”
            btnYes.onclick = async () => {
            modal.classList.add('hidden');
            try {
                const res = await fetch(`/reserva/${id}`, {
                method: 'DELETE',
                credentials: 'include'
                });
                if (!res.ok) throw new Error('Error ' + res.status);

                card.remove();
                if (!document.querySelector('.reserva-card')) {
                container.innerHTML = '<p>No tienes reservas registradas.</p>';
                }
            } catch {
                alert('Error al cancelar la reserva.');
            }
            };

            // 3.3 “No”
            btnNo.onclick = () => {
            modal.classList.add('hidden');
            };
        });
        });
    })
    .catch(err => {
        console.error('Error cargando reservas:', err);
        container.innerHTML = '<p>Debes iniciar sesión para ver tus reservas.</p>';
    });
});
