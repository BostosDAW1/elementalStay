const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Datos de los platos ampliados
const platos = [
  { id: 1, nombre: 'Pizza Margherita', ingredientes: ['Tomate', 'Queso', 'Albahaca'] },
  { id: 2, nombre: 'Pasta Carbonara', ingredientes: ['Pasta', 'Bacon', 'Queso Parmesano'] },
  { id: 3, nombre: 'Ensalada César', ingredientes: ['Lechuga', 'Pollo', 'Queso Parmesano', 'Crutones'] },
  { id: 4, nombre: 'Sopa de Tomate', ingredientes: ['Tomate', 'Cebolla', 'Ajo'] },
  { id: 5, nombre: 'Hamburguesa Clásica', ingredientes: ['Pan', 'Carne de Res', 'Lechuga', 'Tomate', 'Queso'] },
  { id: 6, nombre: 'Tacos de Pollo', ingredientes: ['Tortilla', 'Pollo', 'Cebolla', 'Cilantro', 'Salsa'] },
  { id: 7, nombre: 'Sushi Roll California', ingredientes: ['Arroz', 'Aguacate', 'Cangrejo', 'Alga Nori'] },
  { id: 8, nombre: 'Paella Valenciana', ingredientes: ['Arroz', 'Pollo', 'Conejo', 'Judía Verde', 'Azafrán'] },
  { id: 9, nombre: 'Burrito de Carne', ingredientes: ['Tortilla', 'Carne de Res', 'Frijoles', 'Arroz', 'Queso'] },
  { id: 10, nombre: 'Ceviche de Pescado', ingredientes: ['Pescado', 'Cebolla', 'Limón', 'Cilantro', 'Ají'] },
  { id: 11, nombre: 'Pollo al Curry', ingredientes: ['Pollo', 'Curry', 'Leche de Coco', 'Arroz'] },
  { id: 12, nombre: 'Lasagna de Carne', ingredientes: ['Pasta', 'Carne Molida', 'Queso', 'Tomate', 'Albahaca'] },
  { id: 13, nombre: 'Risotto de Champiñones', ingredientes: ['Arroz Arborio', 'Champiñones', 'Queso Parmesano', 'Cebolla'] },
  { id: 14, nombre: 'Ramen Japonés', ingredientes: ['Fideos', 'Cerdo', 'Huevo', 'Alga Nori', 'Cebollín'] },
  { id: 15, nombre: 'Arepas Rellenas', ingredientes: ['Harina de Maíz', 'Pollo', 'Aguacate', 'Queso'] },
  { id: 16, nombre: 'Wrap Vegetariano', ingredientes: ['Tortilla', 'Lechuga', 'Tomate', 'Zanahoria', 'Hummus'] },
  { id: 17, nombre: 'Falafel', ingredientes: ['Garbanzos', 'Cebolla', 'Ajo', 'Perejil', 'Tahini'] },
  { id: 18, nombre: 'Churrasco', ingredientes: ['Carne de Res', 'Papas Fritas', 'Ensalada', 'Chimichurri'] },
  { id: 19, nombre: 'Milanesa Napolitana', ingredientes: ['Carne de Res', 'Queso', 'Jamón', 'Tomate', 'Orégano'] },
  { id: 20, nombre: 'Tarta de Manzana', ingredientes: ['Manzana', 'Azúcar', 'Harina', 'Canela', 'Mantequilla'] },
];

// Middleware para servir archivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

app.get('/platos', (req, res) => {
  const { ingredientes, nombre, cantidad } = req.query;
  let platosFiltrados = platos;

  // ------------ CONDICION FILTRAR POR INGREDIENTES ------------
  if (ingredientes) {
    const filtros = ingredientes.split(',').map(ing => ing.trim().toLowerCase());
    platosFiltrados = platosFiltrados.filter(plato =>
      filtros.every(filtro =>
        plato.ingredientes.map(ing => ing.toLowerCase()).includes(filtro)
      )
    );
  }

  // ------------ CONDICION FILTRAR POR NOMBRE DEL PLATO ------------
  if (nombre) {
    const filtroNombre = nombre.toLowerCase();
    platosFiltrados = platosFiltrados.filter(plato =>
      plato.nombre.toLowerCase().includes(filtroNombre)
    );
  }

  // ------------ CONDICION FILTRAR POR CANTIDAD DE INGREDIENTES ------------
  if (cantidad) {
    const cantidadNum = parseInt(cantidad);
    if (!isNaN(cantidadNum)) {
      platosFiltrados = platosFiltrados.filter(plato =>
        plato.ingredientes.length === cantidadNum
      );
    }
  }

  res.json(platosFiltrados);
});

app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
