<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <title>MVC - Modelo, Vista, Controlador - Jourmoly</title>
  <style>
    body {
      font-family: sans-serif;
      background-color: #f9f9f9;
      color: #333;
      margin: 0;
      padding: 0;
      text-align: center;
    }
    h1, h4 {
      margin: 0;
      padding: 10px;
    }
    h1 {
      background-color: #4f4caf;
      color: #fff;
      padding: 20px 0;
    }
    h4 {
      background-color: #6461b1;
      color: white;
      padding: 15px 0;
    }
    .hotel-container {
      width: calc(100% - 100px);
      margin: 50px auto;
      display: flex;
      flex-direction: column;
      gap: 20px;
    }
    .hotel-card {
      width: 100%;
      border: 2px solid #ddd;
      border-radius: 10px;
      overflow: hidden;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      background-color: white;
      display: flex;
      flex-direction: column;
    }
    .hotel-top {
      display: flex;
      flex-direction: row;
    }
    .hotel-image {
      width: 200px;
      background-color: #f5f5f5;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 10px;
    }
    .hotel-image img {
      max-width: 100%;
      max-height: 100%;
      object-fit: cover;
    }
    .hotel-info {
      padding: 10px;
      flex-grow: 1;
      display: flex;
      flex-direction: column;
      justify-content: center;
      text-align: left;
    }
    .hotel-info h3 {
      margin: 0;
      font-size: 1.6em;
      font-weight: bold;
    }
    .hotel-info p {
      margin: 5px 0;
      font-size: 1em;
    }
    .hotel-description {
      padding: 10px;
      background-color: #f9f9f9;
      font-size: 1em;
      color: #555;
      text-align: left;
    }
    .hotel-description p {
      margin: 0;
    }
    /* Estilos para habitaciones */
    .hotel-rooms {
      padding: 10px;
      background-color: #e9e9e9;
      margin-top: 15px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .room-card {
      background-color: #fff;
      margin: 10px 0;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .room-card p {
      margin: 5px 0;
    }
    /* Estilos para servicios */
    .hotel-services {
      padding: 10px;
      background-color: #e9e9e9;
      margin-top: 15px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .service-card {
      background-color: #fff;
      margin: 10px 0;
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .actions {
      margin-top: 10px;
      text-align: center;
      padding-bottom: 10px;
    }
    .actions a {
      color: white;
      text-decoration: none;
      padding: 10px;
      margin: 0 5px;
      background-color: #4f4caf;
      border-radius: 5px;
    }
    .actions a:hover {
      background-color: #6461b1;
    }
  </style>
</head>
<body>
  <h1>Elemental Stay</h1>
  <h4>Llistat de Hoteles disponibles</h4>
  <div class="hotel-container">
    <?php
    foreach ($listado as $hotel) {
    ?>
      <div class="hotel-card">
        <div class="hotel-top">
          <div class="hotel-image">
            <img src="<?= $config->get('imagePath') . $hotel['img']; ?>" alt="<?= $hotel['nombre']; ?>" />
          </div>
          <div class="hotel-info">
            <h3><?php echo $hotel['nombre']; ?></h3>
            <p><strong>Tipo:</strong> <?php echo $hotel['tipo_hotel']; ?></p>
            <p><strong>Comunidad:</strong> <?php echo $hotel['comunidad_autonoma']; ?></p>
            <p><strong>Precio/noche:</strong> $<?php echo $hotel['precio_noche']; ?></p>
          </div>
        </div>
        <div class="hotel-description">
          <p><?php echo $hotel['descripcion']; ?></p>
        </div>

        <!-- Habitaciones -->
        <div class="hotel-rooms">
          <h4>Habitaciones:</h4>
          <?php foreach ($hotel['habitaciones'] as $habitacion): ?>
            <div class="room-card">
              <p><strong>Nombre:</strong> <?php echo $habitacion['nombre']; ?></p>
              <p><strong>Capacidad:</strong> <?php echo $habitacion['capacidad']; ?></p>
              <p><strong>Personas:</strong> <?php echo $habitacion['personas']; ?></p>
              <p><strong>Metros cuadrados:</strong> <?php echo $habitacion['m2']; ?> m²</p>
              <p><strong>Wifi:</strong> <?php echo $habitacion['wifi'] ? 'Sí' : 'No'; ?></p>
              <p><strong>Complementos para infantes:</strong> <?php echo $habitacion['complementos_infantes'] ? 'Sí' : 'No'; ?></p>
            </div>
          <?php endforeach; ?>
        </div>

        <!-- Servicios -->
        <div class="hotel-services">
          <h4>Servicios:</h4>
          <?php foreach ($hotel['servicios'] as $servicio): ?>
            <div class="service-card">
              <p><?php echo $servicio['nombre']; ?></p>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="actions">
          <a href="index.php?controlador=HotelesCompletos&accion=modificarHotelesCompletos&id=<?= $hotel["id_hotel"]; ?>">Modificar</a>
          <a href="index.php?controlador=HotelesCompletos&accion=eliminarHotelesCompletos&id=<?= $hotel["id_hotel"]; ?>">Eliminar</a>
        </div>
      </div>
    <?php
    }
    ?>
  </div>
  <div class="actions">
    <a href="index.php?controlador=HotelesCompletos&accion=afegirHotelesCompletos">Afegir</a>
    <a href="index.php?controlador=Hoteles&accion=listarHoteles">Tornar</a>
  </div>
</body>
</html>
