<?php
class HotelesModel
{
    protected $db;
 
    public function __construct()
    {
        // Obtenemos la conexión mysqli mediante el singleton
        $this->db = SMysqli::singleton()->getConnection();
    }
 
    public function listadoHotelesTotal()
    {
        $sql = 'SELECT * FROM hoteles';
        $result = $this->db->query($sql);
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
        $hoteles = [];
        while ($row = $result->fetch_assoc()) {
            $hoteles[] = $row;
        }
        return $hoteles;
    }
    
    // Buscar hoteles según la comunidad autónoma
    public function buscarHotelesPorComunidad($comunidad)
    {
        $sql = "SELECT * FROM hoteles WHERE comunidad_autonoma = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("s", $comunidad);
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
        $hoteles = [];
        while ($row = $result->fetch_assoc()) {
            $hoteles[] = $row;
        }
        return $hoteles;
    }
    
    // Buscar hoteles que tengan al menos un número mínimo de habitaciones (por cantidad de habitaciones)
    public function buscarHotelesPorHabitaciones($numHabitaciones)
    {
        $sql = "SELECT h.*
                FROM hoteles h
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel
                GROUP BY h.id_hotel
                HAVING COUNT(ha.id_habitacion) >= ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $numHabitaciones);
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Buscar hoteles por comunidad y número de habitaciones (filtrado anterior)
    public function buscarHotelesPorComunidadYHabitaciones($comunidad, $numHabitaciones)
    {
        $sql = "SELECT h.*
                FROM hoteles h
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel
                WHERE h.comunidad_autonoma = ?
                GROUP BY h.id_hotel
                HAVING COUNT(ha.id_habitacion) >= ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("si", $comunidad, $numHabitaciones);
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // NUEVO MÉTODO: Buscar hoteles que tengan al menos una habitación cuya capacidad sea mayor o igual a $totalPersonas
    public function buscarHotelesPorCapacidad($totalPersonas)
    {
        $sql = "SELECT h.*
                FROM hoteles h
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel
                WHERE ha.capacidad >= ?
                GROUP BY h.id_hotel";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $totalPersonas);
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // NUEVO MÉTODO: Buscar hoteles por comunidad y capacidad de habitación
    public function buscarHotelesPorComunidadYCapacidad($comunidad, $totalPersonas)
    {
        $sql = "SELECT h.*
                FROM hoteles h
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel
                WHERE h.comunidad_autonoma = ? AND ha.capacidad >= ?
                GROUP BY h.id_hotel";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("si", $comunidad, $totalPersonas);
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
?>
