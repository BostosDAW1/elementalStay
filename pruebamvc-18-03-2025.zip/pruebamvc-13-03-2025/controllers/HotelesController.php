<?php
class HotelesController
{
    private $view;
    
    public function __construct()
    {
        // Instanciamos el motor de plantillas
        $this->view = new View();
    }
 
    public function listarHoteles()
    {
        require_once 'models/HotelesModel.php';
        $hoteles = new HotelesModel();
 
        // Recoger parámetros del formulario
        $destino = isset($_GET['destino']) ? trim($_GET['destino']) : '';
        $adultos = isset($_GET['adultos']) ? intval($_GET['adultos']) : 0;
        $ninos = isset($_GET['ninos']) ? intval($_GET['ninos']) : 0;
 
        // Calcular el total de personas requerido
        $totalPersonas = $adultos + $ninos;
 
        // Decidir qué método utilizar según los filtros:
        if (!empty($destino) && $totalPersonas > 0) {
            // Filtrar por comunidad y capacidad
            $listado = $hoteles->buscarHotelesPorComunidadYCapacidad($destino, $totalPersonas);
        } elseif (!empty($destino)) {
            // Filtrar solo por comunidad autónoma
            $listado = $hoteles->buscarHotelesPorComunidad($destino);
        } elseif ($totalPersonas > 0) {
            // Filtrar solo por capacidad (ocupación requerida)
            $listado = $hoteles->buscarHotelesPorCapacidad($totalPersonas);
        } else {
            // Si no hay filtros, obtener todos los hoteles
            $listado = $hoteles->listadoHotelesTotal();
        }
 
        // Preparar los datos para la vista
        $data['listado'] = $listado;
 
        // Mostrar la vista
        $this->view->show("Hoteles/Hoteleslistar.php", $data);
    }
}
?>
