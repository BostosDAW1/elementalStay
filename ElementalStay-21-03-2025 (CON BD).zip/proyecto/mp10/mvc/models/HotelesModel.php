<?php
class HotelesModel
{
    protected $db;
 
    public function __construct()
    {
        // Obtenemos la conexión mysqli mediante el singleton
        $this->db = SMysqli::singleton()->getConnection();
    }
 
    public function listadoHotelesTotal()
    {
        $sql = 'SELECT * FROM hoteles';
        $result = $this->db->query($sql);
        if (!$result) {
            die("Error en la consulta: " . $this->db->error);
        }
        // Retornamos el resultado (objeto mysqli_result)
        return $result;
    }
}
?>
