<?php
class HotelesController
{
    private $view;
    
    function __construct()
    {
        // Creamos una instancia de nuestro mini motor de plantillas
        $this->view = new View();
    }
 
    public function listarHoteles()
    {
        // Incluimos el modelo que corresponde
        require 'models/HotelesModel.php'; // Asegúrate de que la ruta sea correcta

        // Creamos una instancia de nuestro "modelo"
        $hoteles = new HotelesModel();
 
        // Le pedimos al modelo todos los hoteles
        $listado = $hoteles->listadoHotelesTotal();
 
        // Pasamos a la vista toda la información que se desea representar
        $data['listado'] = $listado;
 
        // Finalmente presentamos nuestra plantilla
        $this->view->show("views/hoteles/Hoteleslistar.php", $data);
    }
}

?>