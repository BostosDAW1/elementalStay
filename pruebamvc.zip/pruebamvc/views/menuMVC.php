<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu MVC - Elemental Stay</title>
</head>
<style>
    body {
    font-family: sans-serif;
    background-color: #f9f9f9;
    color: #333;
    text-align: center;
    margin: 0;
    padding: 0;
}

h1, h4 {
    margin: 0;
    padding: 10px;
}

h1 {
    background-color: #4f4caf;
    color: #fff;
}

table {
    width: 90%; /*APUNTAR COMO CAMBIOOO*/
    margin: 20px auto;
    border-collapse: collapse;
}

th, td {
    padding: 10px;
    border: 1px solid #ddd;
    text-align: center;
}

th {
    background-color: #4f4caf;
    color: #fff;
}

tr:hover {
    background-color: #ddd;
}

#acciones {
    background-color: #6461b1;
}

a {
    color: black;
    text-decoration: none;
    padding: 10px;
}

a:hover {
    color: white;
    background-color: #4e4d76;
    border-radius: 15px;
}

/*------------------- APARTAT CONTROL D'ESTATS  -------------*/
.div-estat{
    display: flex;
    justify-content: center;
    align-items: center;
    width: 300px;
    height: 50px;
    background-color:#4f4caf;
    margin: 15px auto;
    border-radius: 5px;
}

.div-estat:hover {
    background-color: #6461b1;
}

.estat-total {
    color: white;
    margin: 0 0 0 25px;
}

.estat-link {
    text-decoration: none;
    padding: 10px;
}

.estat-link:hover {
    color: white;   
    background-color:#6461b1;
}
</style>
<body>
    <h1>Menu</h1>
    <table style="text-decoration: none">
        <tr>
            <th><a href="../index.php?controlador=Hoteles&accion=listarHoteles">Hoteles</a></th>
            <!-- <th><a href="../index.php?controlador=Comandes&accion=listarComandes">Comandes</a></th>
            <th><a href="../index.php?controlador=Estats&accion=listarEstats">Ges. Estats</a></th> -->
        </tr>
        <!-- <tr> 
            <th><a href="../index.php?controlador=Empleats&accion=listarEmpleats">Empleats</a></th>
            <th><a href="../index.php?controlador=Proveidors&accion=listarProveidors">Proveidors</a></th>
        </tr> -->
    </table>
</body>
</html>