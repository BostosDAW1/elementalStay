// server.js


const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// Middleware para permitir peticiones de otros orígenes (CORS)
app.use(cors());
// Middleware para parsear JSON
app.use(express.json());
// Servir archivos estáticos desde la carpeta "public"
app.use(express.static(path.join(__dirname, 'public')));

// Configuración de la conexión a MySQL
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',       
  password: 'EwnizEv5',       
  database: 'hoteles_db'  
});

db.connect((err) => {
  if (err) {
    console.error('Error al conectar a la base de datos:', err);
    return;
  }
  console.log('Conectado a la base de datos MySQL');
});

// Ruta para servir el index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Ruta para obtener hoteles con filtros
app.get('/hoteles', (req, res) => {
  // Obtenemos los parámetros de filtrado desde la query string
  const { 
    nombreHotel, 
    tipoDeHotel, 
    comunidad, 
    disponibilidad, 
    precioMin, 
    precioMax, 
    fechaEntrada, 
    fechaSalida, 
    numeroAdultos, 
    numeroNinos, 
    numeroHabitaciones, 
    llevoMascota 
  } = req.query;
  
  // Construcción dinámica de la consulta SQL
  let query = "SELECT * FROM hoteles WHERE 1=1";
  const params = [];

  if (nombreHotel) {
    query += " AND nombre LIKE ?";
    params.push(`%${nombreHotel}%`);
  }
  if (tipoDeHotel) {
    query += " AND tipo LIKE ?";
    params.push(`%${tipoDeHotel}%`);
  }
  if (comunidad) {
    query += " AND LOWER(comunidad) LIKE ?";
    params.push(`%${comunidad.toLowerCase()}%`);
  }  
  if (disponibilidad) {
    query += " AND disponibilidad = ?";
    params.push(disponibilidad === 'true' ? 1 : 0);
  }  
  if (precioMin) {
    query += " AND precio >= ?";
    params.push(precioMin);
  }
  if (precioMax) {
    query += " AND precio <= ?";
    params.push(precioMax);
  }
  if (fechaEntrada && fechaSalida) {
    // Se asume que los hoteles tienen un rango de disponibilidad definido
    // por las columnas "available_from" y "available_to"
    query += " AND available_from <= ? AND available_to >= ?";
    params.push(fechaEntrada, fechaSalida);
  }
  if (numeroAdultos) {
    query += " AND numero_adultos >= ?";
    params.push(numeroAdultos);
  }
  if (numeroNinos) {
    query += " AND numero_ninos >= ?";
    params.push(numeroNinos);
  }
  if (numeroHabitaciones) {
    query += " AND numero_habitaciones >= ?";
    params.push(numeroHabitaciones);
  }
  if (llevoMascota) {
    query += " AND permite_mascotas = ?";
    params.push(llevoMascota === 'true' ? 1 : 0);
  }

  // Ejecutar la consulta usando parámetros preparados para evitar inyección SQL
  db.query(query, params, (err, results) => {
    if (err) {
      console.error('Error al obtener los hoteles:', err);
      return res.status(500).json({ error: 'Error al obtener hoteles' });
    }
    res.json(results);
  });
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
