<?php
class HotelesCompletosModel
{
    protected $db;
 
    public function __construct()
    {
        // Obtenemos la conexión mysqli mediante el singleton
        $this->db = SMysqli::singleton()->getConnection();
    }

    public function listadoHotelesCompletosPorId($id_hotel)
    {
        $sql = "SELECT * FROM hoteles WHERE id_hotel = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $id_hotel);
        $stmt->execute();
        $result = $stmt->get_result();

        if (!$result) {
            die("Error en la consulta: " . $this->db->error);
        }

        return $result;
    }

}
?>
