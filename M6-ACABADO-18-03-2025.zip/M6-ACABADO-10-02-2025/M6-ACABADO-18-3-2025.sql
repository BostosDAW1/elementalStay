-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: hoteles_db
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.23.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `pais` varchar(50) NOT NULL,
  `ciudad` varchar(50) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'hugor','Hugo','Ramírez López','hugo.ramirez@example.com','677123456','España','Sevilla','cd6cbae9376c247d9ae791675c706da07e3d7a2877c94cf6deb2ec9bdee50177'),(2,'brunof','Bruno','Fernández Torres','bruno.fernandez@example.com','688234567','México','Guadalajara','9f8fcbdf72be532e8a913ebed95adfd9cc16bf13a7cf3f397c64c93c18bf942b');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoteles`
--

DROP TABLE IF EXISTS `hoteles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hoteles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `comunidad` varchar(50) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `disponibilidad` tinyint(1) NOT NULL,
  `available_from` date NOT NULL,
  `available_to` date NOT NULL,
  `numero_adultos` int NOT NULL,
  `numero_ninos` int NOT NULL,
  `numero_habitaciones` int NOT NULL,
  `permite_mascotas` tinyint(1) NOT NULL,
  `imagen` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoteles`
--

LOCK TABLES `hoteles` WRITE;
/*!40000 ALTER TABLE `hoteles` DISABLE KEYS */;
INSERT INTO `hoteles` VALUES (1,'Hotel Marítimo','playa','valencia',120.00,1,'2025-01-01','2025-12-31',2,1,1,1,'img/hotel1.jpg'),(2,'Hotel Montaña Azul','montaña','madrid',90.00,0,'2025-03-01','2025-11-30',2,0,1,0,'img/hotel2.jpg'),(3,'Hotel Sol','playa','valencia',150.00,1,'2025-06-01','2025-08-31',2,2,2,1,'img/hotel3.jpg'),(4,'Hotel Vista al Mar','playa','cantabria',200.00,1,'2025-05-01','2025-09-30',4,1,2,1,'img/hotel4.jpg'),(5,'Hotel Palacio Real','ciudad','madrid',250.00,0,'2025-07-01','2025-12-31',2,0,1,0,'img/hotel5.jpg'),(6,'Hotel Costa Verde','playa','cantabria',80.00,1,'2025-04-01','2025-10-15',2,2,1,1,'img/hotel6.jpg'),(7,'Hotel Andino','montaña','madrid',100.00,1,'2025-01-01','2025-12-31',3,1,1,1,'img/hotel7.jpg'),(8,'Hotel del Sol','playa','valencia',180.00,0,'2025-05-01','2025-09-30',2,1,2,0,'img/hotel8.jpg'),(9,'Hotel Madrid Centro','ciudad','madrid',220.00,1,'2025-01-01','2025-12-31',2,0,1,1,'img/hotel9.jpg'),(10,'Hotel de la Montaña','montaña','cantabria',130.00,0,'2025-04-01','2025-10-31',3,2,1,1,'img/hotel10.jpg'),(11,'Hotel Brisa Marina','playa','valencia',110.00,1,'2025-02-01','2025-12-31',2,0,1,1,'img/hotel11.jpg'),(12,'Hotel Roca del Mar','playa','cantabria',130.00,1,'2025-03-01','2025-11-30',3,1,1,0,'img/hotel12.jpg'),(13,'Hotel Montaña Escondida','montaña','madrid',140.00,0,'2025-04-01','2025-10-31',2,2,1,0,'img/hotel13.jpg'),(14,'Hotel Ciudad Central','ciudad','madrid',210.00,1,'2025-01-01','2025-12-31',2,0,1,1,'img/hotel14.jpg'),(15,'Hotel Costa Dorada','playa','cantabria',95.00,0,'2025-05-01','2025-09-30',1,1,1,1,'img/hotel15.jpg'),(16,'Hotel Vista Panorámica','montaña','cantabria',170.00,1,'2025-06-01','2025-12-31',4,0,2,0,'img/hotel16.jpg'),(17,'Hotel Sol y Luna','playa','valencia',180.00,1,'2025-07-01','2025-12-31',2,2,2,1,'img/hotel17.jpg'),(18,'Hotel Paraíso Urbano','ciudad','madrid',250.00,0,'2025-08-01','2025-12-31',3,1,1,0,'img/hotel18.jpg'),(19,'Hotel Sierra Azul','montaña','madrid',160.00,1,'2025-03-01','2025-10-31',2,0,1,1,'img/hotel19.jpg'),(20,'Hotel Brisas del Sur','playa','valencia',130.00,1,'2025-02-15','2025-11-30',2,1,1,0,'img/hotel20.jpg'),(21,'Hotel Cielo Abierto','ciudad','cantabria',240.00,1,'2025-04-01','2025-12-31',2,0,2,1,'img/hotel21.jpg'),(22,'Hotel Rincón Secreto','montaña','cantabria',145.00,0,'2025-01-15','2025-09-15',3,2,2,0,'img/hotel22.jpg'),(23,'Hotel Sol Naciente','playa','valencia',155.00,1,'2025-03-01','2025-08-31',2,0,1,1,'img/hotel23.jpg'),(24,'Hotel Horizonte Infinito','ciudad','madrid',265.00,0,'2025-05-01','2025-12-31',2,1,2,0,'img/hotel24.jpg'),(25,'Hotel Mar y Montaña','playa','cantabria',175.00,1,'2025-04-15','2025-10-15',3,1,1,1,'img/hotel25.jpg'),(26,'Hotel Oasis Urbano','ciudad','valencia',230.00,1,'2025-02-01','2025-11-30',2,0,1,0,'img/hotel26.jpg'),(27,'Hotel Rocas y Mar','playa','cantabria',115.00,0,'2025-06-01','2025-09-30',1,1,1,1,'img/hotel27.jpg'),(28,'Hotel Bruma del Valle','montaña','madrid',190.00,1,'2025-03-15','2025-12-31',3,2,2,1,'img/hotel28.jpg'),(29,'Hotel Ciudad del Sol','ciudad','madrid',205.00,1,'2025-01-01','2025-10-31',2,1,1,0,'img/hotel29.jpg'),(30,'Hotel Mar Serene','playa','valencia',125.00,1,'2025-04-01','2025-11-30',2,0,1,1,'img/hotel30.jpg'),(31,'Hotel Pico del Cielo','montaña','cantabria',150.00,0,'2025-05-01','2025-10-31',2,2,1,0,'img/hotel31.jpg'),(32,'Hotel Urbe Moderna','ciudad','madrid',220.00,1,'2025-02-01','2025-12-31',2,0,1,1,'img/hotel32.jpg'),(33,'Hotel Playa Dorada','playa','valencia',135.00,1,'2025-06-01','2025-12-31',3,1,2,1,'img/hotel33.jpg'),(34,'Hotel Montaña Viva','montaña','madrid',155.00,1,'2025-07-01','2025-11-30',2,0,1,0,'img/hotel34.jpg'),(35,'Hotel Ciudad de Oro','ciudad','cantabria',245.00,0,'2025-03-01','2025-09-30',3,1,2,1,'img/hotel35.jpg');
/*!40000 ALTER TABLE `hoteles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `apellidos` varchar(100) NOT NULL,
  `correo` varchar(100) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `pais` varchar(50) NOT NULL,
  `ciudad` varchar(50) NOT NULL,
  `contraseña` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'carlosf','Carlos','Fernández Gómez','carlos.fernandez@example.com','612345678','España','Madrid','ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f'),(2,'lauram','Laura','Martínez Pérez','laura.martinez@example.com','623456789','España','Barcelona','4379f8e1c8ffa0a9f75b600b3af9412b0fa91123c8b674d49139268b71aefd9d'),(3,'davidg','David','García López','david.garcia@example.com','634567890','México','Ciudad de México','42474f99289f6500159070f4fb96a4f381132d36136fa802333b671603852e9f'),(4,'anar','Ana','Ruiz Sánchez','ana.ruiz@example.com','645678901','Argentina','Buenos Aires','f22b9c0270fbebdf6244fcd6b930fdfa2dfa919105553ae1a590c8fc39899bcb'),(5,'miguelt','Miguel','Torres Díaz','miguel.torres@example.com','656789012','Chile','Santiago','1af2389ce41a68ca5e3d4a3528f7a0a0e5221222a3ab207e7d867fdc587ae431');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-18 16:53:37
