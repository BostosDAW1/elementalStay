<?php
class View
{
    function __construct()
    {
    }

    public function show($name, $vars = array())
    {
        // Se obtiene la configuración desde la clase Config
        $config = Config::singleton();

        // Se arma la ruta de la plantilla
        $path = $config->get('viewsFolder') . $name;

        // Verificar si la plantilla existe
        if (!file_exists($path)) {
            trigger_error('Template `' . $path . '` does not exist.', E_USER_NOTICE);
            return false;
        }

        // Asignar las variables a la vista si se pasan como arreglo
        if (is_array($vars)) {
            foreach ($vars as $key => $value) {
                $$key = $value;
            }
        }

        // Incluir la plantilla
        include($path);
    }
}
?>
