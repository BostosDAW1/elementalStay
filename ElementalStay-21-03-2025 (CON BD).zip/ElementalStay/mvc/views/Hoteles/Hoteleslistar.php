<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elemental Stay - Hoteles</title>
    <link rel="stylesheet" href="../CSS/header.css">
    <link rel="stylesheet" href="../CSS/hoteles.css">
    <link rel="stylesheet" href="../CSS/footer.css">
</head>

<body>

    <!------------------------ NAV PRINCIPAL + OPCIONES --------------------- -->
    <nav>
        <div class="logo">
            <img src="../img/logo.png" alt="Logo">
            <h1 class="logo-title">ELEMENTAL STAY</h1>
        </div>

        <ul>
        <li><a href="../index.php" id="boton-superior"><b>INICIO</b></a></li>
        <li><a href="../contactos/contactos.php" id="boton-superior"><b>CONTACTO</b></a></li>

        <?php if (isset($_SESSION['usuario'])): ?>
            <li class="profile">
            <a href="javascript:void(0);" onclick="toggleProfileMenu(event)" id="profileButton"><b>PERFIL</b></a>
            <div class="profile-menu" id="profileMenu">
                <a href="../perfil/perfil.php">Ver Perfil</a>
                <a href="../inicio_session/logout.php" class="logout">Cerrar Sesión</a>
            </div>
            </li>
        <?php else: ?>
            <li><a href="../inicio_session/inicio_session.php" id="boton-superior"><b>INICIAR SESIÓN</b></a></li>
        <?php endif; ?>
        </ul>
    </nav>
        
    <!------------------------ SCRIPT DEL DESPLEGABLE DEL PERIL --------------------- -->
    <script>
        // Función para alternar el menú de perfil
        function toggleProfileMenu(event) {
            event.stopPropagation();
            var menu = document.getElementById('profileMenu');
            menu.classList.toggle('show');
        }

        window.onclick = function(event) {
            if (!event.target.matches('#profileButton') && !event.target.closest('.profile')) {
                var dropdowns = document.getElementsByClassName('profile-menu');
                for (var i = 0; i < dropdowns.length; i++) {
                dropdowns[i].classList.remove('show');
                }
            }
        }
    </script>
    
    <!-- --------------------- BARRA DE BÚSQUEDA --------------------- -->
    <div class="search-bar">
        <input type="text" placeholder="¿Dónde quieres ir?">
        <select id="hotel-select">
            <option value="all">Todos los hoteles</option>
        </select>
        <input type="date" value="2025-05-29">
    </div>

    
    <!-- --------------------- CONTENEDOR PRINCIPAL --------------------- -->
    <div class="container">
        <!-- Sección de resultados -->
        <div class="results" id="hotel-list">
            <?php
            // Se recorre el resultado de la consulta a la BD
            while ($hotel = $listado->fetch_assoc()) {
                // Definir el tipo de hotel (asumiendo que el campo en la BD se llama tipo_hotel)
                $tipo = strtolower($hotel['tipo_hotel']); // Convertimos a minúsculas por seguridad

                // Asegurar que el tipo sea válido
                $tipos_validos = ['ciudad', 'montaña', 'playa'];
                if (!in_array($tipo, $tipos_validos)) {
                    $tipo = 'ciudad'; // Si no es válido, usar 'ciudad' por defecto
                }

                // Aquí es donde defines manualmente la imagen para cada hotel
                $imagen = $config->get('imagePath') . $hotel['img']; // Imagen dinámica desde la base de datos

                // Mostrar la ruta de la imagen para depuración
                echo "<!-- Ruta de la imagen: $imagen -->";

                // Verifica que el archivo de imagen exista antes de mostrarlo
                if (file_exists($imagen)) {
                    echo "
                    <div class='result-item' data-hotel='{$hotel['nombre']}'>
                        <img src='{$imagen}' alt='{$hotel['nombre']}'>
                        <div class='description'>
                            <h3>{$hotel['nombre']}</h3>
                            <p><strong>Tipo:</strong> {$hotel['tipo_hotel']}</p>
                            <p><strong>Comunidad:</strong> {$hotel['comunidad_autonoma']}</p>
                            <div id='acciones'>
                                <a class='btn-reservar' href='index.php?controlador=HotelesCompletos&accion=listarHotelesCompletos&id={$hotel['id_hotel']}'>Ver más</a>
                            </div>
                        </div>
                    </div>
                    ";
                } else {
                    // Si la imagen no existe, mostrar un mensaje alternativo
                    echo "<!-- Imagen no encontrada: $imagen -->";
                }
            }
            ?>
        </div>

        <!-- Sección de mapa -->
        <div class="map">
            <iframe 
                id="google-map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.8354345091843!2d-122.40125888468113!3d37.79359297975644!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858064a4053b33%3A0x6a3491e7b4f7d54c!2sSan%20Francisco%20City%20Hall!5e0!3m2!1ses!2ses!4v1638927961178!5m2!1ses!2ses"
                allowfullscreen=""
                loading="lazy">
            </iframe>
        </div>

    </div>

    <!------------------------ FOOTER DE LA PESTAÑA --------------------- -->
    <footer>
        <div class="footer-container">

            <div class="footer-section">
                <h4>Sobre Nosotros</h4>
                <p>Elemental Stay es tu plataforma para encontrar los mejores alojamientos al mejor precio, con opciones personalizadas para cada tipo de viajero.</p>
            </div>

            <div class="footer-section">
                <h4>Enlaces Útiles</h4>
                <ul>
                    <li><a href="#">Inicio</a></li>
                    <li><a href="#">Acerca de</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li><a href="#">Términos y Condiciones</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h4>Síguenos</h4>
                <div class="social-icons">
                    <a href="#"><img src="icon-facebook.svg" alt="Facebook"></a>
                    <a href="#"><img src="icon-twitter.svg" alt="Twitter"></a>
                    <a href="#"><img src="icon-instagram.svg" alt="Instagram"></a>
                    <a href="#"><img src="icon-youtube.svg" alt="YouTube"></a>
                </div>
            </div>

        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2024 Elemental Stay. Todos los derechos reservados.</p>
        </div>
    </footer>


    <!------------------------ LINK AL HEADER Y  --------------------- -->
    <script src="../JS/Header.js"></script>
    <script src="../JS/hoteles.js"></script>
</body>
</html>
