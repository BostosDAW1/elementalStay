// server.js
const express      = require('express');
const mysql        = require('mysql2');
const cors         = require('cors');
const path         = require('path');
const cookieParser = require('cookie-parser');

const app  = express();
const port = 3000;

// ---------------- APP USE ----------------
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// ---------------- APP GET SERVIDOR ----------------
app.get('/favicon.ico', (req, res) => res.status(204).end());

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ---------------- Conexión a la base de datos ----------------
const db = mysql.createConnection({
  host:     'localhost',
  user:     'root',
  password: 'P@ssw0rd',
  database: 'hoteles_db'
});

db.connect(err => {
  if (err) {
    console.error('❌ Error al conectar a la base de datos:', err.message);
    process.exit(1);
  }
  console.log('✅ Conectado a MySQL');
});

// ---------------- RUTA: Consultar Hoteles ----------------
app.get('/hoteles', (req, res) => {
  const { 
    tipoDeHotel, comunidad, disponibilidad, 
    precioMin, precioMax, fechaEntrada, fechaSalida, 
    numeroAdultos, numeroNinos, numeroHabitaciones, llevoMascota 
  } = req.query;

  const totalPersonas = (parseInt(numeroAdultos) || 0) + (parseInt(numeroNinos) || 0);

  let query = `
    SELECT 
      h.*,
      (
        SELECT MIN(ha.precio)
        FROM habitaciones ha
        WHERE ha.id_hotel = h.id
          ${precioMin ? "AND ha.precio >= ?" : ""}
          ${precioMax ? "AND ha.precio <= ?" : ""}
          ${totalPersonas ? "AND ha.capacidad >= ?" : ""}
          ${fechaEntrada && fechaSalida ? `
            AND NOT EXISTS (
              SELECT 1 
              FROM reservas r
              WHERE r.id_habitacion = ha.id_habitacion
                AND r.fecha_inicio < ?
                AND r.fecha_salida > ?
            )
          ` : ""}
      ) AS precio_habitacion_min,
      COALESCE(
        (
          SELECT JSON_ARRAYAGG(
            JSON_OBJECT(
              'id', ha.id_habitacion,
              'nombre', ha.nombre,
              'precio', ha.precio,
              'capacidad', ha.capacidad
            )
          )
          FROM habitaciones ha
          WHERE ha.id_hotel = h.id
            ${precioMin ? "AND ha.precio >= ?" : ""}
            ${precioMax ? "AND ha.precio <= ?" : ""}
            ${totalPersonas ? "AND ha.capacidad >= ?" : ""}
            ${fechaEntrada && fechaSalida ? `
              AND NOT EXISTS (
                SELECT 1 
                FROM reservas r
                WHERE r.id_habitacion = ha.id_habitacion
                  AND r.fecha_inicio < ?
                  AND r.fecha_salida > ?
              )
            ` : ""}
        ),
        JSON_ARRAY()
      ) AS habitaciones
    FROM hoteles h
    WHERE 1=1
  `;

  const filtros = [];
  const params = [];

  // Parámetros para ambas subconsultas (se repiten)
  if (precioMin)        filtros.push(precioMin);
  if (precioMax)        filtros.push(precioMax);
  if (totalPersonas)    filtros.push(totalPersonas);
  if (fechaEntrada && fechaSalida) filtros.push(fechaSalida, fechaEntrada);
  if (precioMin)        filtros.push(precioMin);
  if (precioMax)        filtros.push(precioMax);
  if (totalPersonas)    filtros.push(totalPersonas);
  if (fechaEntrada && fechaSalida) filtros.push(fechaSalida, fechaEntrada);

  // Filtros sobre hoteles
  if (tipoDeHotel) {
    query += " AND h.tipo LIKE ?";
    params.push(`%${tipoDeHotel}%`);
  }
  if (comunidad) {
    query += " AND LOWER(h.comunidad) LIKE ?";
    params.push(`%${comunidad.toLowerCase()}%`);
  }
  if (disponibilidad) {
    query += " AND h.disponibilidad = ?";
    params.push(disponibilidad === 'true' ? 1 : 0);
  }
  if (fechaEntrada && fechaSalida) {
    query += " AND h.available_from <= ? AND h.available_to >= ?";
    params.push(fechaEntrada, fechaSalida);
  }
  if (numeroHabitaciones) {
    query += " AND h.numero_habitaciones >= ?";
    params.push(numeroHabitaciones);
  }
  if (llevoMascota) {
    query += " AND h.permite_mascotas = ?";
    params.push(llevoMascota === 'true' ? 1 : 0);
  }

  // Asegurar al menos una habitación válida
  if (precioMin || precioMax || totalPersonas || (fechaEntrada && fechaSalida)) {
    query += `
      AND EXISTS (
        SELECT 1 
        FROM habitaciones ha
        WHERE ha.id_hotel = h.id
          ${precioMin ? "AND ha.precio >= ?" : ""}
          ${precioMax ? "AND ha.precio <= ?" : ""}
          ${totalPersonas ? "AND ha.capacidad >= ?" : ""}
          ${fechaEntrada && fechaSalida ? `
            AND NOT EXISTS (
              SELECT 1 
              FROM reservas r
              WHERE r.id_habitacion = ha.id_habitacion
                AND r.fecha_inicio < ?
                AND r.fecha_salida > ?
            )
          ` : ""}
      )
    `;
    if (precioMin)        params.push(precioMin);
    if (precioMax)        params.push(precioMax);
    if (totalPersonas)    params.push(totalPersonas);
    if (fechaEntrada && fechaSalida) params.push(fechaSalida, fechaEntrada);
  }

  db.query(query, [...filtros, ...params], (err, results) => {
    if (err) {
      console.error('Error al obtener los hoteles:', err);
      return res.status(500).json({ error: 'Error al obtener hoteles' });
    }

    // Imprime los resultados crudos para depuración
    console.log('←←← RAW RESULTS:', JSON.stringify(results, null, 2));

    // 1) Filtrar hoteles sin habitación
    results = results.filter(h => h.precio_habitacion_min !== null);

    // 2) Convertir el JSON de 'habitaciones' en array real
    results = results.map(h => {
      if (typeof h.habitaciones === 'string') {
        try {
          h.habitaciones = JSON.parse(h.habitaciones);
        } catch {
          h.habitaciones = [];
        }
      }
      return h;
    });

    // 3) Enviar respuesta
    res.json(results);
  });
});

// POST: Procesar pago y reserva
app.post('/reservar', (req, res) => {
  const { hotelId, roomId, nombreTarjeta, numeroTarjeta, cvv, caducidadTarjeta } = req.body;

  // 1) Insertar datos de pago
  const sqlPago = `
    INSERT INTO info_pagos
      (nombreTarjeta, numeroTarjeta, cvv, caducidadTarjeta)
    VALUES (?, ?, ?, ?)
  `;
  db.query(sqlPago,
    [nombreTarjeta, numeroTarjeta, cvv, caducidadTarjeta],
    (err, result) => {
      if (err) {
        console.error('Error al insertar pago:', err);
        return res.status(500).json({ success: false });
      }
      // Opcional: crear un registro en 'reservas'
      // const idPago = result.insertId;
      // const sqlRes = `INSERT INTO reservas
      //   (id_habitacion, fecha_inicio, fecha_salida, id_infoPago)
      //   VALUES (?, ?, ?, ?)
      // `;
      // db.query(sqlRes, [roomId, req.body.fechaEntrada, req.body.fechaSalida, idPago], ...);

      res.json({ success: true, idPago: result.insertId });
    }
  );
});


// ---------------- RUTAS PARA USUARIO, LOGIN, REGISTRO, etc. ----------------

// RUTA: Obtener usuario autenticado
app.get('/usuario', (req, res) => {
  const usuario = req.cookies.usuario;
  if (usuario) {
    res.json(JSON.parse(usuario));
  } else {
    res.status(401).send("No autenticado");
  }
});

// RUTA: Página de registro
app.get('/registro', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'registro', 'registro.html'));
});

// RUTA: Página de inicio de sesión
app.get('/inicio_sesion', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'inicio_sesion', 'inicio_sesion.html'));
});

// RUTA: Logout
app.get('/logout', (req, res) => {
  res.clearCookie('usuario');
  res.redirect('/inicio_sesion/inicio_sesion.html');
});

// POST: Login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).send("Faltan datos de login.");
  }
  const queryUser = "SELECT * FROM usuarios WHERE username = ? AND password = SHA2(?, 256) LIMIT 1";
  db.query(queryUser, [username, password], (err, results) => {
    if (err) {
      console.error("Error en la base de datos:", err);
      return res.status(500).send("Error interno en el servidor.");
    }
    if (results.length > 0) {
       res.cookie("usuario", JSON.stringify(results[0]), { maxAge: 3600000, httpOnly: false });

    return res.redirect('/index.html');
    } else {
      const queryAdmin = "SELECT * FROM admin WHERE username = ? AND password = SHA2(?, 256) LIMIT 1";
      db.query(queryAdmin, [username, password], (err, adminResults) => {
        if (err) {
          console.error("Error en la base de datos:", err);
          return res.status(500).send("Error interno en el servidor.");
        }
        if (adminResults.length > 0) {
          return res.redirect('/');
        } else {
          return res.status(401).send("Credenciales inválidas.");
        }
      });
    }
  });
});

// POST: Registro
app.post('/register', (req, res) => {
  const { username, email, password, confirmPassword } = req.body;
  if (!username || !email || !password || !confirmPassword) {
    return res.status(400).send("Faltan datos en el registro.");
  }
  if (password !== confirmPassword) {
    return res.status(400).send("Las contraseñas no coinciden.");
  }
  const queryCheck = "SELECT * FROM usuarios WHERE username = ? OR correo = ? LIMIT 1";
  db.query(queryCheck, [username, email], (err, results) => {
    if (err) {
      console.error("Error al consultar la base de datos:", err);
      return res.status(500).send("Error interno en el servidor.");
    }
    if (results.length > 0) {
      return res.status(400).send("El nombre de usuario o el correo electrónico ya están registrados.");
    }
    const queryInsert = "INSERT INTO usuarios (username, correo, password) VALUES (?, ?, SHA2(?, 256))";
    db.query(queryInsert, [username, email, password], (err, insertResults) => {
      if (err) {
        console.error("Error al insertar el usuario:", err);
        return res.status(500).send("Error al registrar el usuario.");
      }
      res.send("¡Registro exitoso! Puedes iniciar sesión ahora.");
    });
  });
});

// POST: Actualización de datos de usuario
app.post('/updateUser', (req, res) => {
  const { username, nombre, apellidos, correo, telefono, pais, ciudad } = req.body;
  if (!username || !correo) {
    return res.status(400).json({ error: "Faltan datos requeridos" });
  }
  const query = `UPDATE usuarios 
                 SET nombre = ?, apellidos = ?, correo = ?, telefono = ?, pais = ?, ciudad = ? 
                 WHERE username = ?`;
  db.query(query, [nombre, apellidos, correo, telefono, pais, ciudad, username], (err, result) => {
    if (err) {
      console.error("Error al actualizar el usuario:", err);
      return res.status(500).json({ error: "Error al actualizar el usuario" });
    }
    const queryUser = "SELECT * FROM usuarios WHERE username = ? LIMIT 1";
    db.query(queryUser, [username], (err, results) => {
      if (err) {
        console.error("Error al obtener el usuario actualizado:", err);
        return res.status(500).json({ error: "Error al obtener datos actualizados" });
      }
      if (results.length > 0) {
        res.cookie("usuario", JSON.stringify(results[0]), { maxAge: 3600000, httpOnly: false });
        return res.json({ success: true, user: results[0] });
      } else {
        return res.status(404).json({ error: "Usuario no encontrado" });
      }
    });
  });
});

// ---------------- FIN DE LAS RUTAS ----------------

app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});

// ---------------- API ADMINISTRATIVA ----------------

// 1) Hoteles
app.get('/api/admin/hoteles', (req, res) => {
  const sql = `SELECT id, nombre, comunidad, precio, disponibilidad FROM hoteles ORDER BY id`;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error al obtener hoteles:', err);
      return res.status(500).json({ error: 'Error al obtener hoteles' });
    }
    res.json(results);
  });
});

// 2) Usuarios
app.get('/api/admin/usuarios', (req, res) => {
  const sql = `SELECT id, username, nombre, apellidos, correo, telefono, pais, ciudad, admin FROM usuarios ORDER BY id`;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error al obtener usuarios:', err);
      return res.status(500).json({ error: 'Error al obtener usuarios' });
    }
    res.json(results);
  });
});

// 3) Reservas
app.get('/api/admin/reservas', (req, res) => {
  const sql = `
    SELECT
      r.idreserva AS id,
      u.username AS usuario,
      h.nombre   AS hotel,
      ha.nombre  AS habitacion,
      r.fecha_inicio AS desde,
      r.fecha_salida AS hasta
    FROM reservas r
    JOIN usuarios u      ON u.id = r.id_usuario
    JOIN habitaciones ha ON ha.id_habitacion = r.id_habitacion
    JOIN hoteles h       ON h.id = ha.id_hotel
    ORDER BY r.fecha_inicio DESC
  `;
  db.query(sql, (err, results) => {
    if (err) {
      console.error('Error al obtener reservas:', err);
      return res.status(500).json({ error: 'Error al obtener reservas' });
    }
    res.json(results);
  });
});

// ———> Ahora sí servimos estáticos desde public
app.use(express.static(path.join(__dirname, 'public')));

// ELIMINAR 
// ———> Rutas DELETE
app.delete('/api/admin/hoteles/:id', (req, res) => {
  db.query('DELETE FROM hoteles WHERE id = ?', [req.params.id], (err) => {
    if (err) {
      console.error('Error al eliminar hotel:', err);
      return res.status(500).json({ error: 'No se pudo eliminar el hotel' });
    }
    res.json({ success: true });
  });
});

app.delete('/api/admin/usuarios/:id', (req, res) => {
  db.query('DELETE FROM usuarios WHERE id = ?', [req.params.id], (err) => {
    if (err) {
      console.error('Error al eliminar usuario:', err);
      return res.status(500).json({ error: 'No se pudo eliminar el usuario' });
    }
    res.json({ success: true });
  });
});

app.delete('/api/admin/reservas/:id', (req, res) => {
  db.query('DELETE FROM reservas WHERE idreserva = ?', [req.params.id], (err) => {
    if (err) {
      console.error('Error al eliminar reserva:', err);
      return res.status(500).json({ error: 'No se pudo eliminar la reserva' });
    }
    res.json({ success: true });
  });
});

// ———> Ahora sí servimos estáticos desde public
app.use(express.static(path.join(__dirname, 'public')));