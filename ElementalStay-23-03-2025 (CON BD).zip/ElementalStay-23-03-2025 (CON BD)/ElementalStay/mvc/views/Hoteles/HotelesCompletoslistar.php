<?php
session_start();
// Se asume que $listado y $config vienen definidos al incluir la vista mediante el motor de plantillas
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" 
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <title>Elemental Stay - Hoteles Información completa</title>
  <link rel="stylesheet" href="../CSS/header.css"/>
  <link rel="stylesheet" href="../CSS/hoteles_completos.css"/>
  <link rel="stylesheet" href="../CSS/footer.css"/>
  <link rel="shortcut icon" href="../img/logo.png"/>
</head>
<body>
    <!-- ------------------------ NAV PRINCIPAL + OPCIONES --------------------- -->
    <nav>
        <div class="logo">
            <img src="../img/logo.png" alt="Logo">
            <h1 class="logo-title">ELEMENTAL STAY</h1>
        </div>
        <ul>
            <li><a href="../index.php" id="boton-superior"><b>INICIO</b></a></li>
            <li><a href="../contactos/contactos.php" id="boton-superior"><b>CONTACTO</b></a></li>
            <?php if (isset($_SESSION['usuario'])): ?>
                <li class="profile">
                    <a href="javascript:void(0);" onclick="toggleProfileMenu(event)" id="profileButton"><b>PERFIL</b></a>
                    <div class="profile-menu" id="profileMenu">
                        <a href="../perfil/perfil.php">Ver Perfil</a>
                        <a href="../inicio_session/logout.php" class="logout">Cerrar Sesión</a>
                    </div>
                </li>
            <?php else: ?>
                <li><a href="../inicio_session/inicio_session.php" id="boton-superior"><b>INICIAR SESIÓN</b></a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <!-- ------------------------ CONTENIDO HOTELES CON INFORMACIÓN ------------------------ -->
    <div class="hotel-container">
        <?php foreach ($listado as $hotel): ?>
        <div class="hotel-card">
            <div class="hotel-top">
            <div class="hotel-image">
                <img src="<?= htmlspecialchars($config->get('imagePath') . $hotel['img']); ?>" alt="<?= htmlspecialchars($hotel['nombre']); ?>" />
            </div>
            <div class="hotel-info">
                <h3><?= htmlspecialchars($hotel['nombre']); ?></h3>
                <p><strong>Tipo:</strong> <?= htmlspecialchars($hotel['tipo_hotel']); ?></p>
                <p><strong>Comunidad:</strong> <?= htmlspecialchars($hotel['comunidad_autonoma']); ?></p>
                <p><strong>Precio/noche:</strong> $<?= htmlspecialchars($hotel['precio_noche']); ?></p>
            </div>
            </div>
            <div class="hotel-description">
            <p><?= htmlspecialchars($hotel['descripcion']); ?></p>
            </div>
            <!-- Habitaciones -->
            <?php if (isset($hotel['habitaciones']) && is_array($hotel['habitaciones'])): ?>
            <div class="hotel-rooms">
            <h4>Habitaciones:</h4>
            <?php foreach ($hotel['habitaciones'] as $habitacion): ?>
                <div class="room-card">
                <p><strong>Nombre:</strong> <?= htmlspecialchars($habitacion['nombre']); ?></p>
                <p><strong>Capacidad:</strong> <?= htmlspecialchars($habitacion['capacidad']); ?></p>
                <p><strong>Metros cuadrados:</strong> <?= htmlspecialchars($habitacion['m2']); ?> m²</p>
                <p><strong>Wifi:</strong> <?= $habitacion['wifi'] ? 'Sí' : 'No'; ?></p>
                <div class="actions">
                    <a href="index.php?controlador=HotelesCompletos&accion=modificarHotelesCompletos&id=<?= htmlspecialchars($hotel["id_hotel"]); ?>">Reservar</a>
                    <!-- <a href="index.php?controlador=HotelesCompletos&accion=eliminarHotelesCompletos&id=<?= htmlspecialchars(string: $hotel["id_hotel"]); ?>">Eliminar</a> -->
                </div>
                </div>
            <?php endforeach; ?>
            </div>
            <?php endif; ?>
            <!-- Servicios -->
            <?php if (isset($hotel['servicios']) && is_array($hotel['servicios'])): ?>
            <div class="hotel-services">
            <h4>Servicios:</h4>
            <?php foreach ($hotel['servicios'] as $servicio): ?>
                <div class="service-card">
                <p><?= htmlspecialchars($servicio['nombre']); ?></p>
                </div>
            <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ------------------------ FOOTER --------------------- -->
    <footer>
        <div class="footer-container">
            <div class="footer-section">
                <h4>Sobre Nosotros</h4>
                <p>Elemental Stay es tu plataforma para encontrar los mejores alojamientos al mejor precio, con opciones personalizadas para cada tipo de viajero.</p>
            </div>
            <div class="footer-section">
                <h4>Enlaces Útiles</h4>
                <ul>
                    <li><a href="#">Inicio</a></li>
                    <li><a href="#">Acerca de</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li><a href="#">Términos y Condiciones</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Síguenos</h4>
                <div class="social-icons">
                    <a href="#"><img src="icon-facebook.svg" alt="Facebook"></a>
                    <a href="#"><img src="icon-twitter.svg" alt="Twitter"></a>
                    <a href="#"><img src="icon-instagram.svg" alt="Instagram"></a>
                    <a href="#"><img src="icon-youtube.svg" alt="YouTube"></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Elemental Stay. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!-- ------------------------ SCRIPTS --------------------- -->
    <script src="../JS/Header.js"></script>
    <script src="../JS/hoteles.js"></script>
</body>
</html>
