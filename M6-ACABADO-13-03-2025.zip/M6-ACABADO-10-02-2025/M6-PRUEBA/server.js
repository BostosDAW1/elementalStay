const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// Middleware para permitir peticiones de otros orígenes (CORS)
app.use(cors());
// Middleware para parsear JSON
app.use(express.json());
// Middleware para parsear datos de formularios (URL-encoded)
app.use(express.urlencoded({ extended: true }));

// Servir archivos estáticos desde la carpeta "public"
app.use(express.static(path.join(__dirname, 'public')));

app.use(express.urlencoded({ extended: true }));


// (Opcional) Ruta para el favicon para evitar errores de CSP
app.get('/favicon.ico', (req, res) => res.status(204).end());

// CONEXIÓN A LA BASE DE DATOS
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'P@ssw0rd',
  database: 'hoteles_db'
});

// MEJORA MUESTRA DE ERRORES
db.connect((err) => {
  if (err) {
    console.error('❌ Error al conectar a la base de datos:', err.message);
    process.exit(1);
  }
  console.log('✅ Conectado a MySQL');
});

// Ruta para procesar el login
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).send("Faltan datos de login.");
  }

  // Verificar en la tabla de usuarios
  const queryUser = "SELECT * FROM usuarios WHERE username = ? AND contraseña = SHA2(?, 256) LIMIT 1";
  db.query(queryUser, [username, password], (err, results) => {
    if (err) {
      console.error("Error en la base de datos:", err);
      return res.status(500).send("Error interno en el servidor.");
    }
    if (results.length > 0) {
      console.log("Usuario autenticado:", results[0]);
      return res.redirect("/index.html");  // O redirige a la ruta que desees
    } else {
      // Si no se encontró en usuarios, verificamos en admin
      const queryAdmin = "SELECT * FROM admin WHERE username = ? AND contraseña = SHA2(?, 256) LIMIT 1";
      db.query(queryAdmin, [username, password], (err, adminResults) => {
        if (err) {
          console.error("Error en la base de datos:", err);
          return res.status(500).send("Error interno en el servidor.");
        }
        if (adminResults.length > 0) {
          console.log("Administrador autenticado:", adminResults[0]);
          return res.redirect("/index.html");
        } else {
          return res.status(401).send("Credenciales inválidas.");
        }
      });
    }
  });
});

// Ruta para servir el index.html
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Ejemplo: Ruta para obtener hoteles (ya existente)
app.get('/hoteles', (req, res) => {
  const { 
    tipoDeHotel, 
    comunidad, 
    disponibilidad, 
    precioMin, 
    precioMax, 
    fechaEntrada, 
    fechaSalida, 
    numeroAdultos, 
    numeroNinos, 
    numeroHabitaciones, 
    llevoMascota 
  } = req.query;
  
  let query = "SELECT * FROM hoteles WHERE 1=1";
  const params = [];

  if (tipoDeHotel) {
    query += " AND tipo LIKE ?";
    params.push(`%${tipoDeHotel}%`);
  }
  if (comunidad) {
    query += " AND LOWER(comunidad) LIKE ?";
    params.push(`%${comunidad.toLowerCase()}%`);
  }  
  if (disponibilidad) {
    query += " AND disponibilidad = ?";
    params.push(disponibilidad === 'true' ? 1 : 0);
  }  
  if (precioMin) {
    query += " AND precio >= ?";
    params.push(precioMin);
  }
  if (precioMax) {
    query += " AND precio <= ?";
    params.push(precioMax);
  }
  if (fechaEntrada && fechaSalida) {
    query += " AND available_from <= ? AND available_to >= ?";
    params.push(fechaEntrada, fechaSalida);
  }
  if (numeroAdultos) {
    query += " AND numero_adultos >= ?";
    params.push(numeroAdultos);
  }
  if (numeroNinos) {
    query += " AND numero_ninos >= ?";
    params.push(numeroNinos);
  }
  if (numeroHabitaciones) {
    query += " AND numero_habitaciones >= ?";
    params.push(numeroHabitaciones);
  }
  if (llevoMascota) {
    query += " AND permite_mascotas = ?";
    params.push(llevoMascota === 'true' ? 1 : 0);
  }

  db.query(query, params, (err, results) => {
    if (err) {
      console.error('Error al obtener los hoteles:', err);
      return res.status(500).json({ error: 'Error al obtener hoteles' });
    }
    res.json(results);
  });
});

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});

// Ruta para procesar el login
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).send("Faltan datos de login.");
  }

  // Consulta para buscar en la tabla de usuarios
  const queryUser = "SELECT * FROM usuarios WHERE username = ? AND contraseña = SHA2(?, 256) LIMIT 1";
  db.query(queryUser, [username, password], (err, results) => {
    if (err) {
      console.error("Error en la base de datos:", err);
      return res.status(500).send("Error interno en el servidor.");
    }
    
    if (results.length > 0) {
      console.log("Usuario autenticado:", results[0]);
      // Si deseas crear una sesión, aquí es donde se iniciaría
      return res.send("Se ha iniciado sesión exitosamente. ¡Bienvenido " + results[0].nombre + "!");
    } else {
      // Si no se encontró en usuarios, comprobamos en admin
      const queryAdmin = "SELECT * FROM admin WHERE username = ? AND contraseña = SHA2(?, 256) LIMIT 1";
      db.query(queryAdmin, [username, password], (err, adminResults) => {
        if (err) {
          console.error("Error en la base de datos:", err);
          return res.status(500).send("Error interno en el servidor.");
        }
        
        if (adminResults.length > 0) {
          console.log("Administrador autenticado:", adminResults[0]);
          return res.send("Se ha iniciado sesión exitosamente como administrador. ¡Bienvenido " + adminResults[0].nombre + "!");
        } else {
          return res.status(401).send("Credenciales inválidas.");
        }
      });
    }
  });
});
