function toggleAdvancedFilters() {
  let filtros = document.getElementById("filtros");
  let hoteles = document.getElementById("hoteles");
  let advancedFilters = document.getElementById("advanced-filters");
  let moreFiltersButton = document.getElementById("more-filters-button");

  // Alterna la visibilidad de los filtros avanzados
  if (advancedFilters.style.display === "none" || advancedFilters.style.display === "") {
    advancedFilters.style.display = "block";  // Muestra el div
    filtros.style.width = "50%";
    hoteles.style.width = "50%";
    // Ajusta los márgenes para que se acerquen entre sí
    filtros.style.marginRight = "-150px";
    hoteles.style.marginLeft = "-150px";
    // Cambia el texto del botón a "Menos filtros"
    moreFiltersButton.innerText = "Menos filtros";
  } else {
    advancedFilters.style.display = "none";   // Oculta el div
    filtros.style.width = "100%";
    hoteles.style.width = "100%";
    filtros.style.marginRight = "0";
    hoteles.style.marginLeft = "0";
    // Restaura el texto original del botón
    moreFiltersButton.innerText = "Más filtros";
  }

  // Alterna las clases de movimiento (si aún las utilizas para animaciones adicionales)
  filtros.classList.toggle("move-filtros");
  hoteles.classList.toggle("move-hoteles");
}