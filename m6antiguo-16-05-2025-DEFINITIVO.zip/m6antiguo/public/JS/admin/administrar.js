// Estado global
const dataStore = { hoteles: [], usuarios: [], reservas: [] };
const pageStore =  { hoteles: 1,  usuarios: 1,  reservas: 1 };
const PAGE_SIZE = 15;

// Cambiar pestañas (igual que antes)
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('section').forEach(s => s.classList.remove('active'));
    tab.classList.add('active');
    document.getElementById(tab.dataset.target).classList.add('active');
  });
});

// Función para renderizar una página de datos
function renderPage(sectionId) {
  const data = dataStore[sectionId];
  const page = pageStore[sectionId];
  const start = (page - 1) * PAGE_SIZE;
  const end   = start + PAGE_SIZE;
  const slice = data.slice(start, end);

  const tbody = document.querySelector(`#${sectionId} tbody`);
  tbody.innerHTML = '';
  slice.forEach(item => {
    const tr = document.createElement('tr');
    Object.values(item).forEach(val => {
      const td = document.createElement('td');
      td.textContent = val;
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });

  renderPagination(sectionId);
}

// Crea los botones de paginación
function renderPagination(sectionId) {
  const data = dataStore[sectionId];
  const page = pageStore[sectionId];
  const totalPages = Math.ceil(data.length / PAGE_SIZE) || 1;
  const container = document.getElementById(`pagination-${sectionId}`);
  container.innerHTML = '';

  const prev = document.createElement('span');
  prev.textContent = '◀';
  prev.className = 'page-btn' + (page === 1 ? ' disabled' : '');
  if (page > 1) prev.addEventListener('click', () => {
    pageStore[sectionId]--;
    renderPage(sectionId);
  });
  container.appendChild(prev);

  const info = document.createElement('span');
  info.className = 'page-info';
  info.textContent = `Página ${page} de ${totalPages}`;
  container.appendChild(info);

  const next = document.createElement('span');
  next.textContent = '▶';
  next.className = 'page-btn' + (page === totalPages ? ' disabled' : '');
  if (page < totalPages) next.addEventListener('click', () => {
    pageStore[sectionId]++;
    renderPage(sectionId);
  });
  container.appendChild(next);
}

// Cargar datos y almacenar en el store
function cargarDatos(endpoint, sectionId) {
  const tbody = document.querySelector(`#${sectionId} tbody`);
  tbody.innerHTML = '<tr><td colspan="99">Cargando...</td></tr>';
  fetch(endpoint)
    .then(res => res.json())
    .then(data => {
      dataStore[sectionId] = data;
      pageStore[sectionId] = 1;
      renderPage(sectionId);
    })
    .catch(err => {
      tbody.innerHTML = '<tr><td colspan="99" style="color:red;">Error cargando datos</td></tr>';
      console.error(`Error cargando ${sectionId}:`, err);
    });
}

// Iniciar carga
['hoteles','usuarios','reservas'].forEach(sec =>
  cargarDatos(`/api/admin/${sec}`, sec)
);

// FUNCION ELIMINAR 
function renderPage(sectionId) {
  const data = dataStore[sectionId];
  const page = pageStore[sectionId];
  const start = (page - 1) * PAGE_SIZE;
  const slice = data.slice(start, start + PAGE_SIZE);

  const tbody = document.querySelector(`#${sectionId} tbody`);
  tbody.innerHTML = '';

  slice.forEach(item => {
    const tr = document.createElement('tr');

    // Columnas de datos
    Object.entries(item).forEach(([key, val]) => {
      const td = document.createElement('td');
      td.textContent = val;
      td.setAttribute('data-label', key);
      tr.appendChild(td);
    });

    // Columna de acciones
    const tdAcc = document.createElement('td');
    tdAcc.setAttribute('data-label', 'Acciones');
    const btn = document.createElement('button');
    btn.textContent = 'Eliminar';
    btn.className = 'btn-delete';
    btn.addEventListener('click', () => {
      if (!confirm(`¿Eliminar este ${sectionId.slice(0,-1)} ID ${item.id}?`)) return;
      fetch(`/api/admin/${sectionId}/${item.id}`, { method: 'DELETE' })
        .then(res => {
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          return res.json();
        })
        .then(() => cargarDatos(`/api/admin/${sectionId}`, sectionId))
        .catch(err => alert(`Error en DELETE: ${err}`));
    });
    tdAcc.appendChild(btn);
    tr.appendChild(tdAcc);

    tbody.appendChild(tr);
  });

  renderPagination(sectionId);
}
