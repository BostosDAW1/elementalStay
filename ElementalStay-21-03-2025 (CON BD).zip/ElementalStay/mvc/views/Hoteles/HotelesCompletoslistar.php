<?php
    session_start();
?>
<?php
include '/var/www/html/ElementalStay/config/conexion.php';

if (!isset($conn) || $conn == null) {
        die("Error: La conexión a la base de datos no está disponible.");
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>MVC - Modelo, Vista, Controlador - Jourmoly</title>
<style>
    /*------------------------ ESTILOS DEL BODY ------------------------*/
    html, body {
        margin: 0;   /* Eliminar márgenes predeterminados */
        padding: 0;  /* Eliminar padding */
        width: 100%; /* Asegura que el body ocupe todo el ancho */
    }
    body {
        font-family: Arial, sans-serif;
        padding-top: 80px; /* Altura del nav para compensar su posición fija */
        
    }

    body::before {
        content: ""; /* Elemento vacío para el fondo */
        position: fixed; /* Cubre toda la pantalla */
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image: url('../img/hotelPrincipal.jpg'); /* Imagen de fondo */
        background-repeat: no-repeat;
        background-size: cover;
        background-position: center;
        opacity: 0.2; /* Ajusta solo la opacidad de la imagen */
        z-index: -1; /* Coloca detrás del contenido */
    }

                /*------------------------ ESTILOS DEL HEADER ------------------------*/

                /* ------------------------------ CSS NAV PRINCIPAL MENU PRINCIPAL -------------------- */
    nav {
        /* background: rgba(0, 0, 0, 0.9);  */
        color: black; 
        display: flex;
        justify-content: space-around; /* Distribuye mejor los elementos */    align-items: center;
        padding: 10px 20px; 
        position: fixed; 
        top: 0;
        left: 0;
        width: 100%; 
        height: 70px;
        z-index: 1000; 
        margin-bottom: 20px; 
        transition: background 0.3s ease; 
        
    }

    nav.scrolled {
        background: black; 
        color: #999999;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); 
    }

    .logo {
        display: flex; /* Flexbox para alinear elementos en línea */
        align-items: center; /* Alinea verticalmente los elementos */
    }

    .logo img {
        margin-top: 8px;
        height: 80px; /* Ajusta el tamaño del logo */
        width: 80px;
    }

    .logo-title {
        margin-left: 15px; /* Espaciado entre la imagen y el título */
        font-size: 24px; /* Tamaño del texto del título */
        color: inherit; /* Hereda el color actual del nav */
        font-weight: bold; /* Estilo de texto en negrita */
    }

    nav ul {
        display: flex;
        list-style: none;
        margin-right: 50px; /* Separa los enlaces del borde derecho */
    }


    nav ul li {
        margin: 0 15px;
    }

    nav ul li a {
        color: inherit; /* Hereda el color actual del nav */
        text-decoration: none;
        padding: 5px 10px;
        transition: background 0.3s ease, color 0.3s ease; /* Suaviza cambios de color y fondo */
    }

    nav ul li a:hover {
        color: white;
        background: orange;
        border-radius: 4px;
        text-decoration: none;
    }

    .menu-toggle {
        display: none;
    }

    .menu-icon {
        display: none;
        flex-direction: column;
        cursor: pointer;
    }

    .menu-icon span {
        height: 3px;
        width: 25px;
        background: #fff;
        margin: 4px 0;
    }

    /* Estilos para pantallas pequeñas */
    @media (max-width: 768px) {
        nav ul {
            display: none;
            flex-direction: column;
            width: 100%;
            position: absolute;
            top: 70px;
            left: 0;
            background: black;
        }

        .menu-toggle:checked + .menu-icon + ul {
            display: flex;
        }

        .menu-icon {
            display: flex;
        }

        nav ul li {
            margin: 10px 0;
            text-align: center;
        }
    }


    /* Estilo básico del menú desplegable */
    .profile-menu {
        display: none;  /* Inicialmente oculto */
        position: absolute;
        background-color: white;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        min-width: 160px;
        z-index: 1;
    }

    .profile-menu a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .profile-menu a:hover {
        background-color: #ddd;
    }

    /* Estilo para el "Cerrar sesión" */
    .logout {
        background-color: rgb(255, 148, 148);
    }

    /* Estilo para el enlace de perfil */
    .profile a {
        cursor: pointer;
        font-weight: bold;
        text-transform: uppercase;
        font-size: 16px;
    }

    /* Cuando el menú tiene la clase 'show', se muestra */
    .profile-menu.show {
        display: block;
    }


            /*------------------------ ESTILOS DEL HOTEL CON LA INFO ------------------------*/

            /* Contenedor principal para cada hotel */
            .hotel-container {
            width: 80%;
            margin: auto;
            display: flex;
            flex-direction: column;
            margin-top: 80px;
            }
            /* Contenedor principal de cada tarjeta de hotel */
            .hotel-card {
            display: flex;
            flex-direction: column;
            background-color: white;
            border: 2px solid #ddd;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            }
            /* Contenedor para la imagen y los datos del hotel */
            .hotel-top {
            display: flex;
            width: 100%;
            padding: 20px;
            gap: 20px; /* Espacio extra entre la imagen y la información */
            align-items: stretch; /* Asegura que la imagen y la info tengan la misma altura */
            }

            /* Contenedor derecho que agrupa la información y la descripción */
            .hotel-details {
            display: flex;
            flex-direction: column;
            flex: 1; /* Ocupa el espacio restante */
            justify-content: flex-start;
            box-sizing: border-box;
            }

            /* Información general del hotel */
            .hotel-info {
            text-align: center;   /* Centra el contenido horizontalmente */
            padding-top: 20px;    /* Separa el bloque desde arriba */
            padding-bottom: 10px; /* Mantiene algo de espacio abajo */
            margin-bottom: 10px;  /* Espacio adicional inferior */
            width: 95%;
            }


            /* Descripción del hotel */
            .hotel-description {
            font-size: 1em;
            text-align: left;
            line-height: 1.5; /* Aumenta la legibilidad */
            padding-top: 10px;
            }

            .hotel-info h3 {
            margin: 0;
            font-size: 1.6em;
            font-weight: bold;
            }

            .hotel-info p {
            margin: 5px 0;
            font-size: 1em;
            }

            /* Contenedor de la imagen */

            .hotel-image {
            width: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            }

            .hotel-image img {
            max-width: 100%;
            max-height: 100%;
            margin-left: 0px;
            }

            .hotel-description p {
            margin: 0;
            text-align: center;
            margin-right: 55px;
            font-family: Arial, sans-serif; /* Fuente Arial */
            color: #000000; /* Color de texto negro */
            }

            /* Botones de acción */
            .actions {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
            padding-bottom: 20px;
            }
            .actions a {
            color: white;
            text-decoration: none;
            padding: 10px;
            background-color: #4f4caf;
            border-radius: 5px;
            }
            .actions a:hover {
            background-color: #6461b1;
            }


            /* Para pantallas tipo tablet (hasta 1024px) */
            @media (max-width: 1024px) {
            .hotel-top {
            flex-direction: column;
            padding: 15px;
            }
            .hotel-image {
            width: 96%;
            height: 300px; /* Altura fija para tablet */
            }

            .hotel-info {
            width: 100%;
            }

            .hotel-details {
            width: 95%;
            }
            .hotel-description p {
            width: 100%;
            text-align: center;
            }
            }

            /* Estilos para pantallas pequeñas */
            @media (max-width: 768px) {
            /* La parte superior pasa a ser columna */
            .hotel-top {
            flex-direction: column;
            padding: 10px;
            }
            /* La imagen se muestra en grande, ocupando el 100% del ancho */
            .hotel-image {
            width: 100%;
            height: auto; /* Permite que la altura se ajuste automáticamente */
            }

            .hotel-image {
            width: 96%;
            height: 300px; /* Altura fija para tablet */
            }

            .hotel-info {
            width: 100%;
            }

            /* La información y descripción también ocupan el ancho completo */
            .hotel-details {
            width: 100%;
            width: 95%;
            }
            /* Elimina el margin-right extra de la descripción en móviles */
            .hotel-description p {
            margin-right: 0;
            }
            }

            /* ----- Footer General ----- */
            footer {
        background-color: #000;      /* Fondo negro */
        color: #fff;                 /* Texto blanco */
        padding: 40px 20px;          /* Espaciado interno */
        font-family: Arial, sans-serif;
        margin-top: 40px;            /* Separación del contenido anterior */
    }

    /* ----- Contenedor principal del footer ----- */
    .footer-container {
        max-width: 1200px;           /* Ancho máximo para centrar */
        margin: 0 auto;              /* Centrar horizontalmente */
        display: grid;               /* Usamos CSS Grid */
        grid-template-columns: 1fr;  /* En pantallas pequeñas, 1 columna */
        gap: 20px;                   /* Espaciado entre secciones */
        text-align: center;          /* Centrado en móviles */
    }

    /* ----- Secciones del footer ----- */

    .footer-section h4 {
        font-size: 18px;
        margin-bottom: 10px;
        color: #f1c40f;              /* Amarillo */
    }


        .footer-section p,
        .footer-section ul,
        .footer-section a {
        font-size: 14px;
        line-height: 1.6;
        color: #fff;
        margin: 0;
    }

    /* Lista de enlaces */
    .footer-section ul {
        display: flex;
        list-style: none;
        padding: 0;
        margin: 0 auto !important;  /* Centra horizontalmente */
        flex-wrap: wrap !important; /* Que se partan en varias líneas */
        justify-content: center !important;
        gap: 15px;
        max-width: 100%;            /* Que no excedan el ancho */
        overflow: visible !important; 
    }


    .footer-section ul li {
        margin: 0;                   /* Ajusta si necesitas más o menos espacio vertical */
    }


    .footer-section ul li a {
        text-decoration: none;
        color: #fff;
        transition: color 0.3s ease;
    }

    .footer-section ul li a:hover {
        color: #f1c40f;
    }

    /* ----- Redes sociales ----- */
    .social-icons {
        display: flex;
        justify-content: center; /* Centrado en pantallas pequeñas */
        flex-wrap: wrap;         /* Permite que los íconos se ajusten si no hay espacio */
        gap: 10px;
        margin-top: 10px;
    }

    .social-icons a img {
        width: 28px;
        height: 28px;
        transition: transform 0.3s ease;
    }

    .social-icons a img:hover {
        transform: scale(1.2);
    }

    /* ----- Pie de página inferior ----- */
    .footer-bottom {
        text-align: center;
        margin-top: 20px;
        border-top: 1px solid #333;
        padding-top: 20px;
        font-size: 12px;
        color: #999;
    }

    /* ----- Media Queries para pantallas más grandes ----- */
    @media (min-width: 768px) {
    .footer-container {
        grid-template-columns: repeat(3, 1fr); /* 3 columnas en tablets y desktops */
        text-align: left;                      /* Texto alineado a la izquierda */
    }
    .social-icons {
        justify-content: flex-start;           /* Redes sociales a la izquierda */
    }
    }


    /* BOTON TORNAR */
    .btn-tornar {
    background-color: #007bff; /* Fondo azul similar al de "Reservar" */
    color: white; /* Texto blanco */
    padding: 12px 20px; /* Espaciado interno */
    font-size: 1.1em; /* Tamaño de la fuente */
    border-radius: 5px; /* Bordes redondeados */
    text-decoration: none; /* Sin subrayado */
    transition: background-color 0.3s ease, transform 0.3s ease; /* Transición suave */
    }

    .btn-tornar:hover {
    background-color: #0056b3; /* Fondo más oscuro al pasar el ratón */
    transform: scale(1.05); /* Levemente más grande al pasar el ratón */
    }
</style>

    </head>
<body>
    
    <!------------------------ MENÚ DE LINKS --------------------- -->
    <nav>
        <div class="logo">
            <img src="../img/logo.png" alt="Logo">
            <h1 class="logo-title">ELEMENTAL STAY</h1>
        </div>
        <ul>
            <li><a href="../index.php" id="boton-superior"><b>INICIO</b></a></li>
            <li><a href="index.php?controlador=Hoteles&accion=listarHoteles" id="boton-superior"><b>HOTELES</b></a></li>
            <li><a href="../contactos/contactos.php" id="boton-superior"><b>CONTACTO</b></a></li>
    

            <!-- Aquí verificamos si la sesión está activa -->
            <?php if (isset($_SESSION['usuario'])): ?>
                <!-- Mostrar 'PERFIL' si la sesión está activa -->
                <li class="profile">
                    <a href="javascript:void(0);" onclick="toggleProfileMenu(event)" id="profileButton"><b>PERFIL</b></a>
                    <!-- Menú desplegable de opciones de perfil -->
                    <div class="profile-menu" id="profileMenu">
                        <a href="../perfil/perfil.php">Ver Perfil</a>
                        <a href="../inicio_session/logout.php" class="logout">Cerrar Sesión</a>
                    </div>
                </li>
            <?php else: ?>
                <!-- Si no hay sesión activa, mostrar el botón de "Iniciar sesión" -->
                <li><a href="../inicio_session/inicio_session.php" id="boton-superior"><b>INICIAR SESIÓN</b></a></li>
            <?php endif; ?>
        </ul>
    </nav>
    
    <!------------------------ SCRIPT DEL DESPLEGABLE DEL PERIL --------------------- -->
    <script>
        // Función para alternar la visibilidad del menú de perfil
        function toggleProfileMenu(event) {
            event.stopPropagation();  // Evita que el clic se propague a otras partes de la página
            var menu = document.getElementById('profileMenu');
            menu.classList.toggle('show');  // Alterna la clase 'show' para mostrar/ocultar el menú
        }

        // Cerrar el menú si se hace clic fuera de él
        window.onclick = function(event) {
            // Verificamos si el clic NO fue sobre el enlace 'PERFIL' ni el menú desplegable
            if (!event.target.matches('#profileButton') && !event.target.matches('.profile-menu') && !event.target.closest('.profile')) {
                var dropdowns = document.getElementsByClassName('profile-menu');
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');  // Oculta el menú
                    }
                }
            }
        }
    </script>

    <!------------------------ DIV DEL HOTEL CON LA INFOMRACIÓN Y FOTO --------------------- -->
    <div class="hotel-container">
        <?php while ($hotelesCompletos = $listado->fetch_assoc()) { ?>
        <div class="hotel-card">
            <div class="hotel-top">

                <div class="hotel-image">
                    <img src="<?= $config->get('imagePath') . $hotelesCompletos['img']; ?>" alt="<?= $hotelesCompletos['nombre']; ?>" />
                </div>

                <div class="hotel-details">
                    <div class="hotel-info">
                        <h3><?php echo $hotelesCompletos['nombre']; ?></h3>
                        <p><strong>Tipo:</strong> <?= isset($habitacion['tipo_habitacion']) ? $habitacion['tipo_habitacion'] : 'No disponible'; ?></p>
                        <p><strong>Comunidad:</strong> <?php echo $hotelesCompletos['comunidad_autonoma']; ?></p>
                        <p><strong>Precio:</strong> $<?= isset($habitacion['precio']) ? $habitacion['precio'] : 'No disponible'; ?></p>
                    </div>

                    <div class="hotel-description">
                        <p><?php echo $hotelesCompletos['descripcion']; ?></p>
                    </div>
                </div>

            </div>




                
        <div class="actions">
            <a href="index.php?controlador=HotelesCompletos&accion=reservaHotelesCompletos&id=<?= $hotelesCompletos['id_hotel']; ?>">Reservar</a>
        </div>

        <div class="actions">
            <a class="btn-tornar" href="index.php?controlador=Hoteles&accion=listarHoteles">Tornar</a>
        </div>

        </div>
        <?php
        }
        ?>
    </div>

    <!------------------------ FOOTER DE LA PESTAÑA --------------------- -->
    <footer>
        <div class="footer-container">

            <div class="footer-section">
                <h4>Sobre Nosotros</h4>
                <p>Elemental Stay es tu plataforma para encontrar los mejores alojamientos al mejor precio, con opciones personalizadas para cada tipo de viajero.</p>
            </div>

            <div class="footer-section">
                <h4>Enlaces Útiles</h4>
                <ul>
                    <li><a href="#">Inicio</a></li>
                    <li><a href="#">Acerca de</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li><a href="#">Términos y Condiciones</a></li>
                </ul>
            </div>

            <div class="footer-section">
                <h4>Síguenos</h4>
                <div class="social-icons">
                    <a href="#"><img src="icon-facebook.svg" alt="Facebook"></a>
                    <a href="#"><img src="icon-twitter.svg" alt="Twitter"></a>
                    <a href="#"><img src="icon-instagram.svg" alt="Instagram"></a>
                    <a href="#"><img src="icon-youtube.svg" alt="YouTube"></a>
                </div>
            </div>

        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2024 Elemental Stay. Todos los derechos reservados.</p>
        </div>
    </footer>

    <!------------------------ LINK AL HEADER --------------------- -->
    <script src="../JS/Header.js"></script>

</body>
</html>

