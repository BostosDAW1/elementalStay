<?php
class HotelesModel
{
    protected $db;
 
    public function __construct()
    {
        // Obtenemos la conexión mysqli mediante el singleton
        $this->db = SMysqli::singleton()->getConnection();
    }
 
    public function listadoHotelesTotalSinFIltros()
    {
        $sql = 'SELECT * FROM hoteles';
        $result = $this->db->query($sql);
        if (!$result) {
            die("Error en la consulta: " . $this->db->error);
        }
        // Retornamos el resultado (objeto mysqli_result)
        return $result;
    }

    // Listado de hoteles con el precio mínimo de las habitaciones disponibles
    public function listadoHotelesTotal()
    {
        $sql = "SELECT h.*, MIN(t.precio) AS min_precio
                FROM hoteles h
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel
                INNER JOIN tarifas t ON ha.id_hotel = t.id_hotel AND ha.id_categoria = t.id_categoria
                GROUP BY h.id_hotel";
        $result = $this->db->query($sql);
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    public function buscarHoteles($destino = null, $totalPersonas = null, $entrada = null, $salida = null, $precioMin = null, $precioMax = null)
    {
        // Base de la consulta
        $sql = "SELECT DISTINCT h.*, MIN(t.precio) AS min_precio
                FROM hoteles h
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel
                -- Se añade el join con temporadas para determinar la temporada vigente según la fecha de entrada
                INNER JOIN temporadas tem ON h.id_hotel = tem.id_hotel AND ? BETWEEN tem.fecha_inicio AND tem.fecha_fin
                -- Ahora, se une tarifas filtrando por la temporada obtenida
                INNER JOIN tarifas t ON ha.id_hotel = t.id_hotel 
                                      AND ha.id_categoria = t.id_categoria 
                                      AND t.id_temporada = tem.id_temporada";
    
        // Lista para almacenar las condiciones dinámicas
        $conditions = [];
        $paramTypes = "s"; // El primer parámetro es la fecha de entrada (para el join con temporadas)
        $params = [$entrada];
    
        // Agregar condiciones según los filtros proporcionados
        if (!empty($totalPersonas)) {
            $conditions[] = "ha.capacidad >= ?";
            $paramTypes .= "i";
            $params[] = $totalPersonas;
        }
        if (!empty($destino)) {
            $conditions[] = "h.comunidad_autonoma = ?";
            $paramTypes .= "s";
            $params[] = $destino;
        }
        if (!empty($entrada) && !empty($salida)) {
            $conditions[] = "NOT EXISTS (
                                SELECT 1 
                                FROM reservas r
                                WHERE r.id_hotel = h.id_hotel
                                  AND ha.id_habitacion = r.id_habitacion
                                  AND (? < r.dia_salida AND ? > r.dia_entrada)
                            )";
            $paramTypes .= "ss";
            $params[] = $entrada;
            $params[] = $salida;
        }
        if (!is_null($precioMin)) {
            $conditions[] = "t.precio >= ?";
            $paramTypes .= "d";
            $params[] = $precioMin;
        }
        if (!is_null($precioMax)) {
            $conditions[] = "t.precio <= ?";
            $paramTypes .= "d";
            $params[] = $precioMax;
        }
    
        // Si hay condiciones, agregarlas a la consulta
        if (!empty($conditions)) {
            $sql .= " WHERE " . implode(" AND ", $conditions);
        }
    
        // Agrupar por hotel
        $sql .= " GROUP BY h.id_hotel";
    
        // Preparar la consulta
        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error preparando la consulta: " . $this->db->error);
        }
    
        // Hacer bind de los parámetros (recordando que el primer parámetro es la fecha de entrada para el join)
        $stmt->bind_param($paramTypes, ...$params);
    
        // Ejecutar la consulta
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
    
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    

    
    // Método que filtra hoteles según comunidad, capacidad, disponibilidad de fechas y rango de precios
    public function buscarHotelesDisponibles($destino, $totalPersonas, $entrada = null, $salida = null, $precioMin = null, $precioMax = null)
    {
        // Validar que si una fecha es proporcionada, la otra también debe estarlo
        if ((!empty($entrada) && empty($salida)) || (empty($entrada) && !empty($salida))) {
            throw new Exception("Debes proporcionar ambas fechas: entrada y salida.");
        }
    
        // Base de la consulta: se hace JOIN con habitaciones y tarifas para obtener el precio mínimo
        $sql = "SELECT DISTINCT h.*, MIN(t.precio) AS min_precio
                FROM hoteles h
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel
                INNER JOIN tarifas t ON ha.id_hotel = t.id_hotel AND ha.id_categoria = t.id_categoria
                WHERE ha.capacidad >= ?";
    
        // Array para almacenar los parámetros de bind_param
        $paramTypes = "i"; // 1º parámetro: capacidad (int)
        $params = [$totalPersonas];
    
        // Si el destino está definido, añadirlo a la consulta
        if (!empty($destino)) {
            $sql .= " AND h.comunidad_autonoma = ?";
            $paramTypes .= "s";
            $params[] = $destino;
        }
    
        // Si las fechas están definidas, añadir la restricción de reservas
        if (!empty($entrada) && !empty($salida)) {
            $sql .= " AND NOT EXISTS (
                        SELECT 1 
                        FROM reservas r
                        WHERE r.id_hotel = h.id_hotel
                          AND ha.id_habitacion = r.id_habitacion
                          AND (? < r.dia_salida AND ? > r.dia_entrada)
                      )";
            $paramTypes .= "ss";
            $params[] = $entrada;
            $params[] = $salida;
        }
    
        // Agrupar por hotel para obtener el precio mínimo
        $sql .= " GROUP BY h.id_hotel";
    
        // Agregar filtro por rango de precios si se han definido
        if (!empty($precioMin) || !empty($precioMax)) {
            if (!empty($precioMin) && !empty($precioMax)) {
                $sql .= " HAVING min_precio BETWEEN ? AND ?";
                $paramTypes .= "dd";  // "d" para double/decimal
                $params[] = $precioMin;
                $params[] = $precioMax;
            } elseif (!empty($precioMin)) {
                $sql .= " HAVING min_precio >= ?";
                $paramTypes .= "d";
                $params[] = $precioMin;
            } elseif (!empty($precioMax)) {
                $sql .= " HAVING min_precio <= ?";
                $paramTypes .= "d";
                $params[] = $precioMax;
            }
        }
    
        // Preparar la consulta
        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error preparando la consulta: " . $this->db->error);
        }
    
        // Hacer bind de los parámetros dinámicamente
        $stmt->bind_param($paramTypes, ...$params);
    
        // Ejecutar la consulta
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
    
        return $result->fetch_all(MYSQLI_ASSOC);
    }
    
    // Método que filtra solo por comunidad y capacidad (sin verificar fechas)
    public function buscarHotelesPorComunidadYCapacidad($destino, $totalPersonas)
    {
        $sql = "SELECT DISTINCT h.*, MIN(t.precio) AS min_precio
                FROM hoteles h
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel
                INNER JOIN tarifas t ON ha.id_hotel = t.id_hotel AND ha.id_categoria = t.id_categoria
                WHERE h.comunidad_autonoma = ? AND ha.capacidad >= ?
                GROUP BY h.id_hotel";

        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error preparando la consulta: " . $this->db->error);
        }
        $stmt->bind_param("si", $destino, $totalPersonas);
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Método que filtra solo por comunidad (sin considerar capacidad ni fechas)
    public function buscarHotelesPorComunidad($destino)
    {
        $sql = "SELECT h.*, MIN(t.precio) AS min_precio
                FROM hoteles h
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel
                INNER JOIN tarifas t ON ha.id_hotel = t.id_hotel AND ha.id_categoria = t.id_categoria
                WHERE h.comunidad_autonoma = ?
                GROUP BY h.id_hotel";
            
        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error preparando la consulta: " . $this->db->error);
        }
        $stmt->bind_param("s", $destino);
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    // Método que filtra solo por capacidad (sin importar comunidad ni fechas)
    public function buscarHotelesPorCapacidad($totalPersonas)
    {
        $sql = "SELECT DISTINCT h.*, MIN(t.precio) AS min_precio
                FROM hoteles h
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel
                INNER JOIN tarifas t ON ha.id_hotel = t.id_hotel AND ha.id_categoria = t.id_categoria
                WHERE ha.capacidad >= ?
                GROUP BY h.id_hotel";
            
        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error preparando la consulta: " . $this->db->error);
        }
        $stmt->bind_param("i", $totalPersonas);
        $stmt->execute();
        $result = $stmt->get_result();
        if (!$result) {
            throw new Exception("Error en la consulta: " . $this->db->error);
        }
        return $result->fetch_all(MYSQLI_ASSOC);
    }
}
?>
