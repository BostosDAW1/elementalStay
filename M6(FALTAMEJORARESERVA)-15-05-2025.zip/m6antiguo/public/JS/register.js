document.addEventListener('DOMContentLoaded', () => {
  const registerForm = document.querySelector('#register-form');

  if (!registerForm) {
    console.error("Formulario de registro no encontrado.");
    return;
  }

  registerForm.addEventListener('submit', (e) => {
    e.preventDefault(); // Evitar que el formulario se envíe de manera tradicional

    // Obtenemos los valores de los campos del formulario
    const username = document.querySelector('#username').value;
    const email = document.querySelector('#email').value;
    const password = document.querySelector('#password').value;
    const confirmPassword = document.querySelector('#confirm-password').value;

    // Verificamos si todos los campos tienen valores
    console.log("Datos del formulario:", { username, email, password, confirmPassword });

    // Validar que los campos no estén vacíos
    if (!username || !email || !password || !confirmPassword) {
      alert("Por favor, completa todos los campos.");
      return;
    }

    // Validar si las contraseñas coinciden
    if (password !== confirmPassword) {
      alert("Las contraseñas no coinciden.");
      return;
    }

    // Crear un objeto con los datos a enviar
    const data = { username, email, password, confirmPassword };

    // Verificamos los datos que se están enviando
    console.log("Datos que se están enviando al servidor:", data);

    // Enviamos los datos al servidor usando fetch
    fetch('/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json' // Indicamos que los datos están en formato JSON
      },
      body: JSON.stringify(data) // Convertimos los datos a JSON
    })
    .then(response => {
      if (response.ok) {
        // Si la respuesta es positiva, redirigimos al usuario a la página de inicio de sesión
        window.location.href = '/inicio_sesion/inicio_sesion.html';  // Cambia a la ruta que desees
      } else {
        // Si la respuesta es un error, devolvemos el mensaje de error
        return response.text();
      }
    })
    .then(errorMessage => {
      // Mostramos el mensaje de error si lo hay
      if (errorMessage) {
        alert(errorMessage); // Mostrar el error proporcionado por el servidor
      }
    })
    .catch(error => {
      console.error('Error en la solicitud:', error);
      alert('Hubo un problema al procesar tu solicitud. Intenta nuevamente más tarde.');
    });
  });
});