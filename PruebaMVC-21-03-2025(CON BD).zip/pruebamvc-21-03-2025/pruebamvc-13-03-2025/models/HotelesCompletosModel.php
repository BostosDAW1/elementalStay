<?php
class HotelesCompletosModel
{
    protected $db;

    public function __construct()
    {
        $this->db = SMysqli::singleton()->getConnection();
    }

    public function listadoHotelesCompletosPorId($id_hotel)
    {
        $sql = "SELECT h.id_hotel, h.nombre AS hotel_nombre, h.tipo_hotel, h.comunidad_autonoma, h.precio_noche, h.descripcion, h.img,
                        ha.id_habitacion, ha.nombre AS habitacion_nombre, ha.capacidad, ha.m2, ha.wifi, ha.complementos_infantes,
                        s.id_servicio, s.nombre AS servicio_nombre
                    FROM hoteles AS h
                    LEFT JOIN habitaciones AS ha ON h.id_hotel = ha.id_hotel
                    LEFT JOIN servicios AS s ON h.nombre = s.nombre_hotel
                    WHERE h.id_hotel = ?";  // Parámetro para la consulta

        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $id_hotel);  // Solo un parámetro, por lo que el tipo es "i" para entero
        $stmt->execute();
        $result = $stmt->get_result();

        if (!$result) {
            die("Error en la consulta: " . $this->db->error);
        }

        $hoteles = [];
        while ($row = $result->fetch_assoc()) {
            $id = $row['id_hotel'];

            // Inicializamos el hotel solo una vez
            if (!isset($hoteles[$id])) {
                $hoteles[$id] = [
                    'id_hotel' => $row['id_hotel'],
                    'nombre' => $row['hotel_nombre'],  // Usamos el alias para el nombre del hotel
                    'tipo_hotel' => $row['tipo_hotel'],
                    'comunidad_autonoma' => $row['comunidad_autonoma'],
                    'precio_noche' => $row['precio_noche'],
                    'descripcion' => $row['descripcion'],
                    'img' => $row['img'],
                    'habitaciones' => [],
                    'servicios' => []
                ];
            }

            // Agregamos las habitaciones sin duplicación
            if (!is_null($row['id_habitacion'])) {
                $hoteles[$id]['habitaciones'][] = [
                    'id_habitacion' => $row['id_habitacion'],
                    'nombre' => $row['habitacion_nombre'],  // Usamos el alias
                    'capacidad' => $row['capacidad'],
                    'm2' => $row['m2'],
                    'wifi' => $row['wifi'],
                    'complementos_infantes' => $row['complementos_infantes']
                ];
            }

            // Agregamos los servicios sin duplicación
            if (!is_null($row['id_servicio'])) {
                $hoteles[$id]['servicios'][] = [
                    'id_servicio' => $row['id_servicio'],
                    'nombre' => $row['servicio_nombre']  // Usamos el alias
                ];
            }
        }

        return array_values($hoteles);  // Devolver los hoteles con habitaciones y servicios
    }
}

?>
