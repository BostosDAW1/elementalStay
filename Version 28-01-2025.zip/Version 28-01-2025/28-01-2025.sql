-- MySQL dump 10.13  Distrib 8.0.36, for Linux (x86_64)
--
-- Host: localhost    Database: elementalStay
-- ------------------------------------------------------
-- Server version	8.0.35-0ubuntu0.23.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comunidades_autonomas`
--

DROP TABLE IF EXISTS `comunidades_autonomas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comunidades_autonomas` (
  `id_comunidad` int NOT NULL AUTO_INCREMENT,
  `comunidad_autonoma` varchar(75) NOT NULL,
  PRIMARY KEY (`id_comunidad`,`comunidad_autonoma`),
  UNIQUE KEY `comunidad_autonoma_UNIQUE` (`comunidad_autonoma`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comunidades_autonomas`
--

LOCK TABLES `comunidades_autonomas` WRITE;
/*!40000 ALTER TABLE `comunidades_autonomas` DISABLE KEYS */;
INSERT INTO `comunidades_autonomas` VALUES (2,'Cantabria'),(3,'Madrid'),(1,'Valencia');
/*!40000 ALTER TABLE `comunidades_autonomas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_pagos`
--

DROP TABLE IF EXISTS `detalle_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_pagos` (
  `id_detalle_pago` int NOT NULL AUTO_INCREMENT,
  `id_pago` int DEFAULT NULL,
  `descripcion` text,
  `id_hotel` int DEFAULT NULL,
  `id_servicio` int DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_detalle_pago`),
  KEY `fk_detalle_pagos_1_idx_new` (`total`),
  KEY `fk_detalle_pagos_1_idx` (`total`),
  KEY `fk_detalle_pagos_2_idx` (`id_pago`),
  KEY `fk_detalle_pagos_3_idx` (`id_hotel`),
  KEY `fk_detalle_pagos_4_idx` (`id_servicio`),
  CONSTRAINT `fk_detalle_pagos_1` FOREIGN KEY (`total`) REFERENCES `pagos` (`total_pago`),
  CONSTRAINT `fk_detalle_pagos_2` FOREIGN KEY (`id_pago`) REFERENCES `pagos` (`id_pago`),
  CONSTRAINT `fk_detalle_pagos_3` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`),
  CONSTRAINT `fk_detalle_pagos_4` FOREIGN KEY (`id_servicio`) REFERENCES `servicios` (`id_servicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_pagos`
--

LOCK TABLES `detalle_pagos` WRITE;
/*!40000 ALTER TABLE `detalle_pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `habitacions`
--

DROP TABLE IF EXISTS `habitacions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `habitacions` (
  `id_habitacions` int NOT NULL,
  `id_hotel` int DEFAULT NULL,
  `nom` varchar(50) DEFAULT NULL,
  `capacitat` int DEFAULT NULL,
  `persones` int DEFAULT NULL,
  `m2` varchar(45) DEFAULT NULL,
  `wifi` tinyint DEFAULT NULL,
  `complements_infants` tinyint DEFAULT NULL,
  PRIMARY KEY (`id_habitacions`),
  KEY `fk_habitacions_1_idx` (`id_hotel`),
  CONSTRAINT `fk_habitacions_1` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `habitacions`
--

LOCK TABLES `habitacions` WRITE;
/*!40000 ALTER TABLE `habitacions` DISABLE KEYS */;
INSERT INTO `habitacions` VALUES (1,1,'Habitación Vista Mar',2,2,'25',1,1),(2,1,'Suite Familiar',4,4,'40',1,1),(3,1,'Habitación Doble Deluxe',2,2,'30',1,1),(4,1,'Habitación Triple',3,3,'35',1,0),(5,1,'Habitación Individual',1,1,'20',1,0),(6,2,'Habitación Estándar',2,2,'28',1,0),(7,2,'Suite con Terraza',4,4,'45',1,1),(8,2,'Habitación Familiar',3,3,'32',1,1),(9,2,'Habitación Doble Superior',2,2,'30',1,0),(10,2,'Habitación Individual Económica',1,1,'18',0,0),(16,3,'Habitación Vista al Mar',2,2,'26',1,1),(17,3,'Suite Ejecutiva',4,4,'48',1,1),(18,3,'Habitación Doble Premium',2,2,'30',1,0),(19,3,'Habitación Triple Confort',3,3,'36',1,1),(20,3,'Habitación Individual Superior',1,1,'22',0,0),(21,4,'Habitación Familiar Deluxe',4,4,'40',1,1),(22,4,'Suite con Jacuzzi',2,2,'35',1,0),(23,4,'Habitación Doble Estándar',2,2,'28',0,0),(24,4,'Habitación Triple Familiar',3,3,'32',1,1),(25,4,'Habitación Individual Económica',1,1,'18',0,0),(26,5,'Habitación Doble Vista Jardín',2,2,'30',1,1),(27,5,'Suite Familiar con Terraza',4,4,'45',1,1),(28,5,'Habitación Individual Confort',1,1,'20',0,0),(29,5,'Habitación Triple Estándar',3,3,'35',1,0),(30,5,'Habitación Doble Superior',2,2,'28',1,1),(31,6,'Habitación Deluxe con Balcón',2,2,'32',1,1),(32,6,'Suite Ejecutiva con Vista',4,4,'50',1,0),(33,6,'Habitación Doble Clásica',2,2,'29',0,0),(34,6,'Habitación Familiar Espaciosa',3,3,'40',1,1),(35,6,'Habitación Individual Económica',1,1,'18',0,0),(36,7,'Habitación Doble con Vista al Lago',2,2,'30',1,1),(37,7,'Suite Familiar con Balcón',4,4,'48',1,1),(38,7,'Habitación Individual Clásica',1,1,'22',0,0),(39,7,'Habitación Triple Confortable',3,3,'35',1,0),(40,7,'Habitación Doble Superior con Jacuzzi',2,2,'32',1,1),(41,8,'Habitación Estándar con Terraza',2,2,'28',1,0),(42,8,'Suite de Lujo',4,4,'50',1,1),(43,8,'Habitación Doble Premium',2,2,'30',0,0),(44,8,'Habitación Familiar Espaciosa',3,3,'40',1,1),(45,8,'Habitación Individual Económica',1,1,'18',0,0),(49,9,'Habitación Familiar Deluxe',4,4,'42',1,1),(50,9,'Habitación Doble Estándar',2,2,'28',0,0),(51,9,'Suite con Vista al Lago',3,3,'45',1,0),(52,9,'Habitación Individual Superior',1,1,'22',0,0),(53,9,'Habitación Doble Premium',2,2,'30',1,1),(59,10,'Habitación Doble con Vista al Jardín',2,2,'30',1,1),(60,10,'Suite Ejecutiva con Terraza',4,4,'55',1,0),(61,10,'Habitación Doble Estándar',2,2,'28',0,0),(62,10,'Habitación Familiar Deluxe',3,3,'40',1,1),(63,10,'Habitación Individual Confortable',1,1,'22',0,0),(69,11,'Habitación Doble con Vista al Mar',2,2,'30',1,1),(70,11,'Suite Familiar con Balcón',4,4,'55',1,0),(71,11,'Habitación Doble Estándar',2,2,'28',0,0),(72,11,'Habitación Triple Confortable',3,3,'40',1,1),(73,11,'Habitación Individual Clásica',1,1,'22',0,0),(74,12,'Habitación Doble Superior',2,2,'35',1,1),(75,12,'Suite de Lujo',4,4,'60',1,0),(76,12,'Habitación Doble Estándar',2,2,'28',0,0),(77,12,'Habitación Familiar Espaciosa',4,4,'45',1,1),(78,12,'Habitación Individual Económica',1,1,'20',0,0),(79,13,'Habitación Doble con Vista al Jardín',2,2,'30',1,1),(80,13,'Suite Familiar con Terraza',4,4,'55',1,0),(81,13,'Habitación Doble Clásica',2,2,'28',0,0),(82,13,'Habitación Triple Confortable',3,3,'40',1,1),(83,13,'Habitación Individual Estándar',1,1,'22',0,0),(84,14,'Habitación Doble Deluxe',2,2,'38',1,1),(85,14,'Suite Ejecutiva',4,4,'65',1,0),(86,14,'Habitación Doble Estándar',2,2,'30',0,0),(87,14,'Habitación Familiar con Vista',4,4,'50',1,1),(88,14,'Habitación Individual Confortable',1,1,'25',0,0),(89,15,'Habitación Doble con Balcón',2,2,'32',1,1),(90,15,'Suite de Lujo con Jacuzzi',4,4,'70',1,0),(91,15,'Habitación Doble Clásica',2,2,'28',0,0),(92,15,'Habitación Familiar Espaciosa',4,4,'48',1,1),(93,15,'Habitación Individual Económica',1,1,'22',0,0);
/*!40000 ALTER TABLE `habitacions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hoteles`
--

DROP TABLE IF EXISTS `hoteles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hoteles` (
  `id_hotel` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `tipo_hotel` varchar(25) DEFAULT NULL,
  `comunidad_autonoma` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`id_hotel`),
  UNIQUE KEY `idx_nombre_hotel` (`nombre`),
  KEY `fk_hoteles_1_idx` (`tipo_hotel`),
  KEY `fk_hoteles_2_idx` (`comunidad_autonoma`),
  CONSTRAINT `fk_hoteles_1` FOREIGN KEY (`tipo_hotel`) REFERENCES `tipo_hotel` (`tipo_hotel`),
  CONSTRAINT `fk_hoteles_2` FOREIGN KEY (`comunidad_autonoma`) REFERENCES `comunidades_autonomas` (`comunidad_autonoma`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hoteles`
--

LOCK TABLES `hoteles` WRITE;
/*!40000 ALTER TABLE `hoteles` DISABLE KEYS */;
INSERT INTO `hoteles` VALUES (1,'Hotel Playa Valencia','playa','Valencia'),(2,'Hotel Sol y Mar','playa','Valencia'),(3,'Hotel Mediterráneo','playa','Valencia'),(4,'Hotel Costa Azul','playa','Valencia'),(5,'Hotel Playa Dorada','playa','Valencia'),(6,'Hotel Montaña Cantabria','montaña','Cantabria'),(7,'Hotel Picos de Europa','montaña','Cantabria'),(8,'Hotel Valle de Liébana','montaña','Cantabria'),(9,'Hotel Cabañas del Bosque','montaña','Cantabria'),(10,'Hotel Mirador de la Montaña','montaña','Cantabria'),(11,'Hotel Ciudad Madrid','ciudad','Madrid'),(12,'Hotel Gran Vía','ciudad','Madrid'),(13,'Hotel Plaza Mayor','ciudad','Madrid'),(14,'Hotel Retiro','ciudad','Madrid'),(15,'Hotel Centro Histórico','ciudad','Madrid');
/*!40000 ALTER TABLE `hoteles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opiniones`
--

DROP TABLE IF EXISTS `opiniones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opiniones` (
  `id_opinion` int NOT NULL AUTO_INCREMENT,
  `id_hotel` int DEFAULT NULL,
  `id_usuario` int DEFAULT NULL,
  `calificacion` int DEFAULT NULL,
  `comentario` text,
  `fecha_opinion` date DEFAULT NULL,
  PRIMARY KEY (`id_opinion`),
  KEY `fk_opiniones_1_idx` (`id_hotel`),
  KEY `fk_opiniones_2_idx` (`id_usuario`),
  CONSTRAINT `fk_opiniones_1` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`),
  CONSTRAINT `fk_opiniones_2` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opiniones`
--

LOCK TABLES `opiniones` WRITE;
/*!40000 ALTER TABLE `opiniones` DISABLE KEYS */;
/*!40000 ALTER TABLE `opiniones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos` (
  `id_pago` int NOT NULL AUTO_INCREMENT,
  `metodo_pago` varchar(45) DEFAULT NULL,
  `total_pago` decimal(10,2) DEFAULT NULL,
  `fecha_pago` datetime DEFAULT NULL,
  PRIMARY KEY (`id_pago`),
  UNIQUE KEY `idx_total_pago` (`total_pago`),
  KEY `fk_pagos_1_idx_new` (`metodo_pago`),
  KEY `fk_pagos_1_idx` (`metodo_pago`),
  CONSTRAINT `fk_pagos_1` FOREIGN KEY (`metodo_pago`) REFERENCES `tipos_pagos` (`metodo_pago`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paises_usuario`
--

DROP TABLE IF EXISTS `paises_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paises_usuario` (
  `id_pais` int NOT NULL AUTO_INCREMENT,
  `pais` varchar(70) DEFAULT NULL,
  PRIMARY KEY (`id_pais`),
  UNIQUE KEY `pais_UNIQUE` (`pais`)
) ENGINE=InnoDB AUTO_INCREMENT=371 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paises_usuario`
--

LOCK TABLES `paises_usuario` WRITE;
/*!40000 ALTER TABLE `paises_usuario` DISABLE KEYS */;
INSERT INTO `paises_usuario` VALUES (187,'Afganistán'),(188,'Albania'),(189,'Alemania'),(190,'Andorra'),(191,'Angola'),(192,'Antigua y Barbuda'),(193,'Arabia Saudita'),(194,'Armenia'),(195,'Australia'),(196,'Austria'),(197,'Azerbaiyán'),(198,'Bahamas'),(199,'Bahrein'),(200,'Bangladés'),(201,'Barbados'),(202,'Baréin'),(203,'Bélgica'),(204,'Belice'),(205,'Benín'),(206,'Bielorrusia'),(207,'Birmania'),(208,'Bolivia'),(209,'Bosnia y Herzegovina'),(210,'Botsuana'),(211,'Brasil'),(212,'Brunéi'),(213,'Bulgaria'),(214,'Burkina Faso'),(215,'Burundi'),(216,'Cabo Verde'),(217,'Camboya'),(218,'Camerún'),(219,'Canadá'),(220,'Catar'),(221,'Chile'),(222,'China'),(223,'Chipre'),(224,'Colombia'),(225,'Comoras'),(226,'Congo'),(227,'Corea del Norte'),(228,'Corea del Sur'),(229,'Costa Rica'),(230,'Croacia'),(231,'Cuba'),(232,'Curazao'),(233,'Dinamarca'),(234,'Dominica'),(235,'Ecuador'),(236,'Egipto'),(237,'El Salvador'),(238,'Emiratos Árabes Unidos'),(239,'Eslovaquia'),(240,'Eslovenia'),(241,'España'),(242,'Estados Unidos'),(243,'Estonia'),(244,'Etiopía'),(245,'Filipinas'),(246,'Finlandia'),(247,'Fiyi'),(248,'Francia'),(249,'Gabón'),(250,'Gambia'),(251,'Gana'),(252,'Granada'),(253,'Grecia'),(254,'Guatemala'),(255,'Guinea'),(256,'Guinea Ecuatorial'),(257,'Guinea-Bisáu'),(258,'Guyana'),(259,'Haití'),(260,'Honduras'),(261,'Hungría'),(262,'India'),(263,'Indonesia'),(264,'Irak'),(265,'Irán'),(266,'Irlanda'),(267,'Islandia'),(268,'Islas Marshall'),(269,'Islas Salomón'),(270,'Israel'),(271,'Italia'),(272,'Jamaica'),(273,'Japón'),(274,'Jordania'),(275,'Kazajistán'),(276,'Kenia'),(277,'Kirguistán'),(278,'Kiribati'),(279,'Kuwait'),(280,'Laos'),(281,'Lesoto'),(282,'Letonia'),(283,'Líbano'),(284,'Liberia'),(285,'Libia'),(286,'Liechtenstein'),(287,'Lituania'),(288,'Luxemburgo'),(289,'Madagascar'),(290,'Malasia'),(291,'Malaui'),(292,'Maldivas'),(293,'Malí'),(294,'Malta'),(295,'Marruecos'),(296,'Mauricio'),(297,'Mauritania'),(298,'México'),(299,'Micronesia'),(300,'Moldavia'),(301,'Mónaco'),(302,'Mongolia'),(303,'Montenegro'),(304,'Mozambique'),(305,'Namibia'),(306,'Nauru'),(307,'Nepal'),(308,'Nicaragua'),(309,'Níger'),(310,'Nigeria'),(311,'Noruega'),(312,'Nueva Zelanda'),(313,'Omán'),(314,'Pakistán'),(315,'Palaos'),(316,'Panamá'),(317,'Papúa Nueva Guinea'),(318,'Paraguay'),(319,'Perú'),(320,'Polonia'),(321,'Portugal'),(322,'Reino Unido'),(323,'República Checa'),(324,'República Dominicana'),(325,'Ruanda'),(326,'Rumanía'),(327,'Samoa'),(328,'San Cristóbal y Nieves'),(329,'San Marino'),(330,'San Vicente y las Granadinas'),(331,'Santa Lucía'),(332,'Santo Tomé y Príncipe'),(333,'Senegal'),(334,'Serbia'),(335,'Seychelles'),(336,'Sierra Leona'),(337,'Singapur'),(338,'Siria'),(339,'Somalia'),(340,'Sri Lanka'),(341,'Sudáfrica'),(342,'Sudán'),(343,'Sudán del Sur'),(344,'Suecia'),(345,'Suiza'),(346,'Surinam'),(347,'Svajilandia'),(348,'Tailandia'),(349,'Tanzania'),(350,'Tayikistán'),(351,'Timor Oriental'),(352,'Togo'),(353,'Tonga'),(354,'Trinidad y Tobago'),(355,'Túnez'),(356,'Turkmenistán'),(357,'Turquía'),(358,'Tuvalu'),(360,'Ucrania'),(359,'Uganda'),(361,'Uruguay'),(362,'Uzbekistán'),(363,'Vanuatu'),(364,'Vaticano'),(365,'Venezuela'),(366,'Vietnam'),(367,'Yemen'),(368,'Yibuti'),(369,'Zambia'),(370,'Zimbabue');
/*!40000 ALTER TABLE `paises_usuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `promociones`
--

DROP TABLE IF EXISTS `promociones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promociones` (
  `id_promocion` int NOT NULL AUTO_INCREMENT,
  `id_servicio` int DEFAULT NULL,
  `id_hotel` varchar(45) DEFAULT NULL,
  `descripcion` text,
  `fecha_inicio` datetime DEFAULT NULL,
  `fecha_fin` datetime DEFAULT NULL,
  `descuento` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id_promocion`),
  KEY `fk_promociones_1_idx` (`id_servicio`),
  KEY `fk_promociones_2_idx` (`id_hotel`),
  CONSTRAINT `fk_promociones_1` FOREIGN KEY (`id_servicio`) REFERENCES `servicios` (`id_servicio`),
  CONSTRAINT `fk_promociones_2` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promociones`
--

LOCK TABLES `promociones` WRITE;
/*!40000 ALTER TABLE `promociones` DISABLE KEYS */;
/*!40000 ALTER TABLE `promociones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservas`
--

DROP TABLE IF EXISTS `reservas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservas` (
  `id_reserva` int NOT NULL AUTO_INCREMENT,
  `id_usuario` int DEFAULT NULL,
  `id_hotel` int DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `dia_entrada` datetime DEFAULT NULL,
  `dia_salida` datetime DEFAULT NULL,
  `cantidad_personas` int DEFAULT NULL,
  `mascota` tinyint DEFAULT NULL,
  `plaza_coche_parking` tinyint DEFAULT NULL,
  `id_habitacions` int DEFAULT NULL,
  PRIMARY KEY (`id_reserva`),
  KEY `fk_reservas_2_idx` (`id_hotel`),
  KEY `fk_reservas_1_idx` (`id_usuario`),
  KEY `fk_reservas_3_idx` (`id_habitacions`),
  CONSTRAINT `fk_reservas_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`),
  CONSTRAINT `fk_reservas_2` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`),
  CONSTRAINT `fk_reservas_3` FOREIGN KEY (`id_habitacions`) REFERENCES `habitacions` (`id_habitacions`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservas`
--

LOCK TABLES `reservas` WRITE;
/*!40000 ALTER TABLE `reservas` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `servicios`
--

DROP TABLE IF EXISTS `servicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `servicios` (
  `id_servicio` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) DEFAULT NULL,
  `nombre_hotel` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_servicio`),
  KEY `fk_servicios_1_idx_new` (`nombre_hotel`),
  KEY `fk_servicios_1_idx` (`nombre_hotel`),
  CONSTRAINT `fk_servicios_1` FOREIGN KEY (`nombre_hotel`) REFERENCES `hoteles` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servicios`
--

LOCK TABLES `servicios` WRITE;
/*!40000 ALTER TABLE `servicios` DISABLE KEYS */;
INSERT INTO `servicios` VALUES (10,'WiFi gratuito','Hotel Playa Valencia'),(11,'Desayuno incluido','Hotel Playa Valencia'),(12,'Servicio de limpieza diario','Hotel Playa Valencia'),(13,'Piscina exterior','Hotel Sol y Mar'),(14,'Spa y bienestar','Hotel Sol y Mar'),(15,'Restaurante con vista al mar','Hotel Sol y Mar'),(16,'Actividades acuáticas','Hotel Sol y Mar'),(17,'WiFi gratuito','Hotel Mediterráneo'),(18,'Desayuno buffet','Hotel Mediterráneo'),(19,'Acceso directo a la playa','Hotel Mediterráneo'),(20,'Restaurante gourmet','Hotel Costa Azul'),(21,'Bar en la piscina','Hotel Costa Azul'),(22,'Servicio de transporte al aeropuerto','Hotel Costa Azul'),(23,'Actividades recreativas','Hotel Costa Azul'),(24,'WiFi gratuito','Hotel Playa Dorada'),(25,'Club infantil','Hotel Playa Dorada'),(26,'Actividades deportivas en la playa','Hotel Playa Dorada'),(27,'Bar en la playa','Hotel Playa Dorada'),(28,'Senderismo guiado','Hotel Montaña Cantabria'),(29,'Desayuno típico de la región','Hotel Montaña Cantabria'),(30,'Alquiler de bicicletas','Hotel Montaña Cantabria'),(31,'Zona de spa y relajación','Hotel Montaña Cantabria'),(32,'Excursiones a la montaña','Hotel Picos de Europa'),(33,'Restaurante con comida local','Hotel Picos de Europa'),(34,'Guías turísticos disponibles','Hotel Picos de Europa'),(35,'Catas de vino','Hotel Valle de Liébana'),(36,'Senderismo y rutas naturales','Hotel Valle de Liébana'),(37,'Zona de juegos para niños','Hotel Valle de Liébana'),(38,'Cabañas privadas en la naturaleza','Hotel Cabañas del Bosque'),(39,'Actividades al aire libre','Hotel Cabañas del Bosque'),(40,'Barbacoa y picnic en el bosque','Hotel Cabañas del Bosque'),(41,'Vistas panorámicas','Hotel Mirador de la Montaña'),(42,'Senderismo guiado','Hotel Mirador de la Montaña'),(43,'Restaurante con cocina regional','Hotel Mirador de la Montaña'),(44,'WiFi gratuito en todo el hotel','Hotel Ciudad Madrid'),(45,'Centro de negocios','Hotel Ciudad Madrid'),(46,'Servicio de habitaciones 24 horas','Hotel Ciudad Madrid'),(47,'Gimnasio equipado','Hotel Ciudad Madrid'),(48,'Ubicación céntrica','Hotel Gran Vía'),(49,'Terraza en la azotea','Hotel Gran Vía'),(50,'Bar y lounge','Hotel Gran Vía'),(51,'Desayuno continental incluido','Hotel Gran Vía'),(52,'Ubicación en el corazón de la ciudad','Hotel Plaza Mayor'),(53,'Desayuno buffet','Hotel Plaza Mayor'),(54,'Recepción 24 horas','Hotel Plaza Mayor'),(55,'Servicio de transporte al aeropuerto','Hotel Plaza Mayor'),(56,'Jardín privado','Hotel Retiro'),(57,'Spa y wellness','Hotel Retiro'),(58,'Alquiler de bicicletas','Hotel Retiro'),(59,'Restaurante gourmet','Hotel Retiro'),(60,'Visitas guiadas a monumentos cercanos','Hotel Centro Histórico'),(61,'WiFi gratuito en áreas comunes','Hotel Centro Histórico'),(62,'Cafetería y bar','Hotel Centro Histórico'),(63,'Servicio de lavandería','Hotel Centro Histórico');
/*!40000 ALTER TABLE `servicios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tarifas`
--

DROP TABLE IF EXISTS `tarifas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tarifas` (
  `id_tarifa` int NOT NULL AUTO_INCREMENT,
  `id_hotel` int DEFAULT NULL,
  `inicio_tarifa` date DEFAULT NULL,
  `fin_tarifa` date DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id_tarifa`),
  KEY `fk_tarifas_1_idx` (`id_hotel`),
  CONSTRAINT `fk_tarifas_1` FOREIGN KEY (`id_hotel`) REFERENCES `hoteles` (`id_hotel`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tarifas`
--

LOCK TABLES `tarifas` WRITE;
/*!40000 ALTER TABLE `tarifas` DISABLE KEYS */;
/*!40000 ALTER TABLE `tarifas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_hotel`
--

DROP TABLE IF EXISTS `tipo_hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipo_hotel` (
  `id_tipo_hotel` int NOT NULL AUTO_INCREMENT,
  `tipo_hotel` varchar(25) NOT NULL,
  PRIMARY KEY (`id_tipo_hotel`,`tipo_hotel`),
  UNIQUE KEY `idx_tipo_hotel` (`tipo_hotel`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_hotel`
--

LOCK TABLES `tipo_hotel` WRITE;
/*!40000 ALTER TABLE `tipo_hotel` DISABLE KEYS */;
INSERT INTO `tipo_hotel` VALUES (2,'ciudad'),(1,'montaña'),(3,'playa');
/*!40000 ALTER TABLE `tipo_hotel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_pagos`
--

DROP TABLE IF EXISTS `tipos_pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipos_pagos` (
  `id_tipo_pago` int NOT NULL AUTO_INCREMENT,
  `metodo_pago` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_pago`),
  UNIQUE KEY `idx_metodo_pago` (`metodo_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_pagos`
--

LOCK TABLES `tipos_pagos` WRITE;
/*!40000 ALTER TABLE `tipos_pagos` DISABLE KEYS */;
INSERT INTO `tipos_pagos` VALUES (3,'facial'),(2,'paypal'),(1,'tarjeta');
/*!40000 ALTER TABLE `tipos_pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `dni` varchar(20) DEFAULT NULL,
  `nombre` varchar(35) DEFAULT NULL,
  `apellidos` varchar(50) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL,
  `nombre_pais` varchar(45) DEFAULT NULL,
  `contraseña` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `correo_UNIQUE` (`correo`),
  KEY `fk_usuarios_1_idx` (`nombre_pais`),
  CONSTRAINT `fk_usuarios_1` FOREIGN KEY (`nombre_pais`) REFERENCES `paises_usuario` (`pais`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,NULL,'pepe',NULL,'a@gmail.com',NULL,NULL,'$2y$10$KdkcAfEP65dSP8qALHSx0.dHg94Q3.7S5tFY61Ik.pWiuL.o4MB/K'),(2,NULL,'Jesus Pardo Carrillo',NULL,'jesus1989@gmail.com',NULL,NULL,'$2y$10$eQ.bXtkKA7butD3N8jskcOH.9s7AshshmiEfEM4ctJqKvhW15toaC'),(5,NULL,'e',NULL,'e@gmail.com',NULL,NULL,'$2y$10$TAXS6e3A2ZHch4imIlqe.Ov/Md7Fs3KGad4UgcjN7BJXq3NgZZcJO'),(6,NULL,'5',NULL,'ea@gmail.com',NULL,NULL,'$2y$10$0MqQ3H37/dVO8z1SXKGt3uelHH96wpswxtHU.B2cbkRGb0lcB/dDO'),(7,NULL,'Pepe',NULL,'Pepe1976@gmail.com',NULL,NULL,'$2y$10$6zVFgCPQ7xe1nY4VAF3r4OvQ2LhES3lihj0w4tCBaHzJTfBfOeNzC'),(10,NULL,'jose',NULL,'jose@gmail.com',NULL,NULL,'$2y$10$ZB3LbZ.SrLOm55SdNVRIIut87x1GLBJBmdu1F2Phf94GBZVS4JY4a'),(12,NULL,'y',NULL,'y@gmail.com',NULL,NULL,'$2y$10$oEvZmq8f/B84BCWgoeis3e326fpWC4v.81UT/KbOXkc8auKdOkITK'),(15,NULL,'pepa',NULL,'pepa@gmail.com',NULL,NULL,'$2y$10$N2uUzvPUlNoBxfYFyvDEtuNrcBplT/FB.on4GvHB.BJHsAg/iSm6m'),(16,NULL,'alberto',NULL,'alberto1987@gmail.com',NULL,NULL,'$2y$10$20..YVysh.H8ZUgGfwEPROJ2HYysb9dQiKyw3ZTQcd8kmspQDNksq'),(18,NULL,'bruno',NULL,'bruno@gmail.com',NULL,NULL,'$2y$10$dUHhWbwhpCgBFmnjDJleiOY4Yv9vj6GasWPcQsIs.R5VZZVNIcwuu'),(19,'30303030L','hugo',NULL,'hugo@gmail.com',NULL,NULL,'$2y$10$oHBBMb5fqA/vEzxmELP2MegViyPzJv9e96r7Y91mHkcNU5zNvCSBe'),(20,NULL,'admin',NULL,'admin@gmail.com',NULL,NULL,'$2y$10$DkZC0tJ4kiNQZ2wRjnw0JOuvjcPJih655bmdlbDnsStpe0ck.Ndua'),(23,NULL,'cabeza',NULL,'cabeza@gmail.com',NULL,NULL,'$2y$10$5jrK9Kymh.mjhJLuJ4tdj.C.Q/A/P87BJ.CWv/I09Ai4yByUosG6.'),(24,NULL,'felipe',NULL,'felipe@gmail.com',NULL,NULL,'$2y$10$oM7UFmVTMMQA3w4mfTazPOYt7RbSF.OG0NdWY6cElLE6jA3k/UBC.'),(25,'20202020H','pepe','González Perez','pepe@gmail.com','937788102','Albania','$2y$10$PiJMpXAhk4BjRXOWbTmAmeab/jtgzNzJ9pmiJijf3SA4ymAHh42Lq'),(26,NULL,'mario merino perez',NULL,'mario@gmail.com',NULL,NULL,'$2y$10$w4iYoLrOJs8EOyvuxpNbsu4046ljGR1DXXuQhVZp0da5vy0jQOn6i'),(27,NULL,'reyna',NULL,'reyna@gmail.com',NULL,NULL,'$2y$10$BV209XVktu3vfL/wiEi3KeKvlcwR1FTQbFbYdxyie089.4G/qHSMa'),(28,NULL,'gekko',NULL,'gekko@gmail.com',NULL,NULL,'$2y$10$UZKfBgVZjkq7Ws.TXEAVMuy0440VqxixXoJk0XCqXEtQkJ6qOsS/G'),(30,NULL,'tomate','moreno','to@gmail.com',NULL,'España','$2y$10$5H1NafQolOzrqDdue/gBweC7sa0rA18yLRH/fBXeu3phU.B00ly0W'),(31,NULL,'papaya',NULL,'papaya@gmail.com',NULL,NULL,'$2y$10$X25dKfjsQT.wyoHVi9JIx.PJCmISTB3rB3DWOChcgpdKs8bC1Xo.O'),(32,NULL,'albaricoque',NULL,'albaricoque@gmail.com',NULL,NULL,'$2y$10$pBCv0HvXAE8fBrqakGbon.G/rs5mDP9Vc1mf.nh8PzpsOU4iQKWmi'),(35,NULL,'b',NULL,'b@gmail.com',NULL,NULL,'$2y$10$2BWJ7K5NoGmvpIeHsje81e3nRFNt7I/czP42GtS3MiccHGuEMJx4K'),(36,NULL,'jabali',NULL,'jabali@gmail.com',NULL,NULL,'$2y$10$f1xciuf0dCBI8OdD1mU.FuqrxuS7/yzRNmea1Q3kC2DQFAb4dopCK');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-28 16:24:27
