<?php
class HotelesCompletosModel
{
    protected $db;

    public function __construct()
    {
        $this->db = SMysqli::singleton()->getConnection();
    }

    public function listadoHotelesCompletosPorId($id_hotel)
    {
        $sql = "SELECT 
                    h.id_hotel, 
                    h.nombre AS hotel_nombre, 
                    h.tipo_hotel, 
                    h.comunidad_autonoma, 
                    h.precio_noche, 
                    h.descripcion, 
                    h.img,
                    IFNULL(GROUP_CONCAT(DISTINCT CONCAT_WS('|', ha.id_habitacion, ha.nombre, ha.capacidad, ha.m2, ha.wifi) SEPARATOR '||'), '') AS habitaciones,
                    IFNULL(GROUP_CONCAT(DISTINCT CONCAT_WS('|', s.id_servicio, s.nombre) SEPARATOR '||'), '') AS servicios
                FROM hoteles AS h
                LEFT JOIN habitaciones AS ha ON h.id_hotel = ha.id_hotel
                LEFT JOIN servicios AS s ON h.nombre = s.nombre_hotel
                WHERE h.id_hotel = ?
                GROUP BY h.id_hotel";

        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $id_hotel);
        $stmt->execute();
        $result = $stmt->get_result();

        if (!$result) {
            die("Error en la consulta: " . $this->db->error);
        }

        $hoteles = [];
        while ($row = $result->fetch_assoc()) {
            $id = $row['id_hotel'];

            // Inicializamos el hotel solo una vez
            if (!isset($hoteles[$id])) {
                $hoteles[$id] = [
                    'id_hotel' => $row['id_hotel'],
                    'nombre' => $row['hotel_nombre'],  // Usamos el alias para el nombre del hotel
                    'tipo_hotel' => $row['tipo_hotel'],
                    'comunidad_autonoma' => $row['comunidad_autonoma'],
                    'precio_noche' => $row['precio_noche'],
                    'descripcion' => $row['descripcion'],
                    'img' => $row['img'],
                    'habitaciones' => [],
                    'servicios' => []
                ];
            }

            // Procesar habitaciones agrupadas
            if (!empty($row['habitaciones'])) {
                $rooms = explode('||', $row['habitaciones']);
                foreach ($rooms as $room) {
                    $fields = explode('|', $room);
                    if (count($fields) === 5 && $fields[0] !== '') { // Verifica que haya datos válidos
                        $hoteles[$id]['habitaciones'][] = [
                            'id_habitacion' => $fields[0],
                            'nombre'        => $fields[1],
                            'capacidad'     => $fields[2],
                            'm2'            => $fields[3],
                            'wifi'          => $fields[4]
                        ];
                    }
                }
            }

            // Procesar servicios agrupados
            if (!empty($row['servicios'])) {
                $servs = explode('||', $row['servicios']);
                foreach ($servs as $servicio) {
                    $fields = explode('|', $servicio);
                    if (count($fields) === 2 && $fields[0] !== '') {
                        $hoteles[$id]['servicios'][] = [
                            'id_servicio' => $fields[0],
                            'nombre'      => $fields[1]
                        ];
                    }
                }
            }
        }

        return array_values($hoteles);  // Devolver los hoteles con habitaciones y servicios
    }
}
?>
