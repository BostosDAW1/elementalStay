<?php

class HotelesModel {

    // Función para obtener los hoteles disponibles según los filtros
    public static function obtenerHotelesDisponibles($destino, $entrada, $salida, $adultos, $ninos, $habitaciones) {
        // Conectar a la base de datos (asegúrate de tener tu conexión a la base de datos)
        $db = new mysqli("localhost", "usuario", "contraseña", "nombre_base_de_datos");

        // Construir la consulta
        $query = "SELECT h.id_hotel, h.nombre, h.tipo_hotel, h.descripcion, h.comunidad_autonoma, 
                h.direccion, h.telefono, h.email, h.precio_noche, h.estrellas, h.img
                FROM hoteles h 
                INNER JOIN habitaciones ha ON h.id_hotel = ha.id_hotel 
                LEFT JOIN disponibilidad_habitaciones dh ON ha.id_habitacion = dh.id_habitacion
                WHERE h.comunidad_autonoma LIKE ? 
                AND dh.disponibilidad = 1 
                AND ha.capacidad >= ? 
                AND ha.personas >= ? 
                AND (dh.fecha_inicio <= ? AND dh.fecha_fin >= ?) 
                GROUP BY h.id_hotel";

        // Preparar la sentencia
        $stmt = $db->prepare($query);
        $destino = "%$destino%"; // Filtrar por destino
        $stmt->bind_param('sssss', $destino, $adultos, $ninos, $entrada, $salida);

        // Ejecutar la consulta
        $stmt->execute();
        $result = $stmt->get_result();

        // Almacenar los resultados en un array
        $hoteles = [];
        while ($row = $result->fetch_assoc()) {
            $hoteles[] = $row;
        }

        // Cerrar la conexión
        $stmt->close();
        $db->close();

        return $hoteles;
    }
}
