// EFECTOS BOTON ENLACES Y FILTROS - TRANSICION
document.addEventListener('DOMContentLoaded', () => {
    // Función para hacer scroll suave al div#hoteles
    function scrollToHoteles(targetId) {
      const target = document.querySelector(targetId);
      const offset = 100; // Cambiar el offset según lo necesario
      const elementPosition = target.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }

    // Función para manejar el clic en los enlaces de tipo de hotel
    function handleTipoHotelClick(tipo) {
      // Filtrar por tipo de hotel
      filtrarPorTipoDeHotel(tipo);

      // Hacer scroll a la sección de hoteles
      scrollToHoteles('#hoteles');
    }

    // Enlaces de tipo de hotel
    const enlacesTipoHotel = document.querySelectorAll('a[href^="#"]');

    // Asignar el evento de clic a cada enlace
    enlacesTipoHotel.forEach(enlace => {
      enlace.addEventListener('click', (event) => {
        event.preventDefault(); // Evitar el comportamiento predeterminado

        // Verificar si el enlace tiene un 'onclick' para filtrar por tipo de hotel
        if (enlace.getAttribute('onclick')) {
          // Extraer el tipo de hotel del atributo 'onclick'
          const tipoHotel = enlace.getAttribute('onclick').match(/'(.*?)'/)?.[1];

          if (tipoHotel) {
            // Llamar a la función que filtra y hace scroll
            handleTipoHotelClick(tipoHotel);
          }
        } else {
          // Si no hay 'onclick', solo hacer scroll al div#hoteles
          scrollToHoteles('#hoteles');
        }
      });
    });
  });