let slideIndex = 0; // Cambié a 0 para facilitar el control
showSlides();

// Avanza al siguiente slide cada 4 segundos (4000ms)
setInterval(function() {
    slideIndex++;
    showSlides();
}, 4000); // Cambia de imagen cada 4000ms (4 segundos)

function showSlides() {
    let slides = document.getElementsByClassName("mySlides");
    
    // Si el índice de la diapositiva es mayor que el número de diapositivas, reiniciamos
    if (slideIndex >= slides.length) {
        slideIndex = 0; // Reinicia el índice a 0 cuando llegue al final
    }

    // Oculta todas las diapositivas
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }

    // Muestra la diapositiva actual
    slides[slideIndex].style.display = "block";
}
