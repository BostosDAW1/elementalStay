<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elemental Stay - Hoteles</title>
    <link rel="stylesheet" href="../CSS/hoteles.css">
    <link rel="stylesheet" href="../CSS/header.css">
    <link rel="stylesheet" href="../CSS/footer.css">
</head>
<body>

    <!------------------------ MENÚ DE LINKS --------------------- -->
    <nav>
        <div class="logo">
            <img src="../img/logo.png" alt="Logo">
            <h1 class="logo-title">ELEMENTAL STAY</h1>
        </div>
        <ul>
            <li><a href="../index.php" id="boton-superior"><b>INICIO</b></a></li>
            <li><a href="hoteles.php" id="boton-superior"><b>HOTELES</b></a></li>
            <li><a href="../contactos/contactos.php" id="boton-superior"><b>CONTACTO</b></a></li>

            <!-- Aquí verificamos si la sesión está activa -->
            <?php if (isset($_SESSION['usuario'])): ?>
                <!-- Mostrar 'PERFIL' si la sesión está activa -->
                <li class="profile">
                    <a href="javascript:void(0);" onclick="toggleProfileMenu(event)" id="profileButton"><b>PERFIL</b></a>
                    <!-- Menú desplegable de opciones de perfil -->
                    <div class="profile-menu" id="profileMenu">
                        <a href="../perfil/perfil.php">Ver Perfil</a>
                        <a href="../inicio_session/logout.php" class="logout">Cerrar Sesión</a>
                    </div>
                </li>
            <?php else: ?>
                <!-- Si no hay sesión activa, mostrar el botón de "Iniciar sesión" -->
                <li><a href="../inicio_session/inicio_session.php" id="boton-superior"><b>INICIAR SESIÓN</b></a></li>
            <?php endif; ?>
        </ul>
    </nav>

    <script>
        // Función para alternar la visibilidad del menú de perfil
        function toggleProfileMenu(event) {
            event.stopPropagation();  // Evita que el clic se propague a otras partes de la página
            var menu = document.getElementById('profileMenu');
            menu.classList.toggle('show');  // Alterna la clase 'show' para mostrar/ocultar el menú
        }

        // Cerrar el menú si se hace clic fuera de él
        window.onclick = function(event) {
            // Verificamos si el clic NO fue sobre el enlace 'PERFIL' ni el menú desplegable
            if (!event.target.matches('#profileButton') && !event.target.matches('.profile-menu') && !event.target.closest('.profile')) {
                var dropdowns = document.getElementsByClassName('profile-menu');
                for (var i = 0; i < dropdowns.length; i++) {
                    var openDropdown = dropdowns[i];
                    if (openDropdown.classList.contains('show')) {
                        openDropdown.classList.remove('show');  // Oculta el menú
                    }
                }
            }
        }
    </script>




    <!------------------------ MENÚ DE LINKS --------------------- -->
    <div class="search-bar">
        <input type="text" placeholder="¿Dónde quieres ir?">
        <select id="hotel-select">
            <!-- Opciones dinámicas generadas desde PHP -->
            <option value="all">Todos los hoteles</option>
            <input type="date" value="2024-10-10">
        </select>
    </div>





    <!------------------------ CONTAINER DE LOS HOTELES --------------------- -->
    <div class="container">
        <div class="results" id="hotel-list">
            <!-- Lista de hoteles generada dinámicamente desde PHP -->
            <?php
            // Ejemplo de datos simulados (normalmente provendrían de una base de datos)
            $hoteles = [
                [
                    "nombre" => "Hotel Sol",
                    "descripcion" => "Ubicado en el corazón de la ciudad, ideal para disfrutar de vistas y gastronomía.",
                    "ciudad" => "Madrid",
                    "pais" => "España",
                    "imagen" => "../images/a5.jpeg"
                ],
                [
                    "nombre" => "Mar y Arena",
                    "descripcion" => "Un lugar frente al mar perfecto para relajarte y disfrutar de la brisa marina.",
                    "ciudad" => "Cancún",
                    "pais" => "México",
                    "imagen" => "../images/a6.jpeg"
                ],
                [
                    "nombre" => "Montaña Azul",
                    "descripcion" => "Ideal para amantes de la naturaleza con actividades al aire libre incluidas.",
                    "ciudad" => "Interlaken",
                    "pais" => "Suiza",
                    "imagen" => "../images/a7.jpeg"
                ],
                [
                    "nombre" => "Rincón Colonial",
                    "descripcion" => "Hotel boutique con encanto histórico, ideal para explorar la cultura local.",
                    "ciudad" => "Cartagena",
                    "pais" => "Colombia",
                    "imagen" => "../images/a8.jpeg"
                ],
            ];

            foreach ($hoteles as $hotel) {
                echo "
                <div class='result-item' data-hotel='{$hotel['nombre']}'>
                    <img src='{$hotel['imagen']}' alt='Imagen del hotel'>
                    <div class='description'>
                        <h3>{$hotel['nombre']}</h3>
                        <p>{$hotel['descripcion']}</p>
                        <p><strong>Ciudad:</strong> {$hotel['ciudad']}</p>
                        <p><strong>País:</strong> {$hotel['pais']}</p>
                    </div>
                </div>
                ";
            }
            ?>
        </div>

        <div class="map">
            <!-- Google Maps iframe dinámico -->
            <iframe 
                id="google-map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.8354345091843!2d-122.40125888468113!3d37.79359297975644!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858064a4053b33%3A0x6a3491e7b4f7d54c!2sSan%20Francisco%20City%20Hall!5e0!3m2!1ses!2ses!4v1638927961178!5m2!1ses!2ses" 
                width="100%" 
                height="100%" 
                style="border:0;" 
                allowfullscreen="" 
                loading="lazy">
            </iframe>
        </div>
    </div>




    
    <!------------------- APARTADO HTML - FOOTER ------------------>
    <footer>
        <div class="footer-container">
            <div class="footer-section">
                <h4>Sobre Nosotros</h4>
                <p>Elemental Stay es tu plataforma para encontrar los mejores alojamientos al mejor precio, con opciones personalizadas para cada tipo de viajero.</p>
            </div>
            <div class="footer-section">
                <h4>Enlaces Útiles</h4>
                <ul>
                    <li><a href="#">Inicio</a></li>
                    <li><a href="#">Acerca de</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li><a href="#">Términos y Condiciones</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Síguenos</h4>
                <div class="social-icons">
                    <a href="#"><img src="icon-facebook.svg" alt="Facebook"></a>
                    <a href="#"><img src="icon-twitter.svg" alt="Twitter"></a>
                    <a href="#"><img src="icon-instagram.svg" alt="Instagram"></a>
                    <a href="#"><img src="icon-youtube.svg" alt="YouTube"></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Elemental Stay. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script src="../JS/Header.js"></script>
    <script src="../JS/hoteles.js"></script>
</body>
</html>
