// FUNCION PRINCIPAL INICIO DE SESIÓN
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.querySelector('#login-form');

  if (!loginForm) {
    console.error("Formulario de inicio de sesión no encontrado.");
    return;
  }

  loginForm.addEventListener('submit', (e) => {
    e.preventDefault(); // Prevenir el envío normal del formulario

    const username = document.querySelector('#username').value;
    const password = document.querySelector('#password').value;

    // Verificar que los campos no estén vacíos
    if (!username || !password) {
      alert("Por favor, ingresa todos los campos.");
      return;
    }

    // Crear los datos a enviar en formato JSON
    const loginData = { username, password };

    // Enviar los datos usando fetch
    fetch('/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(loginData) // Convertir los datos a JSON
    })
    .then(response => {
      if (response.ok) {
        // Si la respuesta es positiva, redirigir al usuario a la página principal
        window.location.href = '/'; // Redirige a la página principal
      } else {
        // Si la respuesta es un error, mostrar el mensaje
        return response.text();
      }
    })
    .then(errorMessage => {
      if (errorMessage) {
        alert(errorMessage); // Mostrar el error recibido del servidor
      }
    })
    .catch(error => {
      console.error('Error en la solicitud:', error);
      alert('Hubo un problema al procesar tu solicitud. Intenta nuevamente más tarde.');
    });
  });
});

// ---------------------------- FUNCION FILTRAR HOTELES ----------------------------
async function filtrarHoteles() {
  const params = new URLSearchParams({
    nombreHotel: document.getElementById('nombreHotel').value,
    tipoDeHotel: document.getElementById('tipoDeHotel').value,
    comunidad: document.getElementById('comunidad').value,
    disponibilidad: document.getElementById('disponibilidad').value,
    precioMin: document.getElementById('precioMin').value,
    precioMax: document.getElementById('precioMax').value,
    fechaEntrada: document.getElementById('fechaEntrada').value,
    fechaSalida: document.getElementById('fechaSalida').value
  });

  const response = await fetch(`/hoteles?${params}`);
  const hoteles = await response.json();

  document.getElementById('hoteles').innerHTML = hoteles.map(hotel =>
    `<div class="hotel-card"><h2>${hotel.nombre}</h2><p>${hotel.tipo} - ${hotel.comunidad}</p></div>`
  ).join('');
}


function limpiarFiltros() {
  document.querySelectorAll('.filters input, .filters select').forEach(el => el.value = '');
}

//! ---------------------------- FUNCION MOSTRAR LOS HOTELES ----------------------------
function mostrarHoteles(hoteles) {
  const hotelesContainer = document.getElementById('hoteles');
  hotelesContainer.innerHTML = '';

  if (!Array.isArray(hoteles) || hoteles.length === 0) {
    hotelesContainer.innerHTML = '<p>No se encontraron hoteles que coincidan con los filtros.</p>';
    return;
  }

  hoteles.forEach(hotel => {
    const hotelDiv = document.createElement('div');
    hotelDiv.className = 'hotel';

    const nombre = hotel.nombre || 'Nombre no disponible';
    const tipo = hotel.tipo || 'No especificado';
    const comunidad = hotel.comunidad || 'No especificado';
    const precio = hotel.precio !== undefined ? `${hotel.precio}€` : 'No disponible';
    const disponibilidad = hotel.disponibilidad === 1 ? 'Disponible ✅' : 'No disponible ❌';
    
    // Asegurar que la ruta sea correcta
    const imagen = hotel.imagen ? `/${hotel.imagen}` : '/img/default.jpg'; // Imagen por defecto

    hotelDiv.innerHTML = `
      <div class="hotel-card">
        <img src="${imagen}" alt="Imagen de ${nombre}" class="hotel-img">
        <div class="hotel-info">
          <h2>${nombre}</h2>
          <p><strong>Tipo de Hotel:</strong> ${tipo}</p>
          <p><strong>Comunidad Autónoma:</strong> ${comunidad}</p>
          <p><strong>Precio:</strong> ${precio}</p>
          <p><strong>Disponibilidad:</strong> ${disponibilidad}</p>
        </div>
      </div>
    `;
    hotelesContainer.appendChild(hotelDiv);
  });
}

//! -------------------------------------------------------- FUNCIONES DE BÚSQUEDA --------------------------------------------------------
// ---------------------------- FILTRAR POR TIPO DE HOTEL ----------------------------
function filtrarPorTipoDeHotel(tipoDeHotel = "") {
  // Si no se especifica un tipoDeHotel (por ejemplo, para el dropdown), se usa el valor de la URL
  if (!tipoDeHotel) {
    tipoDeHotel = document.getElementById('tipoDeHotel').value.trim().toLowerCase();
  }

  // Si no se seleccionó un tipo, no se aplica ningún filtro
  if (!tipoDeHotel) {
    fetch('/hoteles')
      .then(response => response.json())
      .then(hoteles => mostrarHoteles(hoteles))
      .catch(error => {
        console.error('Error al cargar los hoteles:', error);
        mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
      });
    return;
  }

  // Filtrado por tipo de hotel
  fetch(`/hoteles?tipoDeHotel=${encodeURIComponent(tipoDeHotel)}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar los hoteles por tipo:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

// ---------------------------- FILTRAR POR COMUNIDAD AUTONOMA ----------------------------
function filtrarPorComunidadAutonomas() {
  const comunidadAutonomas = document.getElementById('comunidad').value.trim().toLowerCase();

  // Si no se seleccionó una comunidad, no se aplica ningún filtro
  if (!comunidadAutonomas) {
    fetch('/hoteles')
      .then(response => response.json())
      .then(hoteles => mostrarHoteles(hoteles))
      .catch(error => {
        console.error('Error al cargar los hoteles:', error);
        mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
      });
    return;
  }

  fetch(`/hoteles?comunidad=${encodeURIComponent(comunidadAutonomas)}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar los hoteles por comunidad autónoma:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

// ---------------------------- FILTRAR POR DISPONIBILIDAD ----------------------------
function filtrarPorDisponibilidad() {
  const disponibilidad = document.getElementById('disponibilidad').value;

  // Si no se seleccionó una opción de disponibilidad, no se aplica ningún filtro
  if (disponibilidad === "") {
    fetch('/hoteles')
      .then(response => response.json())
      .then(hoteles => mostrarHoteles(hoteles))
      .catch(error => {
        console.error('Error al cargar los hoteles:', error);
        mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
      });
    return;
  }

  fetch(`/hoteles?disponibilidad=${disponibilidad}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar por disponibilidad:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR PRECIO ----------------------------
function filtrarPorPrecio() {
  const precioMin = document.getElementById('precioMin').value.trim();
  const precioMax = document.getElementById('precioMax').value.trim();

  let url = '/hoteles?';
  if (precioMin) url += `precioMin=${encodeURIComponent(precioMin)}&`;
  if (precioMax) url += `precioMax=${encodeURIComponent(precioMax)}`;

  fetch(url)
    .then(response => response.json())
    .then(hoteles => {
      console.log("Hoteles filtrados por precio:", hoteles);
      mostrarHoteles(hoteles);
    })
    .catch(error => {
      console.error('Error al filtrar por precio:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR TIPO, COMUNIDAD Y PRECIO ----------------------------
function filtrarPorTipoComunidadYPrecio() {
  const tipoDeHotel = document.getElementById('tipoDeHotel').value.trim().toLowerCase();
  const comunidadAutonomas = document.getElementById('comunidad').value.trim().toLowerCase(); // El ID de comunidad es correcto aquí
  const precioMin = document.getElementById('precioMin').value.trim();
  const precioMax = document.getElementById('precioMax').value.trim();

  // Validar si al menos un campo está seleccionado
  if (!tipoDeHotel && !comunidadAutonomas && !precioMin && !precioMax) {
    mostrarError('Por favor, selecciona al menos un filtro.');
    return;
  }

  let url = '/hoteles?';

  // Añadir los filtros al URL si están seleccionados
  if (tipoDeHotel) url += `tipoDeHotel=${encodeURIComponent(tipoDeHotel)}&`;
  
  // Cambié de comunidadAutonomas a comunidad
  if (comunidadAutonomas) url += `comunidad=${encodeURIComponent(comunidadAutonomas)}&`; // Se cambia a "comunidad"
  
  if (precioMin) url += `precioMin=${encodeURIComponent(precioMin)}&`;
  if (precioMax) url += `precioMax=${encodeURIComponent(precioMax)}&`;

  console.log('URL de la solicitud:', url); // Para depurar y verificar la URL generada

  // Realizar la solicitud de filtrado
  fetch(url)
    .then(response => response.json())
    .then(hoteles => {
      console.log('Hoteles filtrados por Tipo, Comunidad y Precio:', hoteles); // DEBUG
      mostrarHoteles(hoteles);
    })
    .catch(error => {
      console.error('Error al filtrar los hoteles:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR FECHAS ----------------------------
function filtrarPorFecha() {
  const fechaEntrada = document.getElementById('fechaEntrada').value;
  const fechaSalida = document.getElementById('fechaSalida').value;

  // Validar que ambas fechas se seleccionen
  if (!fechaEntrada || !fechaSalida) {
    mostrarError('Por favor, selecciona una fecha de entrada y salida.');
    return;
  }

  // Convertir las fechas a objetos Date
  const entrada = new Date(fechaEntrada);
  const salida = new Date(fechaSalida);

  // Verificar que la fecha de entrada no sea posterior a la de salida
  if (entrada >= salida) {
    mostrarError('La fecha de entrada no puede ser posterior a la fecha de salida.');
    return;
  }

  // Filtrar los hoteles que estén disponibles en esas fechas
  fetch(`/hoteles?fechaEntrada=${fechaEntrada}&fechaSalida=${fechaSalida}`)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar por fechas:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! ---------------------------- FILTRAR POR EXTRAS (ADULTOS, NIÑOS, HABITACIONES, MASCOTAS) ----------------------------
function filtrarPorExtras() {
  const numeroAdultos = document.getElementById('numeroAdultos').value;
  const numeroNinos = document.getElementById('numeroNinos').value;
  const numeroHabitaciones = document.getElementById('numeroHabitaciones').value;
  const llevoMascota = document.getElementById('llevoMascota').value;

  // Construir la URL con los parámetros de filtrado
  let url = '/hoteles?';

  if (numeroAdultos) url += `numeroAdultos=${encodeURIComponent(numeroAdultos)}&`;
  if (numeroNinos) url += `numeroNinos=${encodeURIComponent(numeroNinos)}&`;
  if (numeroHabitaciones) url += `numeroHabitaciones=${encodeURIComponent(numeroHabitaciones)}&`;
  if (llevoMascota) url += `llevoMascota=${encodeURIComponent(llevoMascota)}&`;

  // Hacer la petición al servidor para obtener los hoteles filtrados
  fetch(url)
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al filtrar por extras:', error);
      mostrarError('Hubo un problema al obtener los hoteles. Intenta de nuevo.');
    });
}

//! CÓDIGO EXTRA
//! ---------------------------- CARGAR DATOS AL CARGAR LA PAGINA ----------------------------
document.addEventListener('DOMContentLoaded', () => {
  fetch('/hoteles')
    .then(response => response.json())
    .then(hoteles => mostrarHoteles(hoteles))
    .catch(error => {
      console.error('Error al cargar los hoteles:', error);
      mostrarError('Hubo un problema al cargar los hoteles.');
    });
});

//! ---------------------------- FUNCION MOSTRAR UN MENSAJE DE ERROR ----------------------------
function mostrarError(message) {
  const hotelesContainer = document.getElementById('hoteles');
  hotelesContainer.innerHTML = `<p style="color: red;">${message}</p>`;
}