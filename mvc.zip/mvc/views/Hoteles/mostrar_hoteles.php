<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hoteles Disponibles</title>
</head>
<body>
    <h1>Hoteles Disponibles</h1>

    <?php if (!empty($hoteles)): ?>
        <div class="hoteles-lista">
            <?php foreach ($hoteles as $hotel): ?>
                <div class="hotel">
                    <h2><?php echo $hotel['nombre']; ?></h2>
                    <p><strong>Tipo:</strong> <?php echo $hotel['tipo_hotel']; ?></p>
                    <p><strong>Descripción:</strong> <?php echo $hotel['descripcion']; ?></p>
                    <p><strong>Comunidad Autónoma:</strong> <?php echo $hotel['comunidad_autonoma']; ?></p>
                    <p><strong>Dirección:</strong> <?php echo $hotel['direccion']; ?></p>
                    <p><strong>Teléfono:</strong> <?php echo $hotel['telefono']; ?></p>
                    <p><strong>Precio por noche:</strong> <?php echo $hotel['precio_noche']; ?>€</p>
                    <p><strong>Estrellas:</strong> <?php echo $hotel['estrellas']; ?> Estrellas</p>
                    <img src="<?php echo $hotel['img']; ?>" alt="<?php echo $hotel['nombre']; ?>">
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <p>No se encontraron hoteles disponibles para tus criterios.</p>
    <?php endif; ?>
</body>
</html>
