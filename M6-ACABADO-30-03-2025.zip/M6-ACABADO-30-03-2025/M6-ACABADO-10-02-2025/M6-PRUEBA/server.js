// CONSTANTES PRINCIPALES - BASE DE DATOS
const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');
const cookieParser = require('cookie-parser');

const app = express();
const port = 3000;

// ---------------- APP USE ----------------
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser()); // Aquí se configura cookie-parser
app.use(express.static(path.join(__dirname, 'public')));

// ---------------- APP GET SERVIDOR ----------------
// (Opcional) Ruta para el favicon para evitar errores de CSP
app.get('/favicon.ico', (req, res) => res.status(204).end());

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/test-redirect', (req, res) => {
  res.redirect('/');
});

app.use(express.json());  // Asegura que Express pueda manejar datos JSON

// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});

// -------------------- CONEXIÓN A LA BASE DE DATOS --------------------
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'P@ssw0rd',
  database: 'hoteles_db'
});

db.connect((err) => {
  if (err) {
    console.error('❌ Error al conectar a la base de datos:', err.message);
    process.exit(1);
  }
  console.log('✅ Conectado a MySQL');
});
// -------------------- FIN DE LA CONEXIÓN A LA BASE DE DATOS --------------------


// ---------------------------- APARTADO APP.GET - CONSULTAS HOTELES ----------------------------
// Ruta para obtener hoteles
app.get('/hoteles', (req, res) => {
  const { 
    tipoDeHotel, 
    comunidad, 
    disponibilidad, 
    precioMin, 
    precioMax, 
    fechaEntrada, 
    fechaSalida, 
    numeroAdultos, 
    numeroNinos, 
    numeroHabitaciones, 
    llevoMascota 
  } = req.query;
  
  let query = "SELECT * FROM hoteles WHERE 1=1";
  const params = [];

  if (tipoDeHotel) {
    query += " AND tipo LIKE ?";
    params.push(`%${tipoDeHotel}%`);
  }
  if (comunidad) {
    query += " AND LOWER(comunidad) LIKE ?";
    params.push(`%${comunidad.toLowerCase()}%`);
  }  
  if (disponibilidad) {
    query += " AND disponibilidad = ?";
    params.push(disponibilidad === 'true' ? 1 : 0);
  }  
  if (precioMin) {
    query += " AND precio >= ?";
    params.push(precioMin);
  }
  if (precioMax) {
    query += " AND precio <= ?";
    params.push(precioMax);
  }
  if (fechaEntrada && fechaSalida) {
    query += " AND available_from <= ? AND available_to >= ?";
    params.push(fechaEntrada, fechaSalida);
  }
  if (numeroAdultos) {
    query += " AND numero_adultos >= ?";
    params.push(numeroAdultos);
  }
  if (numeroNinos) {
    query += " AND numero_ninos >= ?";
    params.push(numeroNinos);
  }
  if (numeroHabitaciones) {
    query += " AND numero_habitaciones >= ?";
    params.push(numeroHabitaciones);
  }
  if (llevoMascota) {
    query += " AND permite_mascotas = ?";
    params.push(llevoMascota === 'true' ? 1 : 0);
  }

  db.query(query, params, (err, results) => {
    if (err) {
      console.error('Error al obtener los hoteles:', err);
      return res.status(500).json({ error: 'Error al obtener hoteles' });
    }
    res.json(results);
  });
});
// ---------------------------- FIN APARTADO APP.GET - CONSULTAS HOTELES ----------------------------


// ------------------------ FUNCIONES APP.GET SESIÓN - REGISTRO - CIERRE SESIÓN ------------------------
// APP - INICIO SESIÓN
app.get('/usuario', (req, res) => {
  const usuario = req.cookies.usuario;
  
  if (usuario) {
    res.json(JSON.parse(usuario)); // Devolver datos del usuario
  } else {
    res.status(401).send("No autenticado");
  }
});

// Ruta para servir la página de REGISTRO (registro.html)
app.get('/registro', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'registro', 'registro.html'));
});

// Ruta para servir la página de INICIO SESIÓN (inicio_sesion.html)
app.get('/inicio_sesion', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'inicio_sesion', 'inicio_sesion.html'));
});

// Ruta para servir la página de CIERRE SESIÓN (inicio_sesion.html)
app.get('/logout', (req, res) => {
  // Borra la cookie del usuario
  res.clearCookie('usuario');
  // Redirige al usuario a la página de inicio de sesión (o a donde prefieras)
  res.redirect('/inicio_sesion/inicio_sesion.html');
});

// ---------------------------- APARTADO APP.POST REGISTRO - INICIO SESIÓN - CIERRE SESIÓN ----------------------------
// RUTA DE LOGIN - APARTADO LOGIN
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).send("Faltan datos de login.");
  }

  const queryUser = "SELECT * FROM usuarios WHERE username = ? AND password = SHA2(?, 256) LIMIT 1";
  db.query(queryUser, [username, password], (err, results) => {
    if (err) {
      console.error("Error en la base de datos:", err);
      return res.status(500).send("Error interno en el servidor.");
    }

    if (results.length > 0) {
      console.log("Usuario autenticado:", results[0]);
      // Guarda los datos del usuario en una cookie
      res.cookie("usuario", JSON.stringify(results[0]), { maxAge: 3600000, httpOnly: false });
      return res.redirect('/index.html');
    } else {
      // ... (código para manejar el caso del admin o credenciales inválidas)
      const queryAdmin = "SELECT * FROM admin WHERE username = ? AND password = SHA2(?, 256) LIMIT 1";
      db.query(queryAdmin, [username, password], (err, adminResults) => {
        if (err) {
          console.error("Error en la base de datos:", err);
          return res.status(500).send("Error interno en el servidor.");
        }

        if (adminResults.length > 0) {
          console.log("Administrador autenticado:", adminResults[0]);
          return res.redirect('/');
        } else {
          return res.status(401).send("Credenciales inválidas.");
        }
      });
    }
  });
});
// FIN RUTA DE LOGIN - APARTADO LOGIN

// CODIGO UNICO PARA REGISTRO 
app.post('/register', (req, res) => {
  const { username, email, password, confirmPassword } = req.body;

  // Verificar si faltan datos en el formulario
  if (!username || !email || !password || !confirmPassword) {
    return res.status(400).send("Faltan datos en el registro.");
  }

  // Verificar que las contraseñas coincidan
  if (password !== confirmPassword) {
    return res.status(400).send("Las contraseñas no coinciden.");
  }

  // Verificar si el nombre de usuario o el correo electrónico ya existen
  const queryCheck = "SELECT * FROM usuarios WHERE username = ? OR correo = ? LIMIT 1";
  db.query(queryCheck, [username, email], (err, results) => {
    if (err) {
      console.error("Error al consultar la base de datos:", err);
      return res.status(500).send("Error interno en el servidor.");
    }

    if (results.length > 0) {
      return res.status(400).send("El nombre de usuario o el correo electrónico ya están registrados.");
    }

    // Insertar el nuevo usuario en la base de datos
    const queryInsert = "INSERT INTO usuarios (username, correo, password) VALUES (?, ?, SHA2(?, 256))";
    db.query(queryInsert, [username, email, password], (err, insertResults) => {
      if (err) {
        console.error("Error al insertar el usuario en la base de datos:", err);
        return res.status(500).send("Error al registrar el usuario.");
      }

      console.log("Nuevo usuario registrado:", username);
      return res.send("¡Registro exitoso! Puedes iniciar sesión ahora.");
    });
  });
});
// FIN CODIGO UNICO REGISTRO 

// CODIGO ACTUALIZACIÓN (UPDATE) DATOS USUARIOS
app.post('/updateUser', (req, res) => {
  const { username, nombre, apellidos, correo, telefono, pais, ciudad } = req.body;
  
  if (!username || !correo) {
    return res.status(400).json({ error: "Faltan datos requeridos" });
  }
  
  const query = `UPDATE usuarios 
                SET nombre = ?, apellidos = ?, correo = ?, telefono = ?, pais = ?, ciudad = ? 
                WHERE username = ?`;
  
  db.query(query, [nombre, apellidos, correo, telefono, pais, ciudad, username], (err, result) => {
    if (err) {
      console.error("Error al actualizar el usuario:", err);
      return res.status(500).json({ error: "Error al actualizar el usuario" });
    }
    
    // Consulta para obtener los datos actualizados del usuario
    const queryUser = "SELECT * FROM usuarios WHERE username = ? LIMIT 1";
    db.query(queryUser, [username], (err, results) => {
      if (err) {
        console.error("Error al obtener el usuario actualizado:", err);
        return res.status(500).json({ error: "Error al obtener datos actualizados" });
      }
      if (results.length > 0) {
        // Actualiza la cookie con los nuevos datos
        res.cookie("usuario", JSON.stringify(results[0]), { maxAge: 3600000, httpOnly: false });
        return res.json({ success: true, user: results[0] });
      } else {
        return res.status(404).json({ error: "Usuario no encontrado" });
      }
    });
  });
});
// FIN CODIGO ACTUALIZACIÓN (UPDATE) DATOS USUARIOS
// ---------------------------------------- FIN APARTADO REGISTRO - INICIO SESIÓN - CIERRE SESIÓN --------------------