<?php
$config = Config::singleton();
 
$config->set('controllersFolder', 'controllers/');
$config->set('modelsFolder', 'models/');
$config->set('viewsFolder', 'views/');
 
$config->set('dbhost', 'localhost');
$config->set('dbname', 'elementalStay');
$config->set('dbuser', 'root');
$config->set('dbpass', 'P@ssw0rd');
?>