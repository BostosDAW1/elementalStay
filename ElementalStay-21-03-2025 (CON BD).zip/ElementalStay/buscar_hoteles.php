<?php
session_start();

// Conectar a la base de datos
$servername = "localhost";
$username = "usuario";
$password = "EwnizEv5";
$dbname = "elementalStay";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Recibir datos del formulario
$destino = $_POST['destino'];
$entrada = $_POST['entrada'];
$salida = $_POST['salida'];

// Consulta SQL para obtener los hoteles disponibles
$sql = "
    SELECT h.id, h.nombre, h.descripcion, h.direccion
    FROM hoteles h
    JOIN habitaciones ha ON h.id = ha.id_hotel
    JOIN disponibilidad_habitaciones d ON ha.id = d.id_habitacion
    WHERE d.fecha >= ? AND d.fecha <= ? AND d.disponibilidad = 1
    AND h.destino = ?
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $entrada, $salida, $destino);
$stmt->execute();
$result = $stmt->get_result();

// Mostrar los resultados
if ($result->num_rows > 0) {
    echo "<h2>Hoteles disponibles</h2>";
    while ($row = $result->fetch_assoc()) {
        echo "<div>";
        echo "<h3>" . $row['nombre'] . "</h3>";
        echo "<p>" . $row['descripcion'] . "</p>";
        echo "<p>Dirección: " . $row['direccion'] . "</p>";
        echo "</div>";
    }
} else {
    echo "No hay hoteles disponibles para esas fechas y destino.";
}

$conn->close();
?>
