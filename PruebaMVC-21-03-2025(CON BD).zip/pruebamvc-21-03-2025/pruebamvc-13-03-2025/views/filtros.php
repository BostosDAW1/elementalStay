<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Filtros</title>
</head>
<body>
  <section>
    <div class="container">
      <div class="text-section">
        <img src="./img/hotelPrincipal2.jpg" alt="fotoprincipal">
      </div>
      <div class="form-section">
        <form method="GET" action="../index.php?controlador=Hoteles&accion=listarHoteles">
          <!-- Campos ocultos para la redirección -->
          <input type="hidden" name="controlador" value="Hoteles">
          <input type="hidden" name="accion" value="listarHoteles">

            <div class="form-group">
            <label for="destino"><b>¿Adónde vas?</b></label>
            <select name="destino" id="destino">
              <option value="">Seleccione una ciudad</option>
              <option value="Valencia">Valencia</option>
              <option value="Madrid">Madrid</option>
              <option value="Cantabria">Cantabria</option>
            </select>
          </div>


          <div class="form-group">
            <label for="entrada"><b>Fecha de entrada</b></label>
            <input type="date" id="entrada" name="entrada">
          </div>

          <div class="form-group">
            <label for="salida"><b>Fecha de salida</b></label>
            <input type="date" id="salida" name="salida">
          </div>

          <div class="form-group">
            <label><b>Adultos</b></label>
            <input type="number" id="adultos" name="adultos" value="1" min="1">
          </div>

          <div class="form-group">
            <label><b>Niños</b></label>
            <input type="number" id="ninos" name="ninos" value="0" min="0">
          </div>

            <!-- Nuevos campos para rango de precios -->
  <div class="form-group">
    <label for="precio_min"><b>Precio Mínimo (€)</b></label>
    <input type="number" id="precio_min" name="precio_min" step="0.01" min="0">
  </div>

  <div class="form-group">
    <label for="precio_max"><b>Precio Máximo (€)</b></label>
    <input type="number" id="precio_max" name="precio_max" step="0.01" min="0">
  </div>

          <button type="submit">Confirmar</button>
        </form>
      </div>
    </div>
  </section>
</body>
</html>
