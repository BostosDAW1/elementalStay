<?php
class FrontController
{
    static function main()
    {
        // Incluir las clases necesarias
        require 'libs/Config.php'; // Configuración
        require 'libs/SPDO.php'; // Conexión a la base de datos con PDO
        require 'libs/View.php'; // Motor de plantillas

        require 'config.php'; // Configuraciones adicionales

        // Formar el nombre del controlador a partir de la URL
        if (!empty($_GET['controlador'])) {
            $controllerName = $_GET['controlador'] . 'Controller';
        } else {
            $controllerName = "HotelController"; // Usamos HotelController como controlador por defecto
        }

        // Formar el nombre de la acción
        if (!empty($_GET['accion'])) {
            $actionName = $_GET['accion'];
        } else {
            $actionName = "index"; // Acción por defecto
        }

        // Ruta del controlador
        $controllerPath = $config->get('controllersFolder') . $controllerName . '.php';

        // Incluir el archivo del controlador solicitado
        if (is_file($controllerPath)) {
            require $controllerPath;
        } else {
            die('El controlador no existe - 404 not found');
        }

        // Crear la instancia del controlador y llamar a la acción
        $controller = new $controllerName();
        $controller->$actionName();
    }
}
?>
