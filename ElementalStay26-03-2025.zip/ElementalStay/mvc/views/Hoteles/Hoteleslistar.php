<?php
session_start();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  <title>Elemental Stay - Hoteles seleccionados</title>
  <link rel="stylesheet" href="../CSS/header.css"/>
  <link rel="stylesheet" href="../CSS/hoteles.css"/>
  <link rel="stylesheet" href="../CSS/footer.css"/>
  <link rel="shortcut icon" href="../img/logo.png"/>
</head>
<body>
    <!-- ------------------------ NAV PRINCIPAL + OPCIONES --------------------- -->
    <nav>
        <div class="logo">
            <img src="../img/logo.png" alt="Logo">
            <h1 class="logo-title">ELEMENTAL STAY</h1>
        </div>
        <ul>
            <li><a href="../index.php" id="boton-superior"><b>INICIO</b></a></li>
            <li><a href="../contactos/contactos.php" id="boton-superior"><b>CONTACTO</b></a></li>
            <?php if (isset($_SESSION['usuario'])): ?>
                <li class="profile">
                    <a href="javascript:void(0);" onclick="toggleProfileMenu(event)" id="profileButton"><b>PERFIL</b></a>
                    <div class="profile-menu" id="profileMenu">
                        <a href="../perfil/perfil.php">Ver Perfil</a>
                        <a href="../inicio_session/logout.php" class="logout">Cerrar Sesión</a>
                    </div>
                </li>
            <?php else: ?>
                <li><a href="../inicio_session/inicio_session.php" id="boton-superior"><b>INICIAR SESIÓN</b></a></li>
            <?php endif; ?>
        </ul>
    </nav>
    
    <!-- ------------------------ SCRIPT DEL DESPLEGABLE DEL PERFIL --------------------- -->
    <script>
        function toggleProfileMenu(event) {
            event.stopPropagation();
            var menu = document.getElementById('profileMenu');
            menu.classList.toggle('show');
        }
        window.onclick = function(event) {
            if (!event.target.matches('#profileButton') && !event.target.closest('.profile')) {
                var dropdowns = document.getElementsByClassName('profile-menu');
                for (var i = 0; i < dropdowns.length; i++) {
                    dropdowns[i].classList.remove('show');
                }
            }
        }
    </script>
    
    <div class="wrapper">
    <!-- --------------------- BARRA DE BÚSQUEDA --------------------- -->
    <div class="search-bar">
        <input type="text" placeholder="¿Dónde quieres ir?">
        <select id="hotel-select">
            <option value="all">Todos los hoteles</option>
        </select>
        <input type="date" value="2025-05-29">
    </div>
    
    <!-- --------------------- CONTENEDOR PRINCIPAL --------------------- -->
    <?php
    // Recuperar los filtros aplicados (puedes adaptarlo según tu lógica de aplicación)
    $filtroComunidad = isset($_GET['comunidad']) ? htmlspecialchars($_GET['comunidad']) : '';
    $filtroEntrada   = isset($_GET['entrada'])   ? htmlspecialchars($_GET['entrada'])   : '';
    $filtroSalida    = isset($_GET['salida'])    ? htmlspecialchars($_GET['salida'])    : '';
    $filtroAdultos   = isset($_GET['adultos'])   ? htmlspecialchars($_GET['adultos'])   : '';
    $filtroNinos     = isset($_GET['ninos'])     ? htmlspecialchars($_GET['ninos'])     : '';
?>
        <main>
<div class="container">
    <!-- Sección de resultados -->
    <section class="results" id="hotel-list">
        <?php if (!empty($listado) && is_array($listado)): ?>
            <?php foreach ($listado as $hotel): 
                $imagen      = $config->get('imagePath') . $hotel['img'];
                $nombre      = htmlspecialchars($hotel['nombre']);
                $comunidad   = htmlspecialchars($hotel['comunidad_autonoma']);
                $precio      = number_format($hotel['min_precio'], 2);
                $idHotel     = htmlspecialchars($hotel['id_hotel']);
                $descripcion = htmlspecialchars($hotel['descripcion']);
                $estrellas   = (int) $hotel['estrellas'];
            ?>
                <article class="hotel-card" data-hotel="<?= $nombre ?>">
                    <!-- Imagen del hotel -->
                    <div class="hotel-card__image">
                        <?php if (file_exists($imagen)): ?>
                            <img src="<?= $imagen ?>" alt="Imagen de <?= $nombre ?>" loading="lazy">
                        <?php else: ?>
                            <img src="ruta_a_una_imagen_por_defecto.jpg" alt="Imagen no disponible" loading="lazy">
                        <?php endif; ?>
                    </div>

                    <!-- Contenido / Información del hotel -->
                    <div class="hotel-card__content">
                        <div class="hotel-card__header">
                            <h3 class="hotel-card__name"><?= $nombre ?></h3>
                            <p class="hotel-card__stars">
                                <?php for ($i = 0; $i < $estrellas; $i++): ?>
                                    <span>⭐</span>
                                <?php endfor; ?>
                            </p>
                        </div>

                        <!-- Información de la reserva -->
                        <div class="booking-info">
                            <p>Hotel: Entrada <?= $filtroEntrada ?> Salida <?= $filtroSalida ?></p>
                            <p>Adultos: <?= $filtroAdultos ?>, Niños: <?= $filtroNinos ?></p>
                        </div>

                        <!-- Descripción extendida -->
                        <p class="hotel-card__description"><?= $descripcion ?></p>

                        <!-- Detalles adicionales -->
                        <ul class="hotel-card__details">
                            <li><strong>Comunidad:</strong> <?= $comunidad ?></li>
                            <li>
                                <strong>Precio:</strong> Desde <?= $precio ?>€ 
                                <span class="incluye">Incluye impuestos y cargos</span>
                            </li>
                        </ul>

                        <!-- Botón de reserva -->
                        <div class="hotel-card__footer">
                        <a class="hotel-card__btn" href="index.php?controlador=HotelesCompletos&accion=listarHabitacionesDisponibles&id=<?= $idHotel ?>&entrada=<?= $filtroEntrada ?>&salida=<?= $filtroSalida ?>&adultos=<?= $filtroAdultos ?>&ninos=<?= $filtroNinos ?>">
                            Ver más
                        </a>


                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
        <?php else: ?>
            <p class="no-results">No se encontraron hoteles disponibles.</p>
        <?php endif; ?>
    </section>
</div>

</main>






    <!-- ------------------------ FOOTER --------------------- -->
    <footer>
        <div class="footer-container">
            <div class="footer-section">
                <h4>Sobre Nosotros</h4>
                <p>Elemental Stay es tu plataforma para encontrar los mejores alojamientos al mejor precio, con opciones personalizadas para cada tipo de viajero.</p>
            </div>
            <div class="footer-section">
                <h4>Enlaces Útiles</h4>
                <ul>
                    <li><a href="#">Inicio</a></li>
                    <li><a href="#">Acerca de</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li><a href="#">Términos y Condiciones</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Síguenos</h4>
                <div class="social-icons">
                    <a href="#"><img src="icon-facebook.svg" alt="Facebook"></a>
                    <a href="#"><img src="icon-twitter.svg" alt="Twitter"></a>
                    <a href="#"><img src="icon-instagram.svg" alt="Instagram"></a>
                    <a href="#"><img src="icon-youtube.svg" alt="YouTube"></a>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2024 Elemental Stay. Todos los derechos reservados.</p>
        </div>
    </footer>
    </div>

    <!-- ------------------------ SCRIPTS --------------------- -->
    <script src="../JS/Header.js"></script>
    <script src="../JS/hoteles.js"></script>
</body>
</html>
