const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');
const cookieParser = require('cookie-parser');

const app = express();
const port = 3000;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser()); // Aquí se configura cookie-parser
app.use(express.static(path.join(__dirname, 'public')));

// (Opcional) Ruta para el favicon para evitar errores de CSP
app.get('/favicon.ico', (req, res) => res.status(204).end());

// CONEXIÓN A LA BASE DE DATOS
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'EwnizEv5',
  database: 'hoteles_db'
});

db.connect((err) => {
  if (err) {
    console.error('❌ Error al conectar a la base de datos:', err.message);
    process.exit(1);
  }
  console.log('✅ Conectado a MySQL');
});

// RUTA DE LOGIN
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).send("Faltan datos de login.");
  }

  const queryUser = "SELECT * FROM usuarios WHERE username = ? AND password = SHA2(?, 256) LIMIT 1";
  db.query(queryUser, [username, password], (err, results) => {
    if (err) {
      console.error("Error en la base de datos:", err);
      return res.status(500).send("Error interno en el servidor.");
    }

    if (results.length > 0) {
      console.log("Usuario autenticado:", results[0]);
      // Guarda los datos del usuario en una cookie
      res.cookie("usuario", JSON.stringify(results[0]), { maxAge: 3600000, httpOnly: false });
      return res.redirect('/index.html');
    } else {
      // ... (código para manejar el caso del admin o credenciales inválidas)
      const queryAdmin = "SELECT * FROM admin WHERE username = ? AND password = SHA2(?, 256) LIMIT 1";
      db.query(queryAdmin, [username, password], (err, adminResults) => {
        if (err) {
          console.error("Error en la base de datos:", err);
          return res.status(500).send("Error interno en el servidor.");
        }

        if (adminResults.length > 0) {
          console.log("Administrador autenticado:", adminResults[0]);
          return res.redirect('/');
        } else {
          return res.status(401).send("Credenciales inválidas.");
        }
      });
    }
  });
});



app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/test-redirect', (req, res) => {
  res.redirect('/');
});


app.post('/register', (req, res) => {
  console.log("Datos recibidos en el servidor:", req.body);  // Imprimimos los datos que llegaron

  const { username, email, password, confirmPassword } = req.body;

  // Verificamos si los datos no están vacíos
  if (!username || !email || !password || !confirmPassword) {
    console.error("Faltan datos en el registro:", req.body);  // Imprimimos los datos que llegaron
    return res.status(400).send("Faltan datos en el registro.");
  }

  if (password !== confirmPassword) {
    return res.status(400).send("Las contraseñas no coinciden.");
  }

  const queryCheck = "SELECT * FROM usuarios WHERE username = ? OR correo = ? LIMIT 1";
  db.query(queryCheck, [username, email], (err, results) => {
    if (err) {
      console.error("Error al consultar la base de datos:", err);
      return res.status(500).send("Error interno en el servidor.");
    }

    if (results.length > 0) {
      return res.status(400).send("El nombre de usuario o el correo ya están registrados.");
    }

    const queryInsert = "INSERT INTO usuarios (username, correo, password) VALUES (?, ?, SHA2(?, 256))";
    db.query(queryInsert, [username, email, password], (err, insertResults) => {
      if (err) {
        console.error("Error al insertar el usuario en la base de datos:", err);
        return res.status(500).send("Error al registrar el usuario.");
      }

      console.log("Nuevo usuario registrado:", username);
      return res.send("¡Registro exitoso! Puedes iniciar sesión ahora.");
    });
  });
});


app.get('/usuario', (req, res) => {
  const usuario = req.cookies.usuario;
  
  if (usuario) {
    res.json(JSON.parse(usuario)); // Devolver datos del usuario
  } else {
    res.status(401).send("No autenticado");
  }
});

app.use(express.json());  // Asegura que Express pueda manejar datos JSON

// Ruta para servir la página de registro (registro.html)
app.get('/registro', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'registro', 'registro.html'));
});


app.get('/inicio_sesion', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'inicio_sesion', 'inicio_sesion.html'));
});

// Ruta para obtener hoteles
app.get('/hoteles', (req, res) => {
  const { 
    tipoDeHotel, 
    comunidad, 
    disponibilidad, 
    precioMin, 
    precioMax, 
    fechaEntrada, 
    fechaSalida, 
    numeroAdultos, 
    numeroNinos, 
    numeroHabitaciones, 
    llevoMascota 
  } = req.query;
  
  let query = "SELECT * FROM hoteles WHERE 1=1";
  const params = [];

  if (tipoDeHotel) {
    query += " AND tipo LIKE ?";
    params.push(`%${tipoDeHotel}%`);
  }
  if (comunidad) {
    query += " AND LOWER(comunidad) LIKE ?";
    params.push(`%${comunidad.toLowerCase()}%`);
  }  
  if (disponibilidad) {
    query += " AND disponibilidad = ?";
    params.push(disponibilidad === 'true' ? 1 : 0);
  }  
  if (precioMin) {
    query += " AND precio >= ?";
    params.push(precioMin);
  }
  if (precioMax) {
    query += " AND precio <= ?";
    params.push(precioMax);
  }
  if (fechaEntrada && fechaSalida) {
    query += " AND available_from <= ? AND available_to >= ?";
    params.push(fechaEntrada, fechaSalida);
  }
  if (numeroAdultos) {
    query += " AND numero_adultos >= ?";
    params.push(numeroAdultos);
  }
  if (numeroNinos) {
    query += " AND numero_ninos >= ?";
    params.push(numeroNinos);
  }
  if (numeroHabitaciones) {
    query += " AND numero_habitaciones >= ?";
    params.push(numeroHabitaciones);
  }
  if (llevoMascota) {
    query += " AND permite_mascotas = ?";
    params.push(llevoMascota === 'true' ? 1 : 0);
  }

  db.query(query, params, (err, results) => {
    if (err) {
      console.error('Error al obtener los hoteles:', err);
      return res.status(500).json({ error: 'Error al obtener hoteles' });
    }
    res.json(results);
  });
});

app.post('/updateUser', (req, res) => {
  const { username, nombre, apellidos, correo, telefono, pais, ciudad } = req.body;
  
  if (!username || !correo) {
    return res.status(400).json({ error: "Faltan datos requeridos" });
  }
  
  const query = `UPDATE usuarios 
                SET nombre = ?, apellidos = ?, correo = ?, telefono = ?, pais = ?, ciudad = ? 
                WHERE username = ?`;
  
  db.query(query, [nombre, apellidos, correo, telefono, pais, ciudad, username], (err, result) => {
    if (err) {
      console.error("Error al actualizar el usuario:", err);
      return res.status(500).json({ error: "Error al actualizar el usuario" });
    }
    
    // Actualización exitosa
    return res.json({ success: true });
  });
});

app.get('/logout', (req, res) => {
  // Borra la cookie del usuario
  res.clearCookie('usuario');
  // Redirige al usuario a la página de inicio de sesión (o a donde prefieras)
  res.redirect('/inicio_sesion/inicio_sesion.html');
});


// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
