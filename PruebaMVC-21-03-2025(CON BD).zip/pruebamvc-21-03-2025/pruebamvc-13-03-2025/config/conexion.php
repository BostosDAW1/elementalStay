<?php
$servername = "localhost";
$username   = "root";
$password   = "EwnizEv5";
$dbname     = "elementalStay";

// Creamos la conexión mysqli
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificamos la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>
