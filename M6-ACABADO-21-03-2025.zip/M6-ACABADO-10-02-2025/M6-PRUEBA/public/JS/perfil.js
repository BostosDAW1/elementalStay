// FUNCIÓN TRANSICIÓN EDICIÓN - GUARDADO DATOS DE USUARIO
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('profile-form');
  const editBtn = document.querySelector('.edit-btn');
  const saveBtn = document.querySelector('.save-btn');
  const cancelBtn = document.querySelector('.cancel-btn');

  // Función para alternar el modo de edición
  const setEditMode = (enabled) => {
    const inputs = form.querySelectorAll('input');
    inputs.forEach(input => {
      // Por ejemplo, dejamos el "username" como solo lectura
      if (input.id !== 'username') {
        input.disabled = !enabled;
        input.style.background = enabled ? '#fff' : '#f9f9f9';
      }
    });
    if (enabled) {
      editBtn.style.display = 'none';
      saveBtn.style.display = 'inline-block';
      cancelBtn.style.display = 'inline-block';
    } else {
      editBtn.style.display = 'inline-block';
      saveBtn.style.display = 'none';
      cancelBtn.style.display = 'none';
    }
  };

  // Obtener los datos del usuario y rellenar el formulario
  fetch('/usuario', { credentials: 'include' })
    .then(response => {
      if (!response.ok) {
        throw new Error('No autenticado');
      }
      return response.json();
    })
    .then(userData => {
      document.getElementById('username').value = userData.username;
      document.getElementById('nombre').value = userData.nombre || '';
      document.getElementById('apellidos').value = userData.apellidos || '';
      document.getElementById('correo').value = userData.correo;
      document.getElementById('telefono').value = userData.telefono || '';
      document.getElementById('pais').value = userData.pais || '';
      document.getElementById('ciudad').value = userData.ciudad || '';
    })
    .catch(error => {
      alert('Debes iniciar sesión primero.');
      window.location.href = '/inicio_sesion/inicio_sesion.html';
    });

  // Al hacer clic en "Editar", se habilitan los campos para modificar
  editBtn.addEventListener('click', () => {
    setEditMode(true);
  });

  // Si se cancela, se recargan los datos (o se puede volver al modo lectura sin recargar)
  cancelBtn.addEventListener('click', () => {
    window.location.reload();
  });

  // Envío del formulario para guardar cambios
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    // Recopilamos los datos actualizados
    const updatedData = {
      username: document.getElementById('username').value, // Se asume que no cambia
      nombre: document.getElementById('nombre').value,
      apellidos: document.getElementById('apellidos').value,
      correo: document.getElementById('correo').value,
      telefono: document.getElementById('telefono').value,
      pais: document.getElementById('pais').value,
      ciudad: document.getElementById('ciudad').value,
    };

    // Enviar los datos actualizados al servidor
    // IMPORTANTE: Debes implementar el endpoint '/updateUser' en el server para actualizar la BD.
    fetch('/updateUser', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      credentials: 'include',
      body: JSON.stringify(updatedData)
    })
    .then(response => {
      if (!response.ok) {
        throw new Error('Error al actualizar el perfil');
      }
      return response.json();
    })
    .then(result => {
      alert('Perfil actualizado con éxito');
      setEditMode(false);
    })
    .catch(error => {
      alert('Ocurrió un error al actualizar el perfil.');
      console.error(error);
    });
  });
});